PHARMACEUTICAL PATENT ML ANALYSIS - BACKUP PACKAGE
===================================================
Created: January 2026

CONTENTS
--------

/data/
  labeled_v2.json          - 1,400 cases with 6-doctrine labels (main dataset)
  ml_results_v2.json       - ML classification results (AUC, accuracy)
  feature_importance.json  - Top predictive features per doctrine
  temporal_analysis.json   - Outcome rates by era (Pre-KSR, Post-KSR, etc.)
  company_analysis.json    - Company win rates (brand & generic)
  cross_doctrine_correlations.json - Phi coefficients between doctrines
  error_analysis.json      - Misclassification patterns & calibration

/scripts/
  create_ai_law.js   - Generates AI & Law paper
  create_dss.js      - Generates Decision Support Systems paper
  create_rp.js       - Generates Research Policy paper
  create_smj.js      - Generates Strategic Management Journal paper

  To regenerate papers: npm install docx && node <script_name>.js

/papers/
  AI_Law_Paper_UPDATED.docx
  DSS_Paper_UPDATED.docx
  Research_Policy_UPDATED.docx
  SMJ_Paper_UPDATED.docx
  Pharma_Patent_ML_Full_Paper.docx  (comprehensive version)

KEY RESULTS
-----------
- Sample: 1,400 federal court decisions (1995-2025)
- 6 Doctrines: Infringement, DJ Jurisdiction, DOE, Claim Construction, 
               Counterclaim, Inequitable Conduct
- Best AUC: 0.91 (DJ Jurisdiction), 0.89 (DOE)
- Calibration: 90%+ accuracy at ≥0.8 confidence threshold
- Temporal: Infringement declined 26.6%→20.8%, DOE declined 82.6%→46.2%
- Company spreads: 13 percentage points for both brands and generics

NOTES
-----
- labeled_v2.json is ~48MB (contains full case text)
- Scripts require Node.js and docx package
- Papers are publication-ready Word documents
