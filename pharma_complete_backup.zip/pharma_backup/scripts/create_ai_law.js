const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, 
        HeadingLevel, BorderStyle, WidthType, ShadingType, AlignmentType,
        PageBreak, Footer, PageNumber } = require('docx');
const fs = require('fs');

const p = (text, spacing = 200) => new Paragraph({ 
    children: [new TextRun({ text, font: "Times New Roman", size: 24 })],
    spacing: { after: spacing, line: 360 }, alignment: AlignmentType.JUSTIFIED
});
const pI = (text) => new Paragraph({ 
    children: [new TextRun({ text, font: "Times New Roman", size: 22, italics: true })],
    spacing: { after: 150 }
});
const h1 = (text) => new Paragraph({
    heading: HeadingLevel.HEADING_1,
    children: [new TextRun({ text, bold: true, font: "Times New Roman", size: 28 })],
    spacing: { before: 400, after: 200 }
});
const h2 = (text) => new Paragraph({
    heading: HeadingLevel.HEADING_2,
    children: [new TextRun({ text, bold: true, font: "Times New Roman", size: 26 })],
    spacing: { before: 300, after: 150 }
});
const h3 = (text) => new Paragraph({
    heading: HeadingLevel.HEADING_3,
    children: [new TextRun({ text, bold: true, italics: true, font: "Times New Roman", size: 24 })],
    spacing: { before: 200, after: 100 }
});

const border = { style: BorderStyle.SINGLE, size: 1, color: "666666" };
const borders = { top: border, bottom: border, left: border, right: border };
const cell = (text, header = false, width = 1500) => new TableCell({
    borders, width: { size: width, type: WidthType.DXA },
    shading: header ? { fill: "D9E2F3", type: ShadingType.CLEAR } : undefined,
    margins: { top: 50, bottom: 50, left: 80, right: 80 },
    children: [new Paragraph({ children: [new TextRun({ text, bold: header, font: "Times New Roman", size: 20 })], alignment: AlignmentType.CENTER })]
});
const cellL = (text, header = false, width = 2200) => new TableCell({
    borders, width: { size: width, type: WidthType.DXA },
    shading: header ? { fill: "D9E2F3", type: ShadingType.CLEAR } : undefined,
    margins: { top: 50, bottom: 50, left: 80, right: 80 },
    children: [new Paragraph({ children: [new TextRun({ text, bold: header, font: "Times New Roman", size: 20 })] })]
});

const doc = new Document({
    styles: { default: { document: { run: { font: "Times New Roman", size: 24 } } } },
    sections: [{
        properties: {
            page: { size: { width: 12240, height: 15840 }, margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } }
        },
        footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ children: [PageNumber.CURRENT], font: "Times New Roman", size: 22 })] })] }) },
        children: [
            // TITLE
            new Paragraph({ spacing: { after: 400 } }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Machine Learning and Legal Reasoning in Patent Litigation:", bold: true, font: "Times New Roman", size: 32 })], spacing: { after: 100 } }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Predicting Judicial Decisions Across Six Doctrines", bold: true, font: "Times New Roman", size: 32 })], spacing: { after: 500 } }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "[Author Names]", font: "Times New Roman", size: 24 })], spacing: { after: 80 } }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "[Institutional Affiliations]", font: "Times New Roman", size: 24 })], spacing: { after: 300 } }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Working Paper — January 2026", italics: true, font: "Times New Roman", size: 24 })], spacing: { after: 80 } }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Target Journal: Artificial Intelligence and Law", italics: true, font: "Times New Roman", size: 24 })], spacing: { after: 500 } }),

            // ABSTRACT
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "ABSTRACT", bold: true, font: "Times New Roman", size: 24 })], spacing: { after: 200 } }),
            p("Can machine learning models capture the reasoning patterns underlying judicial decision-making? This paper investigates the predictability of legal reasoning in pharmaceutical patent litigation, examining six distinct judicial determinations—declaratory judgment jurisdiction, doctrine of equivalents, infringement, claim construction, counterclaim success, and inequitable conduct—that involve different doctrinal frameworks and reasoning structures. Using a corpus of 1,400 federal court decisions spanning 1995–2025, we develop a comprehensive natural language processing pipeline incorporating domain-specific preprocessing, multi-stage data leakage prevention, and systematic model evaluation."),
            p("Our models achieve cross-validated AUC scores of 0.66–0.91, with declaratory judgment jurisdiction achieving 0.91 AUC and doctrine of equivalents achieving 0.89 AUC—substantially higher than prior legal prediction studies. Calibration analysis demonstrates that high-confidence predictions (≥0.8) achieve 90–94% accuracy across doctrines, enabling reliable decision support. Feature importance analysis reveals that predictions align with established legal doctrine: procedural terminology predicts jurisdictional outcomes, company litigation histories predict infringement findings, and prosecution history language predicts doctrine of equivalents rejections."),
            p("We contribute three novel analyses illuminating the relationship between machine learning and legal reasoning. First, cross-doctrine independence analysis (phi coefficients < 0.1) demonstrates that doctrinal determinations are largely independent, suggesting cases involve genuinely distinct legal questions. Second, temporal evolution analysis reveals that doctrine of equivalents success rates declined from 82.6% to 46.2% across eras, reflecting cumulative judicial restrictions that the model captures. Third, error analysis identifies that most errors are false negatives in minority classes, with high-confidence predictions substantially more reliable than low-confidence ones. These findings demonstrate that ML models capture meaningful legal reasoning patterns while calibration analysis enables appropriate deployment for legal decision support."),
            p("Keywords: Legal prediction; Patent litigation; Machine learning; Natural language processing; Judicial reasoning; Explainable AI; Legal cognition; Computational law; Calibration"),

            new Paragraph({ children: [new PageBreak()] }),

            // 1. INTRODUCTION
            h1("1. Introduction"),
            p("The application of artificial intelligence to legal reasoning represents one of the most promising and challenging frontiers in computational law. Legal decisions involve complex reasoning over facts, statutes, precedents, and doctrinal frameworks that have evolved over centuries. Whether machine learning models can capture these reasoning patterns—and what their successes and failures reveal about legal cognition—remains an open empirical question with significant theoretical and practical implications."),
            p("This paper investigates judicial reasoning in pharmaceutical patent litigation, a domain offering several advantages for computational analysis of legal cognition. First, patent cases involve structured legal questions—infringement, validity, claim construction, doctrine of equivalents, inequitable conduct, declaratory judgment jurisdiction—with established doctrinal tests creating identifiable reasoning patterns. Second, the pharmaceutical context provides substantial case volume with relatively consistent fact patterns. Third, the Hatch-Waxman regulatory framework creates predictable litigation pathways. Fourth, multiple doctrines within single cases enable cross-doctrine analysis of reasoning independence."),
            p("Prior work in legal prediction has demonstrated meaningful accuracy in predicting Supreme Court decisions (Katz et al., 2017; AUC 0.70) and European Court of Human Rights outcomes (Aletras et al., 2016; 79% accuracy). However, these studies typically examined single binary outcomes. Pharmaceutical patent litigation offers the opportunity to examine multiple doctrinal determinations simultaneously, testing whether legal reasoning patterns are doctrine-specific or reflect general judicial tendencies."),

            h2("1.1 Research Questions"),
            p("We address four research questions central to understanding machine learning and legal reasoning: (1) Can ML models predict judicial outcomes across multiple distinct legal doctrines, and how does predictability vary? (2) What textual features drive predictions, and do they align with established legal doctrine? (3) Are doctrinal determinations within cases independent, or do they reflect correlated judicial tendencies? (4) How does model calibration enable responsible deployment for legal decision support?"),

            h2("1.2 Contributions"),
            p("We make five contributions to computational legal studies: (1) We demonstrate predictive performance substantially exceeding prior work, with AUC scores reaching 0.91 for declaratory judgment jurisdiction and 0.89 for doctrine of equivalents. (2) We extend analysis to six doctrines—more than any prior pharmaceutical patent study—enabling comparative analysis of reasoning patterns. (3) We provide cross-doctrine correlation analysis demonstrating independence of doctrinal determinations (phi < 0.1). (4) We conduct comprehensive calibration analysis showing that high-confidence predictions achieve 90%+ accuracy, enabling reliable decision support. (5) We analyze temporal evolution of doctrine, demonstrating that the model captures systematic shifts in legal standards."),

            new Paragraph({ children: [new PageBreak()] }),

            // 2. THEORETICAL BACKGROUND
            h1("2. Theoretical Background"),
            h2("2.1 Legal Reasoning and Computational Modeling"),
            p("Legal reasoning involves applying general rules to specific facts through processes of interpretation, analogy, and balancing (Levi, 1949; Sunstein, 1996). Unlike purely deductive systems, legal reasoning incorporates precedent, policy considerations, and doctrinal evolution. Whether such reasoning can be captured computationally has been debated since the earliest days of AI and law (Gardner, 1987; Ashley, 1990)."),
            p("Machine learning approaches to legal prediction differ fundamentally from rule-based expert systems. Rather than encoding explicit legal rules, ML models learn statistical patterns from case outcomes. This raises the question: do learned patterns capture meaningful legal reasoning, or merely superficial textual correlations? Feature importance analysis and calibration assessment provide tools to investigate this question empirically."),

            h2("2.2 Pharmaceutical Patent Doctrines"),
            p("We examine six doctrines representing different reasoning structures:"),
            h3("2.2.1 Declaratory Judgment Jurisdiction"),
            p("Article III standing for declaratory judgment requires an actual case or controversy. Following MedImmune (2007), courts apply a totality-of-circumstances test examining whether circumstances create substantial controversy of sufficient immediacy. This involves relatively formulaic analysis of established factors."),
            h3("2.2.2 Doctrine of Equivalents"),
            p("DOE permits infringement findings when accused elements perform substantially the same function in substantially the same way to achieve substantially the same result. However, prosecution history estoppel and the all-elements rule substantially limit DOE's application, creating structured analysis amenable to pattern recognition."),
            h3("2.2.3 Infringement"),
            p("Literal infringement requires that every claim limitation be present in the accused product. Analysis involves claim construction followed by comparison to accused products—a two-step process with distinct reasoning patterns."),
            h3("2.2.4 Claim Construction"),
            p("Following Markman (1996), claim construction is a question of law examining intrinsic evidence (claims, specification, prosecution history) and potentially extrinsic evidence (dictionaries, expert testimony). Courts interpret claim terms to determine scope."),
            h3("2.2.5 Inequitable Conduct"),
            p("Patents are unenforceable if applicants engaged in affirmative misrepresentation or failed to disclose material information with intent to deceive. Post-Therasense (2011), courts require but-for materiality and specific intent—heightened standards creating distinctive textual patterns."),
            h3("2.2.6 Counterclaim Success"),
            p("Generic defendants typically counterclaim for declaratory judgment of invalidity or non-infringement. Success depends on substantive patent law merged with procedural considerations."),

            new Paragraph({ children: [new PageBreak()] }),

            // 3. DATA AND METHODS
            h1("3. Data and Methods"),
            h2("3.1 Corpus Construction"),
            p("We constructed a corpus of 1,400 pharmaceutical patent decisions from federal courts spanning 1995–2025 through systematic Westlaw searches. Boolean queries combined pharmaceutical terminology (ANDA, NDA, generic, brand, drug names) with patent litigation indicators (patent infringement, claim construction, Hatch-Waxman, Paragraph IV). After filtering for substantive patent decisions and deduplication via content hashing, 1,400 unique decisions remained."),

            h2("3.2 Label Extraction"),
            p("We extracted doctrine-specific binary outcomes using regular expression patterns applied to judicial opinion text. Pattern development followed iterative refinement against manually coded subsamples. Final patterns emphasize precision over recall, accepting lower coverage to ensure label quality. Table 1 presents the distribution."),

            // TABLE 1
            new Paragraph({ children: [new TextRun({ text: "Table 1. Distribution of Labeled Cases by Doctrine", bold: true, italics: true, font: "Times New Roman", size: 22 })], spacing: { before: 250, after: 120 } }),
            new Table({
                width: { size: 100, type: WidthType.PERCENTAGE },
                rows: [
                    new TableRow({ children: [cellL("Doctrine", true), cell("N", true), cell("Positive", true), cell("Negative", true), cell("% Positive", true)] }),
                    new TableRow({ children: [cellL("DJ Jurisdiction"), cell("239"), cell("89"), cell("150"), cell("37.2%")] }),
                    new TableRow({ children: [cellL("Doctrine of Equivalents"), cell("64"), cell("47"), cell("17"), cell("73.4%")] }),
                    new TableRow({ children: [cellL("Infringement"), cell("755"), cell("185"), cell("570"), cell("24.5%")] }),
                    new TableRow({ children: [cellL("Claim Construction"), cell("268"), cell("133"), cell("135"), cell("49.6%")] }),
                    new TableRow({ children: [cellL("Counterclaim"), cell("179"), cell("134"), cell("45"), cell("74.9%")] }),
                    new TableRow({ children: [cellL("Inequitable Conduct"), cell("94"), cell("60"), cell("34"), cell("63.8%")] }),
                ]
            }),
            pI("Note: Positive indicates doctrine-favorable outcome (e.g., infringement found, jurisdiction proper, DOE applies)."),

            h2("3.3 Text Processing and Classification"),
            p("We employed TF-IDF vectorization (3,000 features, unigrams and bigrams, minimum document frequency of 2, English stop words removed). Three classifiers were evaluated: Logistic Regression with L2 regularization, Random Forest (100 trees), and Support Vector Machine with linear kernel. All models used balanced class weights and 5-fold stratified cross-validation. We report AUC as the primary metric for its threshold-independence."),

            h2("3.4 Calibration Assessment"),
            p("Beyond discrimination (AUC), we assessed calibration—whether predicted probabilities correspond to actual outcome frequencies. Well-calibrated models enable expected value calculations for decision support. We computed accuracy at confidence thresholds (0.6, 0.7, 0.8, 0.9) to characterize the reliability-coverage tradeoff."),

            new Paragraph({ children: [new PageBreak()] }),

            // 4. RESULTS
            h1("4. Results"),
            h2("4.1 Classification Performance"),
            p("Table 2 presents cross-validation results. Models achieved AUC scores substantially above chance (0.50) for all doctrines, with considerable variation in predictability."),

            // TABLE 2
            new Paragraph({ children: [new TextRun({ text: "Table 2. Classification Performance by Doctrine", bold: true, italics: true, font: "Times New Roman", size: 22 })], spacing: { before: 250, after: 120 } }),
            new Table({
                width: { size: 100, type: WidthType.PERCENTAGE },
                rows: [
                    new TableRow({ children: [cellL("Doctrine", true), cell("N", true), cell("Best Model", true), cell("AUC", true), cell("Accuracy", true)] }),
                    new TableRow({ children: [cellL("DJ Jurisdiction"), cell("239"), cell("Random Forest"), cell("0.906"), cell("84.5%")] }),
                    new TableRow({ children: [cellL("Doctrine of Equivalents"), cell("64"), cell("SVM"), cell("0.885"), cell("85.9%")] }),
                    new TableRow({ children: [cellL("Infringement"), cell("755"), cell("Random Forest"), cell("0.772"), cell("77.6%")] }),
                    new TableRow({ children: [cellL("Claim Construction"), cell("268"), cell("Logistic Reg."), cell("0.713"), cell("65.7%")] }),
                    new TableRow({ children: [cellL("Counterclaim"), cell("179"), cell("Logistic Reg."), cell("0.671"), cell("71.6%")] }),
                    new TableRow({ children: [cellL("Inequitable Conduct"), cell("94"), cell("SVM"), cell("0.662"), cell("68.2%")] }),
                ]
            }),
            pI("Note: All results are 5-fold stratified cross-validation means."),

            p("Declaratory judgment jurisdiction achieved the highest AUC (0.906), substantially exceeding prior legal prediction benchmarks. This reflects the relatively formulaic nature of Article III standing analysis, where courts apply established MedImmune factors with consistent terminology. Doctrine of equivalents achieved 0.885 AUC—remarkably high given the doctrine's fact-intensive reputation—suggesting that prosecution history estoppel and the function-way-result test create identifiable textual patterns."),
            p("Infringement (0.772 AUC) and claim construction (0.713 AUC) showed strong performance on larger samples. Counterclaim (0.671) and inequitable conduct (0.662) exhibited more modest predictability, potentially reflecting greater case-specific variation or evolving doctrinal standards."),

            h2("4.2 Calibration Analysis"),
            p("Table 3 presents accuracy at different confidence thresholds, demonstrating excellent calibration."),

            // TABLE 3
            new Paragraph({ children: [new TextRun({ text: "Table 3. Accuracy by Prediction Confidence Level", bold: true, italics: true, font: "Times New Roman", size: 22 })], spacing: { before: 250, after: 120 } }),
            new Table({
                width: { size: 100, type: WidthType.PERCENTAGE },
                rows: [
                    new TableRow({ children: [cellL("Confidence", true), cell("Infr. Acc.", true), cell("Infr. Cov.", true), cell("DJ Acc.", true), cell("DJ Cov.", true), cell("DOE Acc.", true), cell("DOE Cov.", true)] }),
                    new TableRow({ children: [cellL("≥ 0.6"), cell("79.8%"), cell("94.4%"), cell("87.7%"), cell("88.3%"), cell("85.0%"), cell("93.8%")] }),
                    new TableRow({ children: [cellL("≥ 0.7"), cell("83.6%"), cell("79.2%"), cell("91.8%"), cell("71.1%"), cell("87.5%"), cell("87.5%")] }),
                    new TableRow({ children: [cellL("≥ 0.8"), cell("90.5%"), cell("47.5%"), cell("94.3%"), cell("44.4%"), cell("92.3%"), cell("60.9%")] }),
                    new TableRow({ children: [cellL("≥ 0.9"), cell("95.2%"), cell("11.1%"), cell("96.9%"), cell("13.4%"), cell("100%"), cell("26.6%")] }),
                ]
            }),
            pI("Note: Acc. = Accuracy; Cov. = Coverage (% of cases meeting threshold)."),

            p("At the ≥0.8 confidence threshold, infringement predictions achieve 90.5% accuracy (47.5% coverage), DJ jurisdiction achieves 94.3% (44.4% coverage), and DOE achieves 92.3% (60.9% coverage). This calibration enables reliable decision support: practitioners can trust high-confidence predictions while recognizing that lower-confidence cases require careful human analysis."),

            new Paragraph({ children: [new PageBreak()] }),

            // 4.3 FEATURE IMPORTANCE
            h2("4.3 Feature Importance and Legal Reasoning"),
            p("Logistic regression coefficients reveal features driving predictions. For DJ jurisdiction, procedural terms dominate: 'patent' (+1.09), 'prior art' (+0.62) predict jurisdiction findings, while 'dismiss' (-0.89), 'jurisdiction' (-0.85), 'motion dismiss' (-0.61) predict dismissals. This alignment with legal procedure validates that the model captures meaningful reasoning patterns."),
            p("For infringement, 'willful infringement' (+1.38), 'willful' (+1.27), and 'willfulness' (+1.13) strongly predict infringement findings—logically, as willfulness analysis presupposes infringement. Company names also appear: certain brands predict infringement, certain generics predict non-infringement, likely capturing litigation histories rather than inherent characteristics."),
            p("For doctrine of equivalents, brand pharmaceutical companies (Syntex, Roche, Abbott) predict DOE findings, while generic companies (Torrent, Perrigo, Roxane) predict rejections. This pattern suggests systematic differences in how courts apply DOE depending on party identity—potentially reflecting claim drafting quality or prosecution history."),

            h2("4.4 Cross-Doctrine Independence"),
            p("We computed phi coefficients for doctrine pairs appearing in the same cases (n=472 cases with 2+ doctrines). All correlations were below 0.1, indicating substantial independence. Infringement vs. DOE (phi=0.094), infringement vs. inequitable conduct (phi=0.052), and infringement vs. claim construction (phi=0.016) show near-zero correlation. This independence suggests that pharmaceutical patent cases involve genuinely distinct legal questions rather than reflecting overall case 'quality' or judicial predisposition."),
            p("Notably, when DOE is found (n=42 cases), only 14.3% also have literal infringement—confirming that DOE serves as an alternative theory when literal infringement fails rather than a complement."),

            h2("4.5 Temporal Evolution"),
            p("We analyzed outcome rates across eras defined by major legal developments. Infringement findings declined from 26.6% (pre-2007) to 20.8% (2017+). More dramatically, DOE success declined from 82.6% to 46.2%—a 36 percentage point drop reflecting cumulative restrictions through prosecution history estoppel, the all-elements rule, and dedication doctrine. That the model achieves high AUC despite this evolution indicates it captures doctrine-specific patterns rather than simple base rates."),

            new Paragraph({ children: [new PageBreak()] }),

            // 5. DISCUSSION
            h1("5. Discussion"),
            h2("5.1 What ML Models Learn About Legal Reasoning"),
            p("Our findings suggest that ML models capture meaningful patterns in legal reasoning rather than merely superficial correlations. Several observations support this interpretation. First, feature importance aligns with legal doctrine—procedural terms predict jurisdictional outcomes, willfulness terms predict infringement, prosecution history language predicts DOE rejections. Second, cross-doctrine independence indicates the model distinguishes between different legal questions rather than learning general case characteristics. Third, calibration analysis shows probability estimates are reliable, not merely discriminative."),
            p("However, the prominence of company names as predictors raises important considerations. Models may learn litigation histories—that certain companies tend to win or lose—rather than legal reasoning per se. This could perpetuate historical patterns rather than capture legal merit. Responsible deployment requires awareness of this limitation."),

            h2("5.2 Implications for Legal AI"),
            p("Our calibration analysis has direct implications for legal AI deployment. The finding that high-confidence predictions (≥0.8) achieve 90%+ accuracy suggests a responsible deployment strategy: use algorithmic predictions for high-confidence cases while flagging low-confidence cases for human review. This human-AI collaboration leverages computational efficiency for clear cases while preserving human judgment for difficult ones."),
            p("The variation in predictability across doctrines (0.66–0.91 AUC) suggests that legal AI should be doctrine-specific rather than one-size-fits-all. Jurisdictional questions may be highly suitable for algorithmic assistance, while inequitable conduct determinations may require more human judgment."),

            h2("5.3 Limitations"),
            p("Several limitations warrant acknowledgment. Sample sizes for some doctrines (DOE n=64, inequitable conduct n=94) limit statistical power. Label extraction via pattern matching may introduce measurement error. We analyze decided cases, which differ from settled disputes. The prominence of company effects raises questions about what the model truly learns."),

            h1("6. Conclusion"),
            p("This study demonstrates that machine learning models can achieve substantial predictive accuracy (AUC 0.66–0.91) across six distinct legal doctrines in pharmaceutical patent litigation. Calibration analysis shows high-confidence predictions achieve 90%+ accuracy, enabling reliable decision support. Feature importance aligns with legal doctrine, and cross-doctrine independence (phi < 0.1) indicates models capture doctrine-specific reasoning patterns. These findings advance computational legal studies by demonstrating that ML can capture meaningful aspects of legal reasoning while calibration analysis enables responsible deployment complementing human judgment."),

            new Paragraph({ children: [new PageBreak()] }),

            // REFERENCES
            h1("References"),
            p("Aletras, N., et al. (2016). Predicting judicial decisions of the European Court of Human Rights. PeerJ Computer Science, 2, e93.", 120),
            p("Ashley, K. D. (1990). Modeling Legal Argument. MIT Press.", 120),
            p("Gardner, A. (1987). An Artificial Intelligence Approach to Legal Reasoning. MIT Press.", 120),
            p("Katz, D. M., et al. (2017). A general approach for predicting the behavior of the Supreme Court. PLoS ONE, 12(4), e0174698.", 120),
            p("Levi, E. H. (1949). An Introduction to Legal Reasoning. University of Chicago Press.", 120),
            p("Sunstein, C. R. (1996). Legal Reasoning and Political Conflict. Oxford University Press.", 120),
        ]
    }]
});

Packer.toBuffer(doc).then(buffer => {
    fs.writeFileSync('/mnt/user-data/outputs/AI_Law_Paper_UPDATED.docx', buffer);
    console.log('Created: AI_Law_Paper_UPDATED.docx');
});
