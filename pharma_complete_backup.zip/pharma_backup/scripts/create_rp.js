const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, 
        HeadingLevel, BorderStyle, WidthType, ShadingType, AlignmentType,
        PageBreak, Footer, PageNumber } = require('docx');
const fs = require('fs');

const p = (text, spacing = 200) => new Paragraph({ 
    children: [new TextRun({ text, font: "Times New Roman", size: 24 })],
    spacing: { after: spacing, line: 360 }, alignment: AlignmentType.JUSTIFIED
});
const pI = (text) => new Paragraph({ 
    children: [new TextRun({ text, font: "Times New Roman", size: 22, italics: true })],
    spacing: { after: 150 }
});
const h1 = (text) => new Paragraph({
    heading: HeadingLevel.HEADING_1,
    children: [new TextRun({ text, bold: true, font: "Times New Roman", size: 28 })],
    spacing: { before: 400, after: 200 }
});
const h2 = (text) => new Paragraph({
    heading: HeadingLevel.HEADING_2,
    children: [new TextRun({ text, bold: true, font: "Times New Roman", size: 26 })],
    spacing: { before: 300, after: 150 }
});

const border = { style: BorderStyle.SINGLE, size: 1, color: "666666" };
const borders = { top: border, bottom: border, left: border, right: border };
const cell = (text, header = false, width = 1500) => new TableCell({
    borders, width: { size: width, type: WidthType.DXA },
    shading: header ? { fill: "D9E2F3", type: ShadingType.CLEAR } : undefined,
    margins: { top: 50, bottom: 50, left: 80, right: 80 },
    children: [new Paragraph({ children: [new TextRun({ text, bold: header, font: "Times New Roman", size: 20 })], alignment: AlignmentType.CENTER })]
});
const cellL = (text, header = false, width = 2800) => new TableCell({
    borders, width: { size: width, type: WidthType.DXA },
    shading: header ? { fill: "D9E2F3", type: ShadingType.CLEAR } : undefined,
    margins: { top: 50, bottom: 50, left: 80, right: 80 },
    children: [new Paragraph({ children: [new TextRun({ text, bold: header, font: "Times New Roman", size: 20 })] })]
});

const doc = new Document({
    styles: { default: { document: { run: { font: "Times New Roman", size: 24 } } } },
    sections: [{
        properties: {
            page: { size: { width: 12240, height: 15840 }, margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } }
        },
        footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ children: [PageNumber.CURRENT], font: "Times New Roman", size: 22 })] })] }) },
        children: [
            // TITLE
            new Paragraph({ spacing: { after: 400 } }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Pharmaceutical Patent Litigation as a Window", bold: true, font: "Times New Roman", size: 32 })], spacing: { after: 100 } }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "into Innovation Dynamics", bold: true, font: "Times New Roman", size: 32 })], spacing: { after: 500 } }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "[Author Names]", font: "Times New Roman", size: 24 })], spacing: { after: 80 } }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "[Institutional Affiliations]", font: "Times New Roman", size: 24 })], spacing: { after: 300 } }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Working Paper — January 2026", italics: true, font: "Times New Roman", size: 24 })], spacing: { after: 80 } }),
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Target Journal: Research Policy", italics: true, font: "Times New Roman", size: 24 })], spacing: { after: 500 } }),

            // ABSTRACT
            new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "ABSTRACT", bold: true, font: "Times New Roman", size: 24 })], spacing: { after: 200 } }),
            p("What can patent litigation reveal about pharmaceutical innovation? This paper argues that the patterns, doctrines, and outcomes of patent disputes provide a window into the dynamics of drug discovery and development. We develop a theoretical framework positing that litigation functions as an information revelation mechanism: adversarial proceedings with billions of dollars at stake compel sophisticated parties to surface information about patent quality, innovation character, and market entry strategies that would otherwise remain private."),
            p("Using comprehensive text analytics on 1,400 federal court decisions spanning 1995–2025, we examine what litigation patterns suggest about pharmaceutical R&D. Our analysis reveals several findings with innovation policy implications. First, temporal trends show declining infringement findings (26.6% to 20.8%) and dramatically declining doctrine of equivalents success (82.6% to 46.2%), indicating that courts are progressively narrowing patent scope—potentially affecting innovation incentives. Second, company-level analysis reveals substantial variation in win rates (13 percentage point spreads for both brands and generics), suggesting that patent portfolio quality and litigation strategy vary systematically across firms. Third, cross-doctrine independence (phi < 0.1) indicates that validity, infringement, and enforceability are genuinely distinct dimensions of patent quality, not reflections of overall patent 'strength.'"),
            p("Machine learning classification achieves 0.66–0.91 AUC across six doctrines, demonstrating that litigation outcomes are substantially predictable from case text. This predictability has policy implications: if outcomes are foreseeable, the information generated by litigation could potentially be obtained through less costly mechanisms. We discuss implications for patent examination, innovation incentives, and the design of pharmaceutical patent policy."),
            p("Keywords: Pharmaceutical innovation; Patent litigation; Text analytics; Innovation policy; Hatch-Waxman; Generic drugs; Patent quality; Doctrinal evolution"),

            new Paragraph({ children: [new PageBreak()] }),

            // 1. INTRODUCTION
            h1("1. Introduction"),
            p("Patent litigation is typically studied as a legal phenomenon—disputes over claim scope, validity doctrines, and infringement standards resolved through adversarial proceedings. But pharmaceutical patent litigation offers something more: a potential window into how the drug discovery and development system actually functions. This paper develops a theoretical framework for extracting innovation insights from litigation and applies comprehensive text analytics to 1,400 federal court decisions to examine what these disputes reveal about pharmaceutical R&D."),
            p("When branded manufacturers and generic challengers contest patents worth billions of dollars, they have powerful incentives to surface all relevant information about patent validity, claim scope, and competitive positioning. The adversarial process, with its discovery procedures, expert testimony, and judicial scrutiny, creates an information environment fundamentally different from patent prosecution or settlement negotiations. We argue that litigation outcomes reveal systematic features of pharmaceutical patents that have implications for innovation policy."),
            p("Our framework identifies three mechanisms connecting litigation to innovation. The selection mechanism examines which patents get challenged—reflecting what innovation produces. The argument mechanism analyzes litigation strategies—revealing systematic features of patent claims. The outcome mechanism studies judicial decisions—showing where doctrines create friction. By applying text analytics to a large corpus of decisions, we can identify patterns invisible in individual cases."),

            h2("1.2 Research Questions"),
            p("We address four questions at the intersection of innovation studies and patent law: (1) How have litigation outcomes evolved over three decades, and what do trends reveal about changing innovation and patent quality? (2) Do companies differ systematically in litigation success, suggesting variation in patent portfolio quality or litigation capability? (3) Are different patent dimensions (validity, infringement, enforceability) correlated, or do they represent independent aspects of patent quality? (4) How predictable are litigation outcomes, and what does predictability imply for patent policy?"),

            new Paragraph({ children: [new PageBreak()] }),

            // 2. THEORETICAL FRAMEWORK
            h1("2. Theoretical Framework"),
            h2("2.1 Litigation as Information Revelation"),
            p("We conceptualize pharmaceutical patent litigation as an information revelation mechanism. The adversarial system creates powerful incentives for parties to identify and present all relevant information. With outcomes worth hundreds of millions of dollars, litigants invest heavily in discovery, expert analysis, and legal research. The resulting judicial opinions synthesize this information, providing detailed analysis of patent scope, validity, and infringement that would not otherwise be publicly available."),
            p("This perspective suggests that litigation outcomes reveal aspects of patent quality and innovation character. When courts frequently find obviousness, it may indicate that patents reflect incremental rather than breakthrough innovation. When doctrine of equivalents claims decline, it suggests narrowing patent scope. When certain companies consistently win or lose, it reveals systematic differences in patent portfolios or litigation strategies."),

            h2("2.2 Three Mechanisms"),
            p("Selection Mechanism: Which patents get challenged reflects what pharmaceutical innovation produces. If incremental modifications dominate, we expect frequent obviousness challenges. If claim drafting is aggressive, we expect claim construction disputes. Litigation selection thus reveals innovation character."),
            p("Argument Mechanism: How parties frame disputes reveals systematic patent features. The arguments and evidence presented—prosecution history, prior art, technical experts—illuminate what makes patents strong or weak. Patterns in arguments across cases reveal systematic features of pharmaceutical patents."),
            p("Outcome Mechanism: Judicial decisions reveal where patent doctrines create friction with actual innovation. When courts narrow claim scope, it affects innovation incentives. When validity challenges succeed or fail, it signals patent quality. Outcome patterns illuminate the functioning of the patent system."),

            new Paragraph({ children: [new PageBreak()] }),

            // 3. DATA AND METHODS
            h1("3. Data and Methods"),
            h2("3.1 Corpus Construction"),
            p("We constructed a corpus of 1,400 pharmaceutical patent decisions from federal courts spanning 1995–2025. Cases were identified through Westlaw searches combining pharmaceutical terminology with patent litigation indicators. After filtering for substantive patent decisions and deduplication, we extracted full text and applied regular expression patterns to identify doctrine-specific outcomes across six dimensions: infringement, claim construction, declaratory judgment jurisdiction, doctrine of equivalents, inequitable conduct, and counterclaim success."),

            h2("3.2 Text Analytics Approach"),
            p("We employed multiple text analytics methods: (1) Pattern extraction for outcome coding across six doctrines. (2) Temporal analysis dividing cases into four eras based on major legal developments: Pre-KSR (<2007), Post-KSR (2007–2010), Post-Therasense (2011–2016), and Recent (2017+). (3) Company-level analysis examining win rates for firms appearing in 15+ cases. (4) Cross-doctrine correlation analysis computing phi coefficients for doctrine pairs. (5) Machine learning classification using TF-IDF features and multiple algorithms."),

            // TABLE 1
            new Paragraph({ children: [new TextRun({ text: "Table 1. Corpus Overview by Doctrine", bold: true, italics: true, font: "Times New Roman", size: 22 })], spacing: { before: 250, after: 120 } }),
            new Table({
                width: { size: 100, type: WidthType.PERCENTAGE },
                rows: [
                    new TableRow({ children: [cellL("Doctrine", true), cell("N", true), cell("Positive", true), cell("Negative", true), cell("% Positive", true)] }),
                    new TableRow({ children: [cellL("Infringement"), cell("755"), cell("185"), cell("570"), cell("24.5%")] }),
                    new TableRow({ children: [cellL("Claim Construction"), cell("268"), cell("133"), cell("135"), cell("49.6%")] }),
                    new TableRow({ children: [cellL("DJ Jurisdiction"), cell("239"), cell("89"), cell("150"), cell("37.2%")] }),
                    new TableRow({ children: [cellL("Counterclaim"), cell("179"), cell("134"), cell("45"), cell("74.9%")] }),
                    new TableRow({ children: [cellL("Inequitable Conduct"), cell("94"), cell("60"), cell("34"), cell("63.8%")] }),
                    new TableRow({ children: [cellL("Doctrine of Equivalents"), cell("64"), cell("47"), cell("17"), cell("73.4%")] }),
                ]
            }),
            pI("Note: Positive indicates outcome favoring patent holder (infringement found, DOE applies, etc.)."),

            new Paragraph({ children: [new PageBreak()] }),

            // 4. RESULTS
            h1("4. Results"),
            h2("4.1 Temporal Trends: Narrowing Patent Scope"),
            p("Table 2 presents outcome rates across four eras, revealing systematic trends with innovation policy implications."),

            // TABLE 2
            new Paragraph({ children: [new TextRun({ text: "Table 2. Outcome Rates by Era", bold: true, italics: true, font: "Times New Roman", size: 22 })], spacing: { before: 250, after: 120 } }),
            new Table({
                width: { size: 100, type: WidthType.PERCENTAGE },
                rows: [
                    new TableRow({ children: [cellL("Era", true), cell("N Cases", true), cell("Infr. Rate", true), cell("DOE Rate", true)] }),
                    new TableRow({ children: [cellL("Era 1: Pre-KSR (<2007)"), cell("290"), cell("26.6%"), cell("82.6%")] }),
                    new TableRow({ children: [cellL("Era 2: Post-KSR (2007–2010)"), cell("211"), cell("24.6%"), cell("—")] }),
                    new TableRow({ children: [cellL("Era 3: Post-Therasense (2011–2016)"), cell("411"), cell("22.5%"), cell("—")] }),
                    new TableRow({ children: [cellL("Era 4: Recent (2017+)"), cell("337"), cell("20.8%"), cell("46.2%")] }),
                ]
            }),
            pI("Note: DOE rates shown only for eras with n≥10 cases."),

            p("Two trends stand out. First, infringement findings declined steadily from 26.6% to 20.8%—a 5.8 percentage point drop. This suggests that courts are construing claims more narrowly or that generic companies have become more adept at designing around patents. Either interpretation has innovation implications: narrower claims reduce appropriability, potentially affecting R&D incentives."),
            p("Second, doctrine of equivalents success declined dramatically from 82.6% to 46.2%—a 36 percentage point drop. This reflects cumulative restrictions through prosecution history estoppel, the all-elements rule, and dedication doctrine. The practical elimination of DOE as a viable infringement theory substantially narrows effective patent scope, with significant implications for pharmaceutical innovation incentives."),

            h2("4.2 Company-Level Variation: Patent Portfolio Quality"),
            p("Table 3 presents win rates for companies appearing in 15+ infringement cases, revealing substantial variation."),

            // TABLE 3
            new Paragraph({ children: [new TextRun({ text: "Table 3. Company Win Rates in Infringement Cases", bold: true, italics: true, font: "Times New Roman", size: 22 })], spacing: { before: 250, after: 120 } }),
            new Table({
                width: { size: 100, type: WidthType.PERCENTAGE },
                rows: [
                    new TableRow({ children: [cellL("Brand Company", true), cell("N", true), cell("Win %", true), cellL("Generic Company", true), cell("N", true), cell("Win %", true)] }),
                    new TableRow({ children: [cellL("AstraZeneca"), cell("126"), cell("30.2%"), cellL("Sandoz"), cell("200"), cell("82.0%")] }),
                    new TableRow({ children: [cellL("Johnson & Johnson"), cell("159"), cell("30.2%"), cellL("Amneal"), cell("58"), cell("79.3%")] }),
                    new TableRow({ children: [cellL("Lilly"), cell("184"), cell("29.9%"), cellL("Barr"), cell("292"), cell("78.8%")] }),
                    new TableRow({ children: [cellL("Novartis"), cell("108"), cell("28.7%"), cellL("Teva"), cell("368"), cell("75.0%")] }),
                    new TableRow({ children: [cellL("Bayer"), cell("111"), cell("17.1%"), cellL("Lupin"), cell("86"), cell("68.6%")] }),
                ]
            }),
            pI("Note: Brand win % = infringement findings; Generic win % = non-infringement findings."),

            p("Brand companies show a 13 percentage point spread (17.1% to 30.2%); generic companies show a similar 13 percentage point spread (68.6% to 82.0%). This variation suggests systematic differences in patent portfolio quality, claim drafting practices, or litigation strategy. For innovation policy, it indicates that patent protection is not uniform—some firms achieve substantially stronger protection than others."),

            h2("4.3 Cross-Doctrine Independence: Dimensions of Patent Quality"),
            p("We computed phi coefficients for doctrine pairs appearing in the same cases (n=472 cases with 2+ doctrines). All correlations were below 0.1, indicating substantial independence. Infringement vs. claim construction (phi=0.016), infringement vs. DOE (phi=0.094), and infringement vs. inequitable conduct (phi=0.052) show near-zero correlation."),
            p("This independence has important implications for understanding patent quality. Validity, infringement, and enforceability are genuinely distinct dimensions—a patent can be valid but not infringed, infringed but unenforceable, or any combination. This multidimensionality suggests that patent quality is not a single construct but a collection of independent attributes, complicating both patent examination and litigation strategy."),

            h2("4.4 Predictability and Policy Implications"),
            p("Machine learning models achieve 0.66–0.91 AUC across doctrines, with DJ jurisdiction (0.91) and DOE (0.89) most predictable. High predictability raises a policy question: if outcomes are substantially foreseeable from case text, could the information generated by litigation be obtained through less costly mechanisms? The 90%+ accuracy at high-confidence thresholds suggests that much uncertainty could be resolved without full litigation."),

            new Paragraph({ children: [new PageBreak()] }),

            // 5. DISCUSSION
            h1("5. Discussion"),
            h2("5.1 Implications for Innovation Policy"),
            p("Our findings have several implications for pharmaceutical innovation policy. First, the temporal narrowing of patent scope—declining infringement rates and collapsing DOE—suggests that effective patent protection has diminished over three decades. If appropriability is essential for pharmaceutical R&D incentives, this trend warrants policy attention."),
            p("Second, company-level variation indicates that the patent system does not provide uniform protection. Some firms achieve 30% infringement success rates while others achieve 17%. This variation could reflect differences in innovation quality, but could also reflect litigation capability, claim drafting skill, or strategic behavior. Policy should consider whether such variation is desirable."),
            p("Third, cross-doctrine independence suggests that patent quality is multidimensional. Patent examination focuses primarily on validity (novelty, obviousness, disclosure), but our analysis shows that infringement and enforceability outcomes are uncorrelated with validity outcomes. This suggests that examination could be expanded to consider claim scope and enforcement likelihood."),

            h2("5.2 Limitations"),
            p("Several limitations warrant acknowledgment. We observe litigated cases, not all patents—selection into litigation may not be random. Company effects may reflect case selection rather than patent quality. Temporal trends may reflect legal evolution rather than innovation change. Despite these limitations, the patterns we identify are consistent and substantial."),

            h1("6. Conclusion"),
            p("This paper demonstrates that pharmaceutical patent litigation provides a window into innovation dynamics. Temporal analysis reveals narrowing patent scope with potential implications for innovation incentives. Company analysis shows substantial variation in patent protection. Cross-doctrine analysis indicates that patent quality is multidimensional. Predictability analysis suggests that much litigation uncertainty could be resolved through less costly mechanisms. These findings contribute to understanding the relationship between the patent system and pharmaceutical innovation."),

            new Paragraph({ children: [new PageBreak()] }),

            // REFERENCES
            h1("References"),
            p("Grabowski, H., & Kyle, M. (2007). Generic competition and market exclusivity in pharmaceuticals. Managerial and Decision Economics, 28(4-5), 491-502.", 120),
            p("Hemphill, C. S., & Sampat, B. N. (2012). Evergreening, patent challenges, and effective market life. Journal of Health Economics, 31(2), 327-339.", 120),
            p("Lemley, M. A., & Shapiro, C. (2005). Probabilistic patents. Journal of Economic Perspectives, 19(2), 75-98.", 120),
        ]
    }]
});

Packer.toBuffer(doc).then(buffer => {
    fs.writeFileSync('/mnt/user-data/outputs/Research_Policy_UPDATED.docx', buffer);
    console.log('Created: Research_Policy_UPDATED.docx');
});
