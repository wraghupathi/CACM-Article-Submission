"""
=============================================================================
PRODUCT LIABILITY & MASS TORTS — ONE-PASS FROZEN ANALYSIS
Gabelli School of Business, Fordham University  |  April 2026
=============================================================================
Stages 1–8  (Stage 7 DiD and Legal-BERT deferred to Colab)
SEED = 42 throughout. Run once. Outputs hashed in s8_manifest.json.
=============================================================================
"""
import os, re, json, hashlib, warnings
import numpy as np
import pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from datetime import datetime
from collections import Counter
import joblib

warnings.filterwarnings('ignore')

SEED = 42
np.random.seed(SEED)
CORPUS = Path("/mnt/user-data/outputs/pl_corpus_full.json")
OUT    = Path("/mnt/user-data/outputs/analysis")
OUT.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({'figure.dpi':150,'savefig.dpi':150,'font.size':10,
    'axes.titlesize':12,'figure.facecolor':'white','axes.facecolor':'#F8F9FA'})
PAL = ['#1F4E79','#2E75B6','#70AD47','#ED7D31','#FFC000',
       '#7030A0','#C00000','#00B0F0','#92D050','#FF0000']
manifest = {}

def _sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for c in iter(lambda:f.read(8192),b''): h.update(c)
    return h.hexdigest()
def _ts(): return datetime.utcnow().isoformat()
def sfig(name):
    p=OUT/name; plt.savefig(p,bbox_inches='tight',dpi=150); plt.close('all')
    manifest[name]={"sha256":_sha(p),"ts":_ts(),"type":"figure"}; print(f"  + {name}")
def sjson(name,obj,params=None):
    p=OUT/name
    with open(p,'w') as f: json.dump(obj,f,indent=2,default=str)
    manifest[name]={"sha256":_sha(p),"ts":_ts(),"type":"json","params":params or {}}; print(f"  + {name}")
def scsv(name,df_):
    p=OUT/name; df_.to_csv(p,index=False)
    manifest[name]={"sha256":_sha(p),"ts":_ts(),"type":"csv"}; print(f"  + {name}")

LEGAL_SW={'plaintiff','defendant','court','judge','affirmed','reversed','remanded',
    'appellant','appellee','petitioner','respondent','v','vs','et','al','mr','ms',
    'dr','inc','llc','corp','ltd','co','also','upon','would','may','shall','must',
    'said','case','cases','action','claim','claims','order','motion','trial',
    'appeal','judgment','held','finding','found','pursuant','herein','thereof',
    'therein','hereby','whether','within','without','however','therefore',
    'although','because','since','thus','further','first','second','third',
    'one','two','three','per','see','id','use','used','using'}

# =============================================================================
# STAGE 1  LOAD
# =============================================================================
print("\n"+"="*60+"\nSTAGE 1  LOAD\n"+"="*60)
with open(CORPUS) as f: raw=json.load(f)
df=pd.DataFrame([{k:v for k,v in r.items() if k!='text'} for r in raw])
TC=list(raw[0]['theories'].keys())
for col in TC: df[col]=df['theories'].apply(lambda x:int(x.get(col,0)))
df.drop(columns=['theories'],inplace=True)
texts={r['case_id']:r['text'] for r in raw}
CID=list(df['case_id']); ALL=[texts[c] for c in CID]
print(f"  n={len(df)}  orig={int((df.source=='original').sum())}  new={int((df.source=='new').sum())}")
print(f"  years {int(df.year.min())}–{int(df.year.max())}")
sjson("s1_validation.json",{"n":len(df),"n_orig":int((df.source=='original').sum()),
    "n_new":int((df.source=='new').sum()),"year_min":int(df.year.min()),
    "year_max":int(df.year.max()),"input_sha256":_sha(CORPUS)})

# =============================================================================
# STAGE 2  OUTCOME RECODE
# =============================================================================
print("\n"+"="*60+"\nSTAGE 2  RECODE\n"+"="*60)
PEND=[r'\bpending\b',r'\bstayed\b',r'\bcontinued\b',r'\bfurther proceedings\b',r'\bon remand\b']
REC=[('Affirmed',r"\baff[i]?rm(ed|s|ing)\b"),('Reversed',r"\brevers(ed|es|ing)\b"),
     ('Vacated',r"\bvacated\b"),('Remanded',r"\bremanded\b"),
     ('Dismissed',r"\bdismiss(ed|al|ing)\b"),('Settlement',r"\bsettl(ed|ement)\b"),
     ('Plaintiff Victory',r"\b(verdict|judgment).{0,40}plaintiff\b"),
     ('Defendant Victory',r"\b(summary judgment|judgment).{0,50}(granted|entered).{0,50}defendant\b")]
def recode(row):
    if row['outcome']!='Unknown': return row['outcome'],False
    s=texts[row['case_id']][:6000].lower()
    for p in PEND:
        if re.search(p,s): return 'Pending',True
    for label,p in REC:
        if re.search(p,s): return label,True
    return 'Unknown',False
res=df.apply(recode,axis=1,result_type='expand')
df['outcome_r']=res[0]; df['recoded']=res[1]
dist=df['outcome_r'].value_counts().to_dict()
for k,v in sorted(dist.items(),key=lambda x:-x[1]): print(f"    {k:<25} {v:>4}")
print(f"  Recoded:{df.recoded.sum()}  Pending:{(df.outcome_r=='Pending').sum()}  Unknown:{(df.outcome_r=='Unknown').sum()}")
sjson("s2_outcome_recode.json",{"distribution":dist,"recoded":int(df.recoded.sum()),
    "pending":int((df.outcome_r=='Pending').sum()),"unknown":int((df.outcome_r=='Unknown').sum())})

# =============================================================================
# STAGE 3  DESCRIPTIVE
# =============================================================================
print("\n"+"="*60+"\nSTAGE 3  DESCRIPTIVE\n"+"="*60)
# Fig 1 overview
fig,axes=plt.subplots(2,2,figsize=(14,10))
yr=(df['year'].dropna().astype(int)//10*10).value_counts().sort_index()
axes[0,0].bar(yr.index,yr.values,width=8,color=PAL[0],alpha=0.85)
axes[0,0].set_title('Cases by Decade')
pc=df['product_category'].value_counts()
axes[0,1].barh(pc.index[::-1],pc.values[::-1],color=PAL[1])
axes[0,1].set_title('Product Category')
cl=df['court_level'].value_counts()
axes[1,0].bar(range(len(cl)),cl.values,color=PAL[2])
axes[1,0].set_xticks(range(len(cl))); axes[1,0].set_xticklabels(cl.index,rotation=25,ha='right',fontsize=8)
axes[1,0].set_title('Court Level')
oc=df['outcome_r'].value_counts()
axes[1,1].pie(oc.values,labels=oc.index,autopct='%1.0f%%',colors=PAL[:len(oc)],textprops={'fontsize':7})
axes[1,1].set_title('Outcome Distribution')
plt.suptitle(f'Corpus Overview — {len(df)} Cases 1917–2026',fontsize=14,fontweight='bold')
sfig("s3_fig1_overview.png")
# Fig 2 jurisdiction+source
fig,axes=plt.subplots(1,2,figsize=(14,5))
jur=df['jurisdiction'].value_counts().head(12)
axes[0].barh(jur.index[::-1],jur.values[::-1],color=PAL[0]); axes[0].set_title('Top 12 Jurisdictions')
for i,(k,v) in enumerate(jur[::-1].items()): axes[0].text(v+1,i,f'{v/len(df)*100:.1f}%',va='center',fontsize=7)
src=df.groupby(['source','product_category']).size().unstack(fill_value=0)
src.T.plot(kind='bar',ax=axes[1],color=[PAL[0],PAL[2]])
axes[1].set_title('Product by Source'); axes[1].legend(['Orig','New']); axes[1].tick_params(axis='x',rotation=30)
sfig("s3_fig2_jurisdiction.png")
# Fig 3 theory heatmap
fig,axes=plt.subplots(1,2,figsize=(15,5))
tr=df[TC].mean().sort_values()
axes[0].barh(tr.index,tr.values*100,color=PAL[1]); axes[0].set_title('Theory Prevalence (%)')
for i,(k,v) in enumerate(tr.items()): axes[0].text(v*100+.5,i,f'{v*100:.0f}%',va='center',fontsize=7)
pt=df.groupby('product_category')[TC].mean()
sns.heatmap(pt.T,annot=True,fmt='.2f',cmap='Blues',ax=axes[1],linewidths=0.3,annot_kws={'size':6})
axes[1].set_title('Theory × Product'); axes[1].tick_params(axis='x',rotation=30,labelsize=7)
sfig("s3_fig3_theory_heatmap.png")
# Fig 4 temporal
fig,axes=plt.subplots(1,2,figsize=(14,5))
df_y=df[df.year.notna()].copy(); df_y['decade']=(df_y['year']//10*10).astype(int)
top6=df['product_category'].value_counts().head(6).index
pt2=df_y[df_y.product_category.isin(top6)].groupby(['decade','product_category']).size().unstack(fill_value=0)
pt2.plot(ax=axes[0],marker='o',colormap='tab10'); axes[0].set_title('Product by Decade'); axes[0].legend(fontsize=7,loc='upper left')
kt=['negligence','strict_liability','design_defect','failure_to_warn','federal_preemption','daubert']
pt3=df_y.groupby('decade')[kt].mean()*100
pt3.plot(ax=axes[1],marker='s',colormap='Set1'); axes[1].set_title('Theory Trends by Decade (%)'); axes[1].legend(fontsize=7)
sfig("s3_fig4_temporal.png")
# Fig 5 wordcount+damages
fig,axes=plt.subplots(1,2,figsize=(12,4))
axes[0].hist(df['word_count'],bins=40,color=PAL[0],edgecolor='white')
axes[0].axvline(df.word_count.median(),color='red',ls='--',label=f'Median:{df.word_count.median():,.0f}')
axes[0].set_title('Word Count'); axes[0].legend()
dam=df['max_dollar_amount'].dropna(); dam=np.log10(dam[dam>0])
axes[1].hist(dam,bins=30,color=PAL[2],edgecolor='white')
axes[1].set_title(f'log10(Dollar Amount) n={len(dam)}'); axes[1].set_xlabel('log10 USD')
sfig("s3_fig5_wordcount_damages.png")
sjson("s3_descriptive_stats.json",{
    "n_total":len(df),"n_original":int((df.source=='original').sum()),"n_new":int((df.source=='new').sum()),
    "year_min":int(df.year.min()),"year_max":int(df.year.max()),
    "word_count_mean":round(float(df.word_count.mean()),1),"word_count_median":round(float(df.word_count.median()),1),
    "n_with_dollars":int(df.max_dollar_amount.notna().sum()),
    "ma_pct":round(float((df.jurisdiction=='Massachusetts').mean()*100),1),
    "federal_circuit_pct":round(float((df.court_level=='Federal Circuit').mean()*100),1),
    "outcome_distribution":dist,"product_distribution":df.product_category.value_counts().to_dict(),
    "jurisdiction_top10":df.jurisdiction.value_counts().head(10).to_dict(),
    "court_level_distribution":df.court_level.value_counts().to_dict(),
    "theory_prevalence":{c:round(float(df[c].mean()*100),1) for c in TC}})
print("  Stage 3 complete.")

# =============================================================================
# STAGE 4  NLP
# =============================================================================
print("\n"+"="*60+"\nSTAGE 4  NLP\n"+"="*60)
from sklearn.feature_extraction.text import TfidfVectorizer,CountVectorizer
from sklearn.decomposition import LatentDirichletAllocation,NMF,TruncatedSVD
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.manifold import TSNE
from sklearn.preprocessing import normalize,StandardScaler
from sklearn.metrics.pairwise import cosine_similarity
import textstat

# 4a TF-IDF 10K
print("\n  4a TF-IDF...")
tf10=TfidfVectorizer(max_features=10000,ngram_range=(1,2),sublinear_tf=True,
                     min_df=3,max_df=0.85,stop_words=list(LEGAL_SW))
X10=tf10.fit_transform(ALL); FN10=np.array(tf10.get_feature_names_out())
print(f"     {X10.shape}")
joblib.dump(tf10,OUT/"s4a_tfidf10k.pkl")
manifest["s4a_tfidf10k.pkl"]={"sha256":_sha(OUT/"s4a_tfidf10k.pkl"),"ts":_ts(),"type":"model"}
dist_t={}
for cat in df['product_category'].unique():
    mask=(df['product_category']==cat).values
    if mask.sum()<5: continue
    cm=np.asarray(X10[mask].mean(axis=0)).flatten()
    om=np.asarray(X10[~mask].mean(axis=0)).flatten()
    rat=cm/(om+1e-9); top=np.argsort(rat)[::-1][:15]
    dist_t[cat]=[{"term":FN10[i],"ratio":round(float(rat[i]),1)} for i in top]
fig,axes=plt.subplots(2,3,figsize=(15,8))
for ax,cat in zip(axes.flatten(),df['product_category'].value_counts().head(6).index):
    mask=(df['product_category']==cat).values
    cm=np.asarray(X10[mask].mean(axis=0)).flatten(); top=np.argsort(cm)[::-1][:15]
    ax.barh([FN10[i] for i in top[::-1]],[cm[i] for i in top[::-1]],color=PAL[0])
    ax.set_title(f'{cat} (n={mask.sum()})',fontsize=8); ax.tick_params(labelsize=7)
plt.suptitle('Top TF-IDF Terms by Product Category',fontsize=13,fontweight='bold')
sfig("s4a_fig_tfidf_terms.png")
sjson("s4a_tfidf_distinctive_terms.json",dist_t,params={"max_features":10000,"ngram_range":"(1,2)"})

# 4b LDA
print("\n  4b LDA...")
cv5=CountVectorizer(max_features=5000,ngram_range=(1,2),min_df=3,max_df=0.85,stop_words=list(LEGAL_SW))
Xcnt=cv5.fit_transform(ALL); FN5=np.array(cv5.get_feature_names_out())
lda_sc,lda_md={},{}
for k in [8,10,12,15]:
    m=LatentDirichletAllocation(n_components=k,random_state=SEED,learning_method='online',max_iter=50,batch_size=128)
    m.fit(Xcnt); lda_sc[k]=m.perplexity(Xcnt); lda_md[k]=m
    print(f"     k={k}  perp={lda_sc[k]:.1f}")
BK=min(lda_sc,key=lda_sc.get); print(f"     Best k={BK}")
lda=lda_md[BK]; X_lda=lda.transform(Xcnt)
joblib.dump(lda,OUT/"s4b_lda_model.pkl")
manifest["s4b_lda_model.pkl"]={"sha256":_sha(OUT/"s4b_lda_model.pkl"),"ts":_ts(),"type":"model","params":{"k":BK,"seed":SEED}}
lda_t={}
for tid,comp in enumerate(lda.components_):
    top=FN5[np.argsort(comp)[::-1][:12]]; lda_t[f"T{tid}"]=list(top)
    print(f"     LDA T{tid:2d}: {', '.join(top[:6])}")
fig,axes=plt.subplots(1,2,figsize=(14,5))
axes[0].plot(list(lda_sc.keys()),list(lda_sc.values()),marker='o',color=PAL[0],lw=2)
axes[0].axvline(BK,color='red',ls='--',label=f'Best k={BK}'); axes[0].legend()
axes[0].set_title('LDA Perplexity'); axes[0].set_xlabel('k')
tc=pd.DataFrame(X_lda,columns=[f"T{i}" for i in range(BK)]); tc['product_category']=df['product_category'].values
sns.heatmap(tc.groupby('product_category').mean().T,cmap='YlOrRd',ax=axes[1],linewidths=0.3)
axes[1].set_title('LDA Topic × Product'); axes[1].tick_params(axis='x',rotation=30,labelsize=7)
sfig("s4b_fig_lda.png")
sjson("s4b_lda_topics.json",{"best_k":BK,"perplexity_scores":{str(k):round(v,1) for k,v in lda_sc.items()},"topics":lda_t},params={"seed":SEED})

# 4c NMF
print(f"\n  4c NMF (k={BK}, random init)...")
nmf=NMF(n_components=BK,random_state=SEED,init='random',max_iter=1000)
X_nmf=nmf.fit_transform(X10); X_nmfn=X_nmf/(X_nmf.sum(axis=1,keepdims=True)+1e-9)
joblib.dump(nmf,OUT/"s4c_nmf_model.pkl")
manifest["s4c_nmf_model.pkl"]={"sha256":_sha(OUT/"s4c_nmf_model.pkl"),"ts":_ts(),"type":"model","params":{"k":BK,"seed":SEED,"init":"random"}}
nmf_t={}
for tid,comp in enumerate(nmf.components_):
    top=FN10[np.argsort(comp)[::-1][:12]]; nmf_t[f"T{tid}"]=list(top)
    print(f"     NMF T{tid:2d}: {', '.join(top[:6])}")
fig,axes=plt.subplots(1,2,figsize=(14,5))
tnc=pd.DataFrame(X_nmfn,columns=[f"N{i}" for i in range(BK)]); tnc['product_category']=df['product_category'].values
sns.heatmap(tnc.groupby('product_category').mean().T,cmap='Blues',ax=axes[0],linewidths=0.3)
axes[0].set_title('NMF Topic × Product'); axes[0].tick_params(axis='x',rotation=30,labelsize=7)
rows=[f"T{i}: {', '.join(nmf_t[f'T{i}'][:4])}" for i in range(min(8,BK))]
axes[1].barh(range(len(rows)),[1]*len(rows),color=PAL[:len(rows)])
axes[1].set_yticks(range(len(rows))); axes[1].set_yticklabels(rows,fontsize=8)
axes[1].set_title('NMF Topics (first 8)'); axes[1].set_xticks([])
sfig("s4c_fig_nmf.png")
sjson("s4c_nmf_topics.json",{"k":BK,"topics":nmf_t},params={"seed":SEED,"init":"random"})
X_top=np.hstack([X_lda,X_nmfn]); print(f"     Topics matrix: {X_top.shape}")

# 4d K-Means
print("\n  4d K-Means...")
svd50=TruncatedSVD(n_components=50,random_state=SEED)
X_svd=svd50.fit_transform(X10); X_svdn=normalize(X_svd)
print(f"     SVD var explained: {svd50.explained_variance_ratio_.sum()*100:.1f}%")
sil={}
for k in [5,7,8,10,12,15]:
    lab=KMeans(n_clusters=k,random_state=SEED,n_init=10).fit_predict(X_svdn)
    sil[k]=silhouette_score(X_svdn,lab,sample_size=min(500,len(X_svdn)),random_state=SEED)
    print(f"     k={k}  sil={sil[k]:.4f}")
BKM=max(sil,key=sil.get); print(f"     Best k={BKM}")
df['cluster']=KMeans(n_clusters=BKM,random_state=SEED,n_init=10).fit_predict(X_svdn)
fig,axes=plt.subplots(1,2,figsize=(14,5))
axes[0].plot(list(sil.keys()),list(sil.values()),marker='o',color=PAL[0],lw=2)
axes[0].axvline(BKM,color='red',ls='--',label=f'Best k={BKM}'); axes[0].legend()
axes[0].set_title('K-Means Silhouette'); axes[0].set_xlabel('k')
sns.heatmap(pd.crosstab(df['cluster'],df['product_category']),cmap='Blues',ax=axes[1],
            linewidths=0.3,annot=True,fmt='d',annot_kws={'size':6})
axes[1].set_title('Cluster × Product'); axes[1].tick_params(axis='x',rotation=30,labelsize=7)
sfig("s4d_fig_kmeans.png")
sjson("s4d_kmeans_results.json",{"best_k":BKM,"silhouette_scores":{str(k):round(v,4) for k,v in sil.items()},
    "svd_var_explained":round(float(svd50.explained_variance_ratio_.sum()),4)},params={"seed":SEED})

# 4e t-SNE
print("\n  4e t-SNE...")
X_tsne=TSNE(n_components=2,perplexity=30,max_iter=1000,random_state=SEED,
            learning_rate='auto',init='pca').fit_transform(X_svdn)
np.save(OUT/"s4e_tsne_coords.npy",X_tsne)
manifest["s4e_tsne_coords.npy"]={"sha256":_sha(OUT/"s4e_tsne_coords.npy"),"ts":_ts(),"type":"array"}
fig,axes=plt.subplots(1,2,figsize=(16,6))
uc=sorted(df['product_category'].unique()); cm1=plt.cm.get_cmap('tab10',len(uc))
for i,cat in enumerate(uc):
    m=(df['product_category']==cat).values
    axes[0].scatter(X_tsne[m,0],X_tsne[m,1],c=[cm1(i)],label=cat,alpha=0.65,s=18,edgecolors='none')
axes[0].set_title('t-SNE — Product Category'); axes[0].legend(fontsize=7,bbox_to_anchor=(1.01,1),loc='upper left')
axes[0].set_xticks([]); axes[0].set_yticks([])
cm2=plt.cm.get_cmap('Set3',BKM)
for k in range(BKM):
    m=(df['cluster']==k).values
    axes[1].scatter(X_tsne[m,0],X_tsne[m,1],c=[cm2(k)],label=f'C{k}',alpha=0.65,s=18,edgecolors='none')
axes[1].set_title(f't-SNE — K-Means (k={BKM})'); axes[1].legend(fontsize=6,bbox_to_anchor=(1.01,1),loc='upper left',ncol=2)
axes[1].set_xticks([]); axes[1].set_yticks([])
sfig("s4e_fig_tsne.png")

# 4f N-grams
print("\n  4f N-grams...")
def top_ng(n,topk=20,min_df=5):
    v=CountVectorizer(ngram_range=(n,n),min_df=min_df,stop_words=list(LEGAL_SW),max_features=60000)
    X=v.fit_transform(ALL); s=np.asarray(X.sum(axis=0)).flatten(); f=np.array(v.get_feature_names_out())
    idx=np.argsort(s)[::-1][:topk]; return [(f[i],int(s[i])) for i in idx]
bg=top_ng(2,20,8); tg=top_ng(3,20,5)
fig,axes=plt.subplots(1,2,figsize=(15,6))
bt,bv=zip(*bg); axes[0].barh(list(bt)[::-1],list(bv)[::-1],color=PAL[0]); axes[0].set_title('Top 20 Bigrams')
tt,tv=zip(*tg); axes[1].barh(list(tt)[::-1],list(tv)[::-1],color=PAL[1]); axes[1].set_title('Top 20 Trigrams')
sfig("s4f_fig_ngrams.png")
sjson("s4f_ngrams.json",{"bigrams":bg,"trigrams":tg})

# 4g Doctrines
print("\n  4g Doctrines...")
DOCS={'Punitive Damages':r'\b(punitive|exemplary)\s+damages\b',
      'Proximate Cause':r'\bproximate\s+cause\b','Strict Liability/402A':r'\bstrict\s+liabilit|\b402[Aa]\b',
      'Economic Loss Rule':r'\beconomic\s+loss\s+rule\b','Joint & Several':r'\bjoint\s+and\s+several\b',
      'Comparative Fault':r'\b(comparative|contributory)\s+(fault|negligence)\b',
      'Discovery Rule':r'\bdiscovery\s+rule\b','Risk-Utility Test':r'\brisk.{0,5}utility\b',
      'Daubert Standard':r'\bdaubert\b','But-For Causation':r'\bbut.for\s+caus',
      'State of the Art':r'\bstate\s+of\s+the\s+art\b','Substantial Factor':r'\bsubstantial\s+factor\b',
      'Consumer Expectation':r'\bconsumer\s+expectation','Crashworthiness':r'\bcrashworthiness\b',
      'Federal Preemption':r'\b(federal\s+)?preemption\b','Successor Liability':r'\bsuccessor\s+liabilit',
      'Market Share':r'\bmarket\s+share\s+liabilit','Learned Intermediary':r'\blearned\s+intermediary\b',
      'Sophisticated User':r'\bsophisticated\s+user\b'}
doc_c={}; DOC_COLS=[]
for dname,pat in DOCS.items():
    flags=[int(bool(re.search(pat,t,re.I))) for t in ALL]; cnt=sum(flags)
    doc_c[dname]={"count":cnt,"pct":round(cnt/len(df)*100,1)}
    key="doc_"+re.sub(r'[^a-z]','_',dname.lower())[:18]; df[key]=flags; DOC_COLS.append(key)
fig,ax=plt.subplots(figsize=(10,7))
names=list(doc_c.keys()); pcts=[doc_c[n]['pct'] for n in names]; order=np.argsort(pcts)
ax.barh([names[i] for i in order],[pcts[i] for i in order],color=PAL[1])
ax.set_xlabel('% of Cases'); ax.set_title('Legal Doctrine Prevalence (566 Cases)')
for i,idx in enumerate(order): ax.text(pcts[idx]+.3,i,f'{pcts[idx]:.1f}%',va='center',fontsize=8)
sfig("s4g_fig_doctrines.png")
sjson("s4g_doctrine_prevalence.json",doc_c)

# 4h Readability
print("\n  4h Readability & tone...")
TONE={'certainty':['clearly','undoubtedly','manifestly','certainly','plainly'],
      'uncertainty':['arguably','potentially','questionable','uncertain','ambiguous'],
      'strong':['egregious','unconscionable','reckless','reprehensible','willful','wanton'],
      'critical':['failed','inadequate','misleading','deceptive','deficient','unreasonable']}
read_rows=[]
for cid,text in zip(CID,ALL):
    s=text[:5000]
    try: fk=textstat.flesch_kincaid_grade(s)
    except: fk=np.nan
    try: fog=textstat.gunning_fog(s)
    except: fog=np.nan
    wl=text.lower().split(); nw=max(len(wl),1)
    tone={k:sum(wl.count(w) for w in v)/nw*1000 for k,v in TONE.items()}
    read_rows.append({'case_id':cid,'fk_grade':fk,'gunning_fog':fog,**tone})
df_read=pd.DataFrame(read_rows); df=df.merge(df_read,on='case_id',how='left')
TONE_COLS=list(TONE.keys())
fig,axes=plt.subplots(2,2,figsize=(14,10))
axes[0,0].hist(df_read['fk_grade'].dropna(),bins=30,color=PAL[0],edgecolor='white')
axes[0,0].axvline(df_read['fk_grade'].median(),color='red',ls='--',label=f'Median:{df_read["fk_grade"].median():.1f}')
axes[0,0].set_title('FK Grade Level'); axes[0,0].legend()
axes[0,1].barh(*zip(*df.groupby('product_category')['fk_grade'].mean().sort_values().items()),color=PAL[1])
axes[0,1].set_title('Mean FK Grade by Product')
axes[1,0].barh(*zip(*df.groupby('product_category')['strong'].mean().sort_values().items()),color=PAL[3])
axes[1,0].set_title('Strong Language by Product (per 1K)')
co=df.groupby('outcome_r')['critical'].mean().sort_values()
axes[1,1].bar(range(len(co)),co.values,color=PAL[4]); axes[1,1].set_xticks(range(len(co)))
axes[1,1].set_xticklabels(co.index,rotation=25,ha='right',fontsize=8); axes[1,1].set_title('Critical Language by Outcome')
sfig("s4h_fig_readability.png")
scsv("s4h_readability_tone.csv",df_read)

# 4i Similarity
print("\n  4i Similarity...")
intra={}
for cat in df['product_category'].unique():
    idx=[i for i,c in enumerate(df['product_category'].values) if c==cat]
    if len(idx)<3: continue
    sm=cosine_similarity(X_svdn[idx]); np.fill_diagonal(sm,np.nan)
    intra[cat]=round(float(np.nanmean(sm)),4)
fig,ax=plt.subplots(figsize=(10,4))
cs=sorted(intra,key=intra.get)
ax.barh(cs,[intra[c] for c in cs],color=PAL[0])
ax.set_xlabel('Mean Cosine Similarity'); ax.set_title('Intra-Category Similarity (566 Cases)')
for i,c in enumerate(cs): ax.text(intra[c]+.001,i,f'{intra[c]:.3f}',va='center',fontsize=8)
sfig("s4i_fig_similarity.png")
sjson("s4i_similarity.json",intra)
print("  Stage 4 complete.")

# =============================================================================
# STAGE 5  ML
# =============================================================================
print("\n"+"="*60+"\nSTAGE 5  ML\n"+"="*60)
from sklearn.linear_model import LogisticRegression,Ridge,Lasso
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import LinearSVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import StratifiedKFold,KFold
from sklearn.metrics import roc_auc_score,roc_curve,confusion_matrix,accuracy_score,f1_score,r2_score,mean_absolute_error
from xgboost import XGBClassifier,XGBRegressor
from lightgbm import LGBMClassifier
import shap

# 5a Feature sets
print("\n  5a Feature sets...")
tf5=TfidfVectorizer(max_features=5000,ngram_range=(1,2),sublinear_tf=True,
                    min_df=3,max_df=0.85,stop_words=list(LEGAL_SW))
X_tfidf=tf5.fit_transform(ALL); FN5ML=tf5.get_feature_names_out()
joblib.dump(tf5,OUT/"s5a_tfidf5k_ml.pkl")
manifest["s5a_tfidf5k_ml.pkl"]={"sha256":_sha(OUT/"s5a_tfidf5k_ml.pkl"),"ts":_ts(),"type":"model"}

TONE_COLS=['fk_grade','gunning_fog','certainty','uncertainty','strong','critical']
eng_base=df[TC+DOC_COLS+TONE_COLS].fillna(0).reset_index(drop=True)
cd=pd.get_dummies(df['court_level'],prefix='crt')
pd_=pd.get_dummies(df['product_category'],prefix='prd')
jd=pd.get_dummies(df['jurisdiction'].where(
    df['jurisdiction'].isin(['Massachusetts','California','New York','Texas','Illinois','Pennsylvania','Federal']),
    other='Other'),prefix='jur')
X_eng_df=pd.concat([eng_base,cd,pd_,jd],axis=1).fillna(0)
X_eng_df['log_wc']=np.log1p(df['word_count'].values)
X_eng_df['year_n']=(df['year'].fillna(df['year'].median())-1990)/30
X_eng=StandardScaler().fit_transform(X_eng_df.values.astype(float))
X_top=normalize(X_top)
svd100=TruncatedSVD(n_components=100,random_state=SEED)
X_comb=StandardScaler().fit_transform(np.hstack([svd100.fit_transform(X_tfidf),X_eng,X_top]))
FS={'TF-IDF':X_tfidf,'Engineered':X_eng,'Topics':X_top,'Combined':X_comb}
for fs,X in FS.items(): print(f"     {fs:<12}: {X.shape}")

# 5b Targets
aff_mask=df['outcome_r'].isin(['Affirmed','Reversed'])
df_aff=df[aff_mask]; y_aff=(df_aff['outcome_r']=='Affirmed').astype(int).values; aff_idx=df_aff.index.tolist()
def_mask=df['outcome_r'].isin(['Defendant Victory','Plaintiff Victory','Dismissed'])
df_def=df[def_mask].copy(); df_def['pro_def']=df_def['outcome_r'].isin(['Defendant Victory','Dismissed']).astype(int)
y_def=df_def['pro_def'].values; def_idx=df_def.index.tolist()
y_pun=df['punitive_damages'].values; y_cls=df['class_action_mdl'].values
MCM={'Affirmed':0,'Reversed':1,'Dismissed':2,'Defendant Victory':3,'Plaintiff Victory':4,'Settlement':5}
mc_mask=df['outcome_r'].isin(MCM); df_mc=df[mc_mask]
y_mc=df_mc['outcome_r'].map(MCM).values; mc_idx=df_mc.index.tolist()
TGTS={'Affirmed_vs_Reversed':(y_aff,aff_idx,True),'Pro_Def_vs_Pro_Pla':(y_def,def_idx,True),
      'Punitive_Damages':(y_pun,None,True),'Class_Action_MDL':(y_cls,None,True),
      'Multiclass_Outcome':(y_mc,mc_idx,False)}
for t,(y,idx,_) in TGTS.items(): print(f"     {t:<30}: n={len(y)}")
SKF=StratifiedKFold(n_splits=5,shuffle=True,random_state=SEED)

# 5c CV evaluation
def cv_run(model,X,y,cv,binary=True):
    accs,f1s,aucs=[],[],[]
    for tr,te in cv.split(X,y):
        try:
            m2=type(model)(**model.get_params()); m2.fit(X[tr],y[tr]); yp=m2.predict(X[te])
            accs.append(accuracy_score(y[te],yp))
            f1s.append(f1_score(y[te],yp,average='macro',zero_division=0))
            if binary and len(np.unique(y))==2:
                p=m2.predict_proba(X[te])[:,1] if hasattr(m2,'predict_proba') else m2.decision_function(X[te])
                aucs.append(roc_auc_score(y[te],p))
        except: pass
    out={'accuracy':round(np.nanmean(accs),4) if accs else np.nan,
         'f1_macro':round(np.nanmean(f1s),4) if f1s else np.nan}
    if aucs: out['auc']=round(float(np.nanmean(aucs)),4)
    return out

print("\n  5c Training 7 models × 4 FS × 5 targets...")
all_res={}
for tgt,(y,idx,binary) in TGTS.items():
    print(f"\n    {tgt} (n={len(y)}, binary={binary})")
    all_res[tgt]={}; is_mc=not binary
    nc=len(np.unique(y))
    for fs,X_full in FS.items():
        X=X_full[idx] if idx is not None else X_full; all_res[tgt][fs]={}
        mods={
            'LogReg_L1':LogisticRegression(C=1,penalty='l1',solver='saga',max_iter=2000,random_state=SEED),
            'LogReg_L2':LogisticRegression(C=1,penalty='l2',solver='lbfgs',max_iter=2000,random_state=SEED),
            'RandomForest':RandomForestClassifier(n_estimators=300,max_depth=15,min_samples_leaf=5,random_state=SEED,n_jobs=-1),
            'XGBoost':XGBClassifier(n_estimators=200,max_depth=6,learning_rate=0.1,random_state=SEED,verbosity=0,n_jobs=-1,
                eval_metric='mlogloss' if is_mc else 'logloss',
                objective='multi:softprob' if is_mc else 'binary:logistic',
                **({'num_class':nc} if is_mc else {})),
            'LightGBM':LGBMClassifier(n_estimators=200,max_depth=8,learning_rate=0.1,random_state=SEED,
                verbose=-1,n_jobs=-1,force_col_wise=True,
                **({'objective':'multiclass','num_class':nc} if is_mc else {})),
            'LinearSVM':LinearSVC(C=1,max_iter=5000,random_state=SEED),
        }
        for mn,mod in mods.items():
            r=cv_run(mod,X,y,SKF,binary); all_res[tgt][fs][mn]=r
            print(f"      {fs:<12}|{mn:<14}| AUC={r.get('auc','—'):>6}  Acc={r.get('accuracy','—'):>6}")
        if fs=='TF-IDF':
            try:
                nbc=CountVectorizer(max_features=5000,min_df=3,stop_words=list(LEGAL_SW))
                Xnb=nbc.fit_transform([ALL[i] for i in (idx if idx else range(len(df)))])
                r=cv_run(MultinomialNB(alpha=1.0),Xnb,y,SKF,binary)
            except Exception as e: r={"error":str(e)}
            all_res[tgt][fs]['NaiveBayes']=r
            print(f"      {'TF-IDF':<12}|{'NaiveBayes':<14}| AUC={r.get('auc','—'):>6}  Acc={r.get('accuracy','—'):>6}")

sjson("s5_ml_all_results.json",all_res,params={"cv_folds":5,"seed":SEED,"n_models":7,"n_fs":4,"n_targets":5})

# Best model summary
best_m={}
for tgt in all_res:
    bv,bc=0,None
    for fs in all_res[tgt]:
        for m in all_res[tgt][fs]:
            r=all_res[tgt][fs][m]; v=r.get('auc',r.get('f1_macro',0))
            if isinstance(v,float) and v>bv: bv,bc=v,(fs,m,r)
    if bc: best_m[tgt]={"feature_set":bc[0],"model":bc[1],"metrics":bc[2]}; print(f"  BEST {tgt}: {bc[1]}+{bc[0]} metric={bv:.4f}")
sjson("s5_best_models.json",best_m)

# AUC heatmap
MN=['LogReg_L1','LogReg_L2','RandomForest','XGBoost','LightGBM','LinearSVM','NaiveBayes']
FNl=list(FS.keys())
fig,axes=plt.subplots(1,len(TGTS),figsize=(7*len(TGTS),6))
for ax,(tgt,_) in zip(axes,TGTS.items()):
    heat=np.full((len(MN),len(FNl)),np.nan)
    for j,fs in enumerate(FNl):
        for i,m in enumerate(MN):
            r=all_res[tgt].get(fs,{}).get(m,{}); v=r.get('auc',r.get('f1_macro',np.nan))
            if isinstance(v,float): heat[i,j]=v
    sns.heatmap(heat,annot=True,fmt='.3f',cmap='RdYlGn',vmin=0.5,vmax=1.0,ax=ax,
                xticklabels=FNl,yticklabels=MN,linewidths=0.5,annot_kws={'size':8})
    ax.set_title(tgt.replace('_',' '),fontsize=9)
    ax.tick_params(axis='x',rotation=30,labelsize=8); ax.tick_params(axis='y',labelsize=8)
plt.suptitle('AUC / F1 Heatmap — All Models × Feature Sets × Targets',fontsize=12,fontweight='bold')
sfig("s5_fig1_auc_heatmaps.png")

# ROC curves
binary_t=[(t,d) for t,d in TGTS.items() if d[2]][:4]
fig,axes=plt.subplots(2,2,figsize=(13,10))
for ax,(tgt,(y,idx,_)) in zip(axes.flatten(),binary_t):
    X=FS['TF-IDF'][idx] if idx else FS['TF-IDF']
    mod=XGBClassifier(n_estimators=200,max_depth=6,learning_rate=0.1,random_state=SEED,eval_metric='logloss',verbosity=0)
    fprs,tprs,ar=[],[],[]
    for tr,te in SKF.split(X,y):
        mod.fit(X[tr],y[tr]); prob=mod.predict_proba(X[te])[:,1]
        fpr,tpr,_=roc_curve(y[te],prob); fprs.append(fpr); tprs.append(tpr); ar.append(roc_auc_score(y[te],prob))
    mf=np.linspace(0,1,100); mt=np.mean([np.interp(mf,f,t) for f,t in zip(fprs,tprs)],axis=0)
    ax.plot(mf,mt,color=PAL[0],lw=2,label=f'XGBoost TF-IDF (AUC={np.mean(ar):.3f})')
    ax.fill_between(mf,mt-np.std([np.interp(mf,f,t) for f,t in zip(fprs,tprs)],axis=0),
                    mt+np.std([np.interp(mf,f,t) for f,t in zip(fprs,tprs)],axis=0),alpha=0.15,color=PAL[0])
    ax.plot([0,1],[0,1],'k--',lw=1); ax.set_title(tgt.replace('_',' '),fontsize=9)
    ax.set_xlabel('FPR'); ax.set_ylabel('TPR'); ax.legend(fontsize=8)
sfig("s5_fig2_roc_curves.png")

# Confusion matrices
fig,axes=plt.subplots(2,2,figsize=(12,10))
for ax,(tgt,(y,idx,_)) in zip(axes.flatten(),binary_t):
    X=FS['TF-IDF'][idx] if idx else FS['TF-IDF']
    mod=XGBClassifier(n_estimators=200,max_depth=6,learning_rate=0.1,random_state=SEED,eval_metric='logloss',verbosity=0)
    preds=[]
    for tr,te in SKF.split(X,y):
        mod.fit(X[tr],y[tr]); preds.extend(zip(te.tolist(),mod.predict(X[te]).tolist()))
    preds.sort(key=lambda x:x[0]); yp=np.array([p for _,p in preds])
    sns.heatmap(confusion_matrix(y,yp,normalize='true'),annot=True,fmt='.2f',cmap='Blues',ax=ax,linewidths=0.5)
    ax.set_title(tgt.replace('_',' '),fontsize=9); ax.set_xlabel('Predicted'); ax.set_ylabel('Actual')
sfig("s5_fig3_confusion_matrices.png")

# SHAP
print("\n  5d SHAP...")
shap_out={}
for tgt,(y,idx,_) in [('Affirmed_vs_Reversed',(y_aff,aff_idx,True)),
                        ('Pro_Def_vs_Pro_Pla',(y_def,def_idx,True))]:
    X=FS['TF-IDF'][idx] if idx else FS['TF-IDF']
    mod=XGBClassifier(n_estimators=200,max_depth=6,learning_rate=0.1,random_state=SEED,eval_metric='logloss',verbosity=0)
    mod.fit(X,y)
    try:
        exp=shap.TreeExplainer(mod)
        si=np.random.RandomState(SEED).choice(X.shape[0],min(150,X.shape[0]),replace=False)
        Xs=X[si].toarray() if hasattr(X,'toarray') else X[si]
        sv=exp.shap_values(Xs)
        fig=plt.figure(figsize=(10,6))
        shap.summary_plot(sv,Xs,feature_names=FN5ML,show=False,max_display=20)
        plt.title(f'SHAP — {tgt.replace("_"," ")}',fontsize=11)
        sfig(f"s5d_fig_shap_{tgt.lower()}.png")
        ms=np.abs(sv).mean(axis=0); top=np.argsort(ms)[::-1][:20]
        shap_out[tgt]=[{"feature":FN5ML[i],"mean_abs_shap":round(float(ms[i]),6)} for i in top]
        print(f"     {tgt} top5: {[FN5ML[i] for i in top[:5]]}")
    except Exception as e: print(f"     SHAP err: {e}"); shap_out[tgt]={"error":str(e)}
sjson("s5d_shap_results.json",shap_out)
print("  Stage 5 complete.")

# =============================================================================
# STAGE 6  DAMAGES REGRESSION
# =============================================================================
print("\n"+"="*60+"\nSTAGE 6  REGRESSION\n"+"="*60)
dam_mask=df['max_dollar_amount'].notna()&(df['max_dollar_amount']>0)
df_dam=df[dam_mask]; y_dam=np.log10(df_dam['max_dollar_amount'].values)
dam_idx=df_dam.index.tolist(); n_dam=len(df_dam)
print(f"  n={n_dam}  log10 range {y_dam.min():.2f}–{y_dam.max():.2f}")
fig,axes=plt.subplots(1,2,figsize=(12,4))
axes[0].hist(y_dam,bins=30,color=PAL[0],edgecolor='white')
axes[0].set_title(f'log₁₀(Damages) n={n_dam}'); axes[0].set_xlabel('log₁₀ USD')
dc=df_dam.groupby('product_category')['max_dollar_amount'].median().sort_values()
axes[1].barh(dc.index,np.log10(dc.values.clip(1)),color=PAL[2]); axes[1].set_title('Median log₁₀ by Product')
sfig("s6_fig1_damages.png")
KF=KFold(n_splits=5,shuffle=True,random_state=SEED); reg_res={}
for fs_name,X_full in [('TF-IDF',FS['TF-IDF']),('Engineered',FS['Engineered']),('Combined',FS['Combined'])]:
    Xd=X_full[dam_idx]; reg_res[fs_name]={}
    for rn,reg in [('Ridge',Ridge(alpha=1.0)),('Lasso',Lasso(alpha=0.01,max_iter=5000)),
                   ('XGBoost',XGBRegressor(n_estimators=200,max_depth=6,learning_rate=0.1,random_state=SEED,verbosity=0,n_jobs=-1))]:
        r2s,maes=[],[]
        for tr,te in KF.split(Xd):
            Xtr=Xd[tr].toarray() if hasattr(Xd,'toarray') else Xd[tr]
            Xte=Xd[te].toarray() if hasattr(Xd,'toarray') else Xd[te]
            try: reg.fit(Xtr,y_dam[tr]); p=reg.predict(Xte); r2s.append(r2_score(y_dam[te],p)); maes.append(mean_absolute_error(y_dam[te],p))
            except: r2s.append(np.nan); maes.append(np.nan)
        reg_res[fs_name][rn]={"r2_mean":round(float(np.nanmean(r2s)),4),"r2_std":round(float(np.nanstd(r2s)),4),"mae_mean":round(float(np.nanmean(maes)),4)}
        print(f"  {fs_name:<12}|{rn:<10}| R²={reg_res[fs_name][rn]['r2_mean']:.4f}  MAE={reg_res[fs_name][rn]['mae_mean']:.4f}")
sjson("s6_regression_results.json",reg_res,params={"n":n_dam,"target":"log10_dollars","cv":5,"seed":SEED})
try:
    Xe=FS['Engineered'][dam_idx]
    xr=XGBRegressor(n_estimators=200,max_depth=6,learning_rate=0.1,random_state=SEED,verbosity=0)
    xr.fit(Xe,y_dam); exp2=shap.TreeExplainer(xr); sv2=exp2.shap_values(Xe)
    fig=plt.figure(figsize=(10,6))
    shap.summary_plot(sv2,Xe,feature_names=list(X_eng_df.columns),show=False,max_display=20)
    plt.title('SHAP — log(Damages) Regression',fontsize=11); sfig("s6_fig2_shap_damages.png")
    ms2=np.abs(sv2).mean(axis=0); top2=np.argsort(ms2)[::-1][:20]
    sjson("s6_shap_damages.json",[{"feature":list(X_eng_df.columns)[i],"mean_abs_shap":round(float(ms2[i]),6)} for i in top2])
except Exception as e: print(f"  SHAP reg err: {e}")
print("  Stage 6 complete.")

# =============================================================================
# STAGE 7  DEFERRED
# =============================================================================
sjson("s7_did_deferred.json",{"status":"deferred","events":["Daubert_1993","Riegel_2008"],
    "note":"Run in Colab using bert_colab_package/"})

# =============================================================================
# STAGE 8  MANIFEST & FREEZE
# =============================================================================
print("\n"+"="*60+"\nSTAGE 8  MANIFEST\n"+"="*60)
meta_cols=['case_id','case_name','filename','source','word_count','year','jurisdiction',
           'court_level','outcome','outcome_r','recoded','product_category',
           'max_dollar_amount','cluster']+TC+DOC_COLS+TONE_COLS
meta_cols=[c for c in meta_cols if c in df.columns]
scsv("pl_corpus_metadata_for_colab.csv",df[meta_cols])
manifest["INPUT_corpus"]={"sha256":_sha(CORPUS),"ts":_ts(),"type":"input","n_cases":len(df)}
manifest["PIPELINE_PARAMS"]={"seed":SEED,"tfidf_10k":10000,"tfidf_5k_ml":5000,
    "lda_k":BK,"nmf_k":BK,"nmf_init":"random","kmeans_k":BKM,"cv_folds":5,
    "bert":"deferred_colab","did":"deferred_colab","run_ts":_ts()}
sjson("s8_manifest.json",manifest)
files=sorted(OUT.glob("*")); total=sum(f.stat().st_size for f in files)
print(f"\n  {len(files)} files  {total/1e6:.1f} MB")
for f in files: print(f"    {f.name:<55} {f.stat().st_size/1024:>7.1f} KB")
print("\n  FROZEN. Reference s8_manifest.json.")
