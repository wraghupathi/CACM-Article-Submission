# Shareholder & Securities Litigation — Reproducibility Package v2
# Raghupathi, W. — Fordham University, Gabelli School of Business
# Generated: April 2026
# Phase: Descriptive Analytics (complete) | Predictive Analytics (pending)
# ============================================================================

## OVERVIEW
Full reproducibility package for corpus construction and descriptive analytics
phases of the shareholder and securities litigation NLP/ML study (N = 883).

## WHAT IS NEW IN v2 (vs v1)
v1 contained: corpus metadata, cleaned CSV, excluded CSV, texts JSON, 4 scripts,
               6 pipeline outputs, README.
v2 adds:       3 additional scripts (descriptive analytics, text analytics B1–B7,
               chart generation), 28 new descriptive output CSVs, 14 production
               charts, updated README.

## FILE INVENTORY (65 files total)

### Root — Core Data (4 files)
  securities_corpus_metadata.csv     900 raw cases profiled (13 columns)
  securities_corpus_cleaned.csv      883 retained cases after cleaning
  securities_corpus_excluded.csv     17 excluded cases with documented reasons
  securities_texts.json              Full cleaned text for all 883 cases (~68 MB)

### Scripts/ — Run in Order (7 files)
  01_profile_corpus.py               Metadata extraction from 900 PDFs
  02_clean_corpus.py                 Dedup + relevance filter → 883 cases
  03_extract_texts.py                Full text extraction + Westlaw boilerplate stripping
  04_nlp_pipeline.py                 TF-IDF, LDA (sklearn), NMF, outcome classification
  05_descriptive_analytics.py        15 demographic/structural analyses → 20 CSVs
  06_text_analytics_B1_B7.py         Word cloud, cosine similarity, Gensim LDA + coherence
  07_generate_charts.py              All 14 production charts (matplotlib/seaborn/wordcloud)

### pipeline_outputs/ — From Script 04 (6 files)
  tfidf_top_terms.csv                Top 30 TF-IDF terms (mean score)
  lda_topics.csv                     sklearn LDA k=10, top 15 words per topic
  nmf_topics.csv                     NMF k=10, top 15 words per topic
  doc_topic_assignments.csv          Per-document topic probabilities + dominant topic
  classification_results.csv         5-fold CV: LR, RF, LinearSVC
  lr_feature_importance.csv          LR coefficients (plaintiff vs defense terms)

### descriptive_outputs/ — From Scripts 05 & 06 (34 files)
  01_corpus_overview.csv             Summary metrics (N, year range, word counts)
  02_temporal_by_year.csv            Case count by individual year (1934–2026)
  02_temporal_by_decade.csv          Case count + % by decade
  03_court_level.csv                 Court level distribution
  04_circuit_distribution.csv        Circuit distribution (labeled cases)
  05_theory_frequency.csv            22 legal theories — count + %
  06_theory_cooccurrence.csv         12×12 co-occurrence matrix (counts)
  07_outcome_distribution.csv        10 outcome categories — count + %
  08_outcome_x_court.csv             Outcome × court level cross-tab
  09_outcome_x_theory.csv            Outcome × theory (top 8) + dismiss rate
  10_wordcount_stats.csv             Descriptive stats on word count
  10_wordcount_by_court.csv          Word count by court level
  10_wordcount_by_decade.csv         Word count by decade
  11_vocabulary_richness.csv         Type-Token Ratio by decade
  12_tfidf_top_unigrams.csv          Top 30 unigrams by TF-IDF
  12_tfidf_top_bigrams.csv           Top 30 bigrams by TF-IDF
  12_tfidf_top_combined.csv          Top 30 combined (1,2)-grams
  13_theory_x_decade_heatmap.csv     Theory prevalence % by decade (heatmap data)
  14_circuit_x_theory.csv            Circuit × theory cross-tab (top 5 circuits)
  15_summary_statistics.csv          Paper-ready summary statistics table
  B1_wordcloud_data.csv              Top 200 unigram frequencies (word cloud source)
  B1_wordcloud_bigrams.csv           Top 150 bigram frequencies
  B4_cosine_similarity_stats.csv     Pairwise similarity statistics (500 pairs)
  B4_cosine_distribution.csv         Histogram data (bin counts)
  B4_most_similar_pairs.csv          Top 30 most similar document pairs (sim > 0.25)
  B4_similarity_by_court.csv         Within-group similarity by court level
  B7_coherence_scores.csv            Coherence scores: k=5 (C_v=0.400) k=10 (C_v=0.394)
  B7_gensim_lda_k10_topics.csv       Gensim LDA k=10: top 15 words + probabilities
  B7_gensim_lda_k10_doc_topics.csv   Per-document topic distribution (Gensim)

### charts/ — Production Figures (14 files)
  chart01_temporal_decade.png        Fig. 1  — Cases by decade bar chart
  chart02_court_level.png            Fig. 2  — Court level pie + bar
  chart03_circuit.png                Fig. 3  — Circuit distribution bar
  chart04_theory_frequency.png       Fig. 4  — Theory frequency horizontal bar
  chart05_outcomes.png               Fig. 5  — Outcome distribution (color-coded)
  chart06_theory_decade_heatmap.png  Fig. 6  — Theory × Decade heatmap
  chart07_cooccurrence_heatmap.png   Fig. 7  — Theory co-occurrence heatmap
  chart08_wordcloud.png              Fig. 8  — Word cloud (top 120 terms)
  chart09_cosine_similarity.png      Fig. 9  — Cosine similarity distribution
  chart10_lda_topics.png             Fig. 10 — sklearn LDA topics (k=10)
  chart11_gensim_lda_topics.png      Fig. 11 — Gensim LDA topics (k=10)
  chart12_dismissal_by_theory.png    Fig. 12 — Dismissal rate by theory
  chart13_wordcount_by_decade.png    Fig. 13 — Opinion length boxplots by decade
  chart14_nmf_topics.png             Fig. 14 — NMF robustness check (k=10)

## PIPELINE SUMMARY

  Step 0: Extraction
    9 zip files → separate subdirs → global unique IDs (0001–0900)
    Tool: Python zipfile

  Step 1: Profiling [Script 01]
    Input:  900 PDFs
    Output: securities_corpus_metadata.csv
    Method: PyMuPDF; regex extraction of citation, docket, year,
            court, circuit, 22 theories, 10 outcome keywords, word count

  Step 2: Cleaning [Script 02]
    Input:  900 cases
    Output: 883 retained + 17 excluded
    Stage 1 — Duplicate citations:    3 removed
    Stage 2 — Too short (< 500 wds):  5 removed
    Stage 3 — Irrelevant subject:     9 removed

  Step 3: Text Extraction [Script 03]
    Input:  883 PDFs
    Output: securities_texts.json (883 full texts, boilerplate stripped)
    Errors: 0 of 883

  Step 4: NLP Pipeline [Script 04]
    TF-IDF:  883 × 5,000 matrix (max_features=5000, min_df=5, max_df=0.85)
    LDA:     k=10, sklearn, online learning, random_state=42
    NMF:     k=10, sklearn, random_state=42
    Classif: 544 labeled cases; 5-fold CV; LR / RF / LinearSVC
    Best:    LinearSVC (Acc=0.708, F1=0.674)

  Step 5: Demographic Analytics [Script 05]
    15 analyses → 20 CSV outputs
    Covers: temporal, court, circuit, theory, co-occurrence, outcome,
            document length, vocabulary richness, TF-IDF, heatmaps, cross-tabs

  Step 6: Text Analytics B1–B7 [Script 06]
    B1: Word cloud data (unigrams + bigrams)
    B4: Cosine similarity (500 random pairs; within-group by court)
    B7: Gensim LDA k=10 with C_v coherence scoring
    Note: Mallet LDA not available (network-restricted environment);
          Gensim LdaMulticore used as equivalent (Gibbs-sampling philosophy
          approximated via online VB with asymmetric alpha)

  Step 7: Chart Generation [Script 07]
    14 production charts (matplotlib 3.10.8 / seaborn 0.13.2 / wordcloud)
    All figures numbered and titled for paper insertion

## CORPUS PROFILE (Final: N = 883)
  Year range:      1934–2026 (median 1989, mean 1991)
  Court levels:    District 58% | Circuit 29% | SCOTUS 1% | State 3% | SEC 1%
  Top circuits:    2nd (68) | 9th (46) | 3rd (28) | 7th (27) | 5th (25)
  Top theories:    Fraud 45% | Merger 43% | Rule 10b-5 35% | Proxy 32%
  Top outcomes:    Dismissed 35% | Affirmed 29% | Remanded 16% | Reversed 15%
  Plaintiff wins:  12 cases (1.4% of labeled) — defense-dominant corpus
  ESG/Climate:     1 ESG case; 3 climate mentions — pre-ESG litigation era
  Word count:      Mean 5,931 | Median 4,442 | SD 5,113 | Total 5.24M

## KEY FINDINGS — DESCRIPTIVE PHASE
  1. Temporal: 1970s–80s dominate (40.5%); class actions rising to 61% of 2020s cases
  2. Geography: 2nd Circuit dominates (26.8% of circuit cases); NY/CA financial hubs
  3. Theory clusters: (a) Fraud/10b-5/Misrepresentation; (b) Merger/Proxy/Fiduciary
  4. Outcomes: defense-favorable — 48% dismissal rate for Rule 10b-5 cases
  5. Similarity: corpus highly diverse (73% of pairs sim < 0.10); SCOTUS most cohesive
  6. Topics: 10 coherent themes confirmed by LDA (sklearn), Gensim LDA, and NMF
  7. Temporal trends: Rule 10b-5 peaked 1960s–70s; derivative suits declining;
     class actions and longer opinions both trending upward

## ENVIRONMENT
  Python 3.12 | PyMuPDF 1.27.2 | scikit-learn 1.8.0 | gensim 4.4.0
  matplotlib 3.10.8 | seaborn 0.13.2 | wordcloud | pandas | numpy
  Node.js | docx (npm) — for Word document generation

## REPRODUCIBILITY DISCIPLINE
  - All random seeds fixed at 42 throughout
  - No fabrication: all statistics trace to frozen CSV outputs
  - Exclusions deterministic (citation match, word threshold, name list)
  - securities_texts.json is single source of truth for all NLP stages
  - Run scripts in order: 01 → 02 → 03 → 04 → 05 → 06 → 07
  - Predictive analytics scripts (08+) to be added in v3
