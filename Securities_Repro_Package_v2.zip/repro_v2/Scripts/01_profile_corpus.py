"""
Shareholder & Securities Litigation Corpus Profiler
Extracts metadata from 900 Westlaw PDFs:
  - Case name, citation, docket number
  - Court name and level
  - Decision date and year
  - Jurisdiction / circuit
  - Legal theories mentioned
  - Outcome keywords
  - Word count
Outputs: securities_corpus_metadata.csv
"""

import os, re, json, csv
from pathlib import Path
import fitz  # PyMuPDF

CORPUS_DIR = Path("/home/claude/securities_all")
OUT_CSV    = Path("/home/claude/securities_corpus_metadata.csv")

# ── Helpers ──────────────────────────────────────────────────────────────────

def extract_text(pdf_path, max_pages=6):
    """Extract text from first N pages (header info lives there)."""
    try:
        doc = fitz.open(str(pdf_path))
        text = ""
        for i, page in enumerate(doc):
            if i >= max_pages:
                break
            text += page.get_text()
        doc.close()
        return text
    except Exception as e:
        return ""

def full_text(pdf_path):
    """Extract full text for word count."""
    try:
        doc = fitz.open(str(pdf_path))
        text = " ".join(page.get_text() for page in doc)
        doc.close()
        return text
    except:
        return ""

def parse_citation(text):
    """Extract primary Westlaw citation (e.g. 421 U.S. 723, 556 F.3d 1095)."""
    patterns = [
        r'\d+\s+U\.S\.\s+\d+',
        r'\d+\s+S\.Ct\.\s+\d+',
        r'\d+\s+F\.\d+[sd]?\s+\d+',
        r'\d+\s+F\.Supp\.(?:\d+[sd]?)?\s+\d+',
        r'\d+\s+F\.App\'?x\.?\s+\d+',
        r'\d+\s+WL\s+\d+',
        r'\d+\s+Fed\.Appx\.\s+\d+',
    ]
    for pat in patterns:
        m = re.search(pat, text[:3000])
        if m:
            return m.group().strip()
    return ""

def parse_docket(text):
    """Extract docket/case number."""
    patterns = [
        r'No\.?\s+[\w\d\-]+(?:[\-–]\w+)*(?:,\s*No\.?\s+[\w\d\-]+)*',
        r'Case No\.?\s+[\w\d\-:]+',
        r'Civ\.?\s+(?:No\.?\s+)?[\w\d\-]+',
        r'Civil Action No\.?\s+[\w\d\-]+',
    ]
    for pat in patterns:
        m = re.search(pat, text[:3000])
        if m:
            val = m.group().strip()
            if len(val) < 60:
                return val
    return ""

def parse_date(text):
    """Extract decision date."""
    months = r'(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)'
    patterns = [
        rf'Decided\s+{months}\.?\s+\d{{1,2}},\s+(\d{{4}})',
        rf'Filed\s+{months}\.?\s+\d{{1,2}},\s+(\d{{4}})',
        rf'({months}\.?\s+\d{{1,2}},\s+\d{{4}})',
        r'(\d{4})\)',
    ]
    for pat in patterns:
        m = re.search(pat, text[:4000])
        if m:
            year_str = m.group(1) if m.lastindex and m.lastindex >= 1 else m.group()
            yr = re.search(r'\d{4}', year_str)
            if yr:
                yr_int = int(yr.group())
                if 1930 <= yr_int <= 2026:
                    return yr_int, m.group().strip()
    return None, ""

def parse_court(text):
    """Extract court name and classify level."""
    court_patterns = [
        (r'Supreme Court of the United States', 'SCOTUS'),
        (r'United States Court of Appeals[^\.]{0,60}(?:Circuit|Cir\.)', 'Circuit'),
        (r'U\.S\. Court of Appeals[^\.]{0,60}(?:Circuit|Cir\.)', 'Circuit'),
        (r'United States District Court[^\.]{0,80}', 'District'),
        (r'U\.S\. District Court[^\.]{0,80}', 'District'),
        (r'Court of Chancery', 'State-Chancery'),
        (r'Supreme Court of (?!the United)[A-Z][a-z]+', 'State-Supreme'),
        (r'(?:Appellate|Appeals?) Court of [A-Z][a-z]+', 'State-Appellate'),
        (r'Securities and Exchange Commission', 'SEC/Admin'),
    ]
    for pat, level in court_patterns:
        m = re.search(pat, text[:3000])
        if m:
            return m.group().strip()[:120], level
    return "", "Unknown"

def parse_circuit(court_text):
    """Extract circuit number from court string."""
    m = re.search(r'(First|Second|Third|Fourth|Fifth|Sixth|Seventh|Eighth|Ninth|Tenth|Eleventh|D\.C\.|Federal)\s+Circuit', court_text, re.I)
    if m:
        return m.group(1)
    m = re.search(r'(\d+)(?:st|nd|rd|th)\s+Cir', court_text, re.I)
    if m:
        return m.group(1)
    return ""

LEGAL_THEORIES = {
    'Rule 10b-5':       r'10b[-–]5|Rule\s+10b',
    'Section 10(b)':    r'[Ss]ection\s+10\(b\)|§\s*10\(b\)',
    'Section 11':       r'[Ss]ection\s+11\b|§\s*11\b',
    'Section 12':       r'[Ss]ection\s+12\b|§\s*12\b',
    'Section 14':       r'[Ss]ection\s+14\b|§\s*14\b',
    'Section 20(a)':    r'[Ss]ection\s+20\(a\)|§\s*20\(a\)',
    'Rule 14a-9':       r'14a[-–]9',
    'Fiduciary Duty':   r'fiduciary\s+duty|breach\s+of\s+fiduciary',
    'Insider Trading':  r'insider\s+trad',
    'Proxy':            r'proxy\s+(?:statement|fraud|contest|fight|solicitation)',
    'Fraud':            r'\bfraud\b|fraudulent\s+misrepresent',
    'Misrepresentation':r'misrepresent|material\s+omission',
    'Class Action':     r'class\s+action|class\s+certif',
    'Derivative':       r'derivative\s+(?:action|suit|claim)',
    'Tender Offer':     r'tender\s+offer',
    'Merger':           r'\bmerger\b|going[\s-]private|acquisition',
    'Short-swing':      r'short[\s-]swing|[Ss]ection\s+16\(b\)',
    'PSLRA':            r'PSLRA|Private\s+Securities\s+Litigation\s+Reform',
    'RICO':             r'\bRICO\b|racketeering',
    'Standing':         r'\bstanding\b|Birnbaum|Blue\s+Chip',
    'Scienter':         r'\bscienter\b|fraudulent\s+intent',
    'Loss Causation':   r'loss\s+causation|transaction\s+causation',
}

OUTCOMES = {
    'Affirmed':         r'\baffirmed\b',
    'Reversed':         r'\breversed\b',
    'Remanded':         r'\bremanded\b',
    'Dismissed':        r'\bdismissed\b|motion\s+to\s+dismiss\s+granted',
    'Summary Judgment': r'summary\s+judgment\s+(?:granted|affirmed)',
    'Settled':          r'\bsettled?\b|settlement\s+approved',
    'Plaintiff Win':    r'judgment\s+for\s+plaintiff|verdict\s+for\s+plaintiff',
    'Defendant Win':    r'judgment\s+for\s+defendant|verdict\s+for\s+defendant',
    'Certified':        r'class\s+(?:is\s+)?certified',
    'Denied Cert':      r'certiorari\s+denied|cert\.?\s+denied',
}

def parse_theories(text):
    found = [k for k, pat in LEGAL_THEORIES.items() if re.search(pat, text[:8000], re.I)]
    return "; ".join(found)

def parse_outcome(text):
    found = [k for k, pat in OUTCOMES.items() if re.search(pat, text[:6000], re.I)]
    return "; ".join(found)

def parse_case_name(filename):
    m = re.match(r'^\d{4} - (.+)\.pdf$', filename)
    return m.group(1) if m else filename

# ── Main profiling loop ───────────────────────────────────────────────────────

files = sorted(CORPUS_DIR.glob("*.pdf"))
print(f"Profiling {len(files)} PDFs...")

records = []
errors = []

for i, pdf_path in enumerate(files):
    if (i+1) % 50 == 0:
        print(f"  {i+1}/{len(files)}...")

    fname = pdf_path.name
    case_name = parse_case_name(fname)

    hdr_text = extract_text(pdf_path, max_pages=6)
    if not hdr_text:
        errors.append(fname)
        continue

    ft = full_text(pdf_path)
    word_count = len(ft.split())

    citation   = parse_citation(hdr_text)
    docket     = parse_docket(hdr_text)
    year, date_str = parse_date(hdr_text)
    court, level   = parse_court(hdr_text)
    circuit        = parse_circuit(court)
    theories       = parse_theories(ft)
    outcome        = parse_outcome(ft)

    records.append({
        "global_id":   fname[:4],
        "filename":    fname,
        "case_name":   case_name,
        "citation":    citation,
        "docket":      docket,
        "year":        year,
        "date_str":    date_str,
        "court":       court,
        "court_level": level,
        "circuit":     circuit,
        "theories":    theories,
        "outcome":     outcome,
        "word_count":  word_count,
    })

fieldnames = ["global_id","filename","case_name","citation","docket",
              "year","date_str","court","court_level","circuit",
              "theories","outcome","word_count"]

with open(OUT_CSV, "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=fieldnames)
    w.writeheader()
    w.writerows(records)

print(f"\nDone. {len(records)} records written to {OUT_CSV}")
print(f"Errors (unreadable PDFs): {len(errors)}")
if errors:
    for e in errors:
        print(f"  {e}")
