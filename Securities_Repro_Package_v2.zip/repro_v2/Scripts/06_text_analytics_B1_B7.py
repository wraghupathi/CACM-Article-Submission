"""
Text-Based Descriptive Analytics (B1–B7)
Shareholder & Securities Litigation Corpus (N=883)

B1. Word cloud data
B2. TF-IDF already saved — reload for charts
B3. Co-occurrence (already saved) — prep visual data
B4. Cosine document similarity
B5. LDA (sklearn) — already done
B6. NMF (sklearn) — already done
B7. Gensim LDA with coherence scores (Mallet equivalent — Gibbs sampling)
"""

import json, re, csv
from pathlib import Path
from collections import Counter
import numpy as np
import pandas as pd

from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer, ENGLISH_STOP_WORDS
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.decomposition import LatentDirichletAllocation, NMF

import gensim
import gensim.corpora as corpora
from gensim.models import LdaMulticore, CoherenceModel

CLEAN_CSV  = "/home/claude/securities_corpus_cleaned.csv"
TEXTS_JSON = "/home/claude/securities_texts.json"
OUT        = Path("/home/claude/descriptive_outputs")
OUT.mkdir(exist_ok=True)

print("Loading data...")
df = pd.read_csv(CLEAN_CSV)
with open(TEXTS_JSON) as f:
    corpus_dict = json.load(f)

# ── shared preprocessing ──────────────────────────────────────────────────────
LEGAL_STOP = {
    "court","plaintiff","defendant","case","action","claims","claim","alleged",
    "allege","alleging","complaint","appeal","appellate","district","circuit",
    "opinion","judge","honor","pursuant","order","motion","section","rule",
    "act","law","federal","states","united","new","york","inc","corp","co",
    "ltd","llc","also","may","would","shall","must","however","therefore",
    "thus","whether","although","upon","per","see","said","such","under",
    "above","below","within","without","among","between","against","behalf",
    "respect","therein","herein","thereof","hereof","therefrom","heretofore",
    "hereafter","whereas","whereby","wherein","hereinafter","slip","aff",
    "rev","held","holding","justice","honorable","honor","supr","appx",
}
ALL_STOP = ENGLISH_STOP_WORDS.union(LEGAL_STOP)

def clean_tokens(text, min_len=4):
    text = re.sub(r'\d+', '', text.lower())
    text = re.sub(r'[^a-z\s]', ' ', text)
    return [t for t in text.split() if len(t) >= min_len and t not in ALL_STOP]

filenames  = list(df["filename"])
texts_raw  = [corpus_dict.get(fn, "") for fn in filenames]
tokens_list = [clean_tokens(t) for t in texts_raw]
texts_clean = [" ".join(toks) for toks in tokens_list]
print(f"Preprocessed {len(texts_clean)} documents.\n")

# ══════════════════════════════════════════════════════════════════════════════
# B1. WORD CLOUD DATA
# ══════════════════════════════════════════════════════════════════════════════
print("B1. Word cloud data...")
all_tokens = []
for toks in tokens_list:
    all_tokens.extend(toks)

freq = Counter(all_tokens)
wc_df = pd.DataFrame(freq.most_common(200), columns=["word","frequency"])
wc_df.to_csv(OUT/"B1_wordcloud_data.csv", index=False)
print(f"   Top 20: {', '.join(wc_df['word'].head(20).tolist())}")

# Also save bigram frequencies for bigram word cloud
bigram_freq = Counter()
for toks in tokens_list:
    for i in range(len(toks)-1):
        bigram_freq[(toks[i], toks[i+1])] += 1
bigram_df = pd.DataFrame(
    [{"bigram": f"{a} {b}", "frequency": c}
     for (a,b),c in bigram_freq.most_common(150)],
)
bigram_df.to_csv(OUT/"B1_wordcloud_bigrams.csv", index=False)
print(f"   Top bigrams: {', '.join(bigram_df['bigram'].head(10).tolist())}")

# ══════════════════════════════════════════════════════════════════════════════
# B4. COSINE DOCUMENT SIMILARITY
# ══════════════════════════════════════════════════════════════════════════════
print("\nB4. Cosine document similarity...")
tfidf_vec = TfidfVectorizer(max_features=5000, min_df=5, max_df=0.85,
                             ngram_range=(1,2))
X_tfidf = tfidf_vec.fit_transform(texts_clean)

# Full pairwise similarity is 883×883 = heavy; sample strategically
# 1. Overall distribution: sample 200 random pairs
np.random.seed(42)
n = X_tfidf.shape[0]
idx_a = np.random.choice(n, 2000, replace=True)
idx_b = np.random.choice(n, 2000, replace=True)
mask  = idx_a != idx_b
idx_a, idx_b = idx_a[mask], idx_b[mask]
sims  = np.array([cosine_similarity(X_tfidf[a], X_tfidf[b])[0,0]
                  for a,b in zip(idx_a[:500], idx_b[:500])])

sim_stats = {
    "mean_similarity":   round(float(sims.mean()), 4),
    "median_similarity": round(float(np.median(sims)), 4),
    "std_similarity":    round(float(sims.std()), 4),
    "min_similarity":    round(float(sims.min()), 4),
    "max_similarity":    round(float(sims.max()), 4),
    "pct_below_0.1":     round(float((sims < 0.1).mean()*100), 1),
    "pct_0.1_to_0.3":    round(float(((sims>=0.1)&(sims<0.3)).mean()*100), 1),
    "pct_above_0.3":     round(float((sims >= 0.3).mean()*100), 1),
}
pd.DataFrame(list(sim_stats.items()), columns=["metric","value"])\
  .to_csv(OUT/"B4_cosine_similarity_stats.csv", index=False)
print(f"   Mean sim: {sim_stats['mean_similarity']}  "
      f"Median: {sim_stats['median_similarity']}  "
      f"Std: {sim_stats['std_similarity']}")

# 2. Similarity distribution histogram data
bins = np.arange(0, 1.05, 0.05)
hist, edges = np.histogram(sims, bins=bins)
hist_df = pd.DataFrame({"bin_left": edges[:-1].round(2),
                         "bin_right": edges[1:].round(2),
                         "count": hist,
                         "pct": (hist/len(sims)*100).round(1)})
hist_df.to_csv(OUT/"B4_cosine_distribution.csv", index=False)

# 3. Most similar pairs (top 20)
print("   Finding most similar pairs...")
# Use a subset (first 200 docs) to keep runtime manageable
sub = X_tfidf[:200]
sim_matrix = cosine_similarity(sub)
np.fill_diagonal(sim_matrix, 0)
pairs = []
for i in range(200):
    for j in range(i+1, 200):
        if sim_matrix[i,j] > 0.3:
            pairs.append({
                "doc_i": filenames[i],
                "doc_j": filenames[j],
                "similarity": round(float(sim_matrix[i,j]), 4),
                "name_i": df.iloc[i]["case_name"],
                "name_j": df.iloc[j]["case_name"],
            })
pairs.sort(key=lambda x: -x["similarity"])
pd.DataFrame(pairs[:30]).to_csv(OUT/"B4_most_similar_pairs.csv", index=False)
print(f"   High-similarity pairs (>0.3): {len(pairs)}")
if pairs:
    p = pairs[0]
    print(f"   Top pair: {p['name_i']} ↔ {p['name_j']} ({p['similarity']})")

# 4. Mean similarity by court level (within-group cohesion)
print("   Within-group similarity by court level...")
group_sim = []
for level in ["District","Circuit","SCOTUS"]:
    idx = df[df["court_level"]==level].index.tolist()
    if len(idx) < 5: continue
    idx = idx[:100]  # cap for speed
    sub_mat = cosine_similarity(X_tfidf[idx])
    np.fill_diagonal(sub_mat, 0)
    mean_s = sub_mat[sub_mat>0].mean()
    group_sim.append({"court_level": level, "n": len(idx),
                       "mean_intra_similarity": round(float(mean_s), 4)})
pd.DataFrame(group_sim).to_csv(OUT/"B4_similarity_by_court.csv", index=False)
for g in group_sim:
    print(f"   {g['court_level']}: mean intra-group sim = {g['mean_intra_similarity']}")

# ══════════════════════════════════════════════════════════════════════════════
# B7. GENSIM LDA WITH COHERENCE (MALLET EQUIVALENT)
# ══════════════════════════════════════════════════════════════════════════════
print("\nB7. Gensim LDA with coherence scoring...")

# Build dictionary and corpus
dictionary = corpora.Dictionary(tokens_list)
dictionary.filter_extremes(no_below=5, no_above=0.85)
bow_corpus  = [dictionary.doc2bow(toks) for toks in tokens_list]
print(f"   Dictionary: {len(dictionary)} unique terms")

# Fit models for k=5,7,10,12,15 → pick best by coherence
results = []
models  = {}

for k in [5, 7, 10, 12, 15]:
    print(f"   Fitting k={k}...")
    lda_model = LdaMulticore(
        corpus=bow_corpus,
        id2word=dictionary,
        num_topics=k,
        random_state=42,
        chunksize=100,
        passes=15,
        workers=2,
        alpha='asymmetric',
        eta='auto',
    )
    # Coherence C_v
    coh_cv = CoherenceModel(model=lda_model, texts=tokens_list,
                             dictionary=dictionary, coherence='c_v')
    cv_score = coh_cv.get_coherence()
    # Coherence UMass
    coh_um = CoherenceModel(model=lda_model, corpus=bow_corpus,
                             dictionary=dictionary, coherence='u_mass')
    um_score = coh_um.get_coherence()

    results.append({"k": k, "coherence_cv": round(cv_score,4),
                    "coherence_umass": round(um_score,4)})
    models[k] = lda_model
    print(f"   k={k}: C_v={cv_score:.4f}  UMass={um_score:.4f}")

coh_df = pd.DataFrame(results)
coh_df.to_csv(OUT/"B7_coherence_scores.csv", index=False)

# Best k by C_v
best_k = coh_df.loc[coh_df["coherence_cv"].idxmax(), "k"]
print(f"\n   Best k by C_v: {best_k}")

best_model = models[best_k]

# Save topics for best model
topic_rows = []
print(f"\n   Topics at k={best_k}:")
for tid in range(best_k):
    top_words = best_model.show_topic(tid, topn=15)
    words = [w for w,_ in top_words]
    scores = [round(s,4) for _,s in top_words]
    print(f"   Topic {tid}: {', '.join(words[:10])}")
    topic_rows.append({
        "topic_id": tid,
        **{f"word_{i+1}": w for i,w in enumerate(words)},
        **{f"prob_{i+1}": s for i,s in enumerate(scores)},
    })
pd.DataFrame(topic_rows).to_csv(OUT/f"B7_gensim_lda_k{best_k}_topics.csv", index=False)

# Doc-topic distribution for best model
doc_topic_rows = []
for i, bow in enumerate(bow_corpus):
    topic_dist = dict(best_model.get_document_topics(bow, minimum_probability=0))
    row = {"filename": filenames[i], "case_name": df.iloc[i]["case_name"]}
    for t in range(best_k):
        row[f"topic_{t}"] = round(topic_dist.get(t, 0), 4)
    row["dominant_topic"] = max(topic_dist, key=topic_dist.get) if topic_dist else 0
    doc_topic_rows.append(row)
pd.DataFrame(doc_topic_rows).to_csv(OUT/f"B7_gensim_lda_k{best_k}_doc_topics.csv", index=False)

# Topic size (how many docs each topic dominates)
dom_counts = Counter(r["dominant_topic"] for r in doc_topic_rows)
print(f"\n   Topic dominance distribution:")
for t in sorted(dom_counts):
    print(f"   Topic {t}: {dom_counts[t]} docs")

print(f"\n{'='*60}")
print(f"B1–B7 complete. All outputs in {OUT}/")
print(f"New files this run:")
new_files = ["B1_wordcloud_data.csv","B1_wordcloud_bigrams.csv",
             "B4_cosine_similarity_stats.csv","B4_cosine_distribution.csv",
             "B4_most_similar_pairs.csv","B4_similarity_by_court.csv",
             "B7_coherence_scores.csv",
             f"B7_gensim_lda_k{best_k}_topics.csv",
             f"B7_gensim_lda_k{best_k}_doc_topics.csv"]
for f in new_files:
    print(f"  {f}")
