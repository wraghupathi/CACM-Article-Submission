"""
Shareholder & Securities Litigation Corpus Cleaner
Applies three-stage cleaning:
  1. Exact duplicate removal (same citation, keep longest doc)
  2. Very short document removal (< 500 words — stubs/orders)
  3. Relevance filter (non-securities subject matter)
Outputs:
  - securities_corpus_cleaned.csv   (retained cases)
  - securities_corpus_excluded.csv  (excluded cases with reason)
"""

import pandas as pd
import re

IN_CSV       = "/home/claude/securities_corpus_metadata.csv"
CLEAN_CSV    = "/home/claude/securities_corpus_cleaned.csv"
EXCLUDED_CSV = "/home/claude/securities_corpus_excluded.csv"

df = pd.read_csv(IN_CSV)
df["exclusion_reason"] = ""
print(f"Starting N = {len(df)}")

excluded = []

# ── STAGE 1: Duplicate citations ─────────────────────────────────────────────
# Where multiple docs share a citation, keep the one with most words.
# Citation collisions that are actually different cases (different names,
# different dockets) are treated as false-positive citation parses — kept.

cit_valid = df["citation"].notna() & (df["citation"] != "")
dup_mask  = df.duplicated("citation", keep=False) & cit_valid

dup_groups = df[dup_mask].groupby("citation")

drop_ids = set()
for citation, grp in dup_groups:
    # Check if case names are similar (genuine dupe) or very different (false positive)
    names = grp["case_name"].tolist()
    # Normalize: lowercase first plaintiff name
    def lead(n):
        return re.sub(r'\s+', ' ', n.split(' v ')[0].lower().strip()[:30])
    leads = [lead(n) for n in names]
    unique_leads = set(leads)

    if len(unique_leads) == 1 or len(unique_leads) <= max(1, len(grp)//2):
        # Genuine duplicates — keep longest
        keep_idx = grp["word_count"].idxmax()
        for idx in grp.index:
            if idx != keep_idx:
                drop_ids.add(idx)
                excluded.append({**df.loc[idx].to_dict(),
                                  "exclusion_reason": f"Duplicate citation ({citation}) — shorter copy"})

print(f"Stage 1 — Duplicate citations removed: {len(drop_ids)}")
df = df.drop(index=list(drop_ids)).reset_index(drop=True)

# ── STAGE 2: Very short documents (< 500 words) ──────────────────────────────
short_mask = df["word_count"] < 500
short_df   = df[short_mask]
for idx, row in short_df.iterrows():
    excluded.append({**row.to_dict(),
                     "exclusion_reason": f"Too short ({row['word_count']} words) — likely stub/order"})
df = df[~short_mask].reset_index(drop=True)
print(f"Stage 2 — Short docs removed: {short_mask.sum()}")

# ── STAGE 3: Relevance filter ─────────────────────────────────────────────────
# Flag cases that are clearly outside securities/shareholder litigation:
# tax cases, domestic relations, pure property/real estate, criminal (non-SEC),
# workers comp, patent (non-securities), etc.

IRRELEVANT_PATTERNS = [
    # Domestic / family
    (r'\bdivorce\b|\bmarital\b|\bspouse\b|\balimony\b|\bcustody\b', "Domestic relations"),
    # Tax (non-securities)
    (r'\bCommissioner of Internal Revenue\b|\bI\.R\.S\b|\bincome tax\b|\btax court\b', "Tax/IRS matter"),
    # Real property / municipal assessors
    (r'\bAssessors? of\b|\breal property tax\b|\bproperty assessment\b', "Property tax/assessment"),
    # Workers compensation
    (r'\bworkers?\s+comp|\bworkmen.s\s+comp', "Workers compensation"),
    # Pure contract / no securities nexus — catch only if also no theories
    # (we use absence of theories as secondary signal below)
]

IRRELEVANT_NAMES = [
    # Confirmed non-securities from profiling review
    "Stancil v Stancil",
    "Castriota v Castriota",
    "People ex rel Lincoln v Assessors of Town of Barton",
    "Shereff v Commissioner of Internal Revenue",
    "Quirke v Norfolk And W Ry Co",
    "Pirilla v Bonucci",
    "Mann v Butler",
    "Pollitz v Wabash R Co",
    "In re Thomas",
]

irrel_drop = set()

for idx, row in df.iterrows():
    case_name = str(row["case_name"])
    theories  = str(row["theories"]) if pd.notna(row["theories"]) else ""
    court_lvl = str(row["court_level"])
    text_proxy = case_name + " " + str(row["court"])

    # Check known irrelevant names
    for bad_name in IRRELEVANT_NAMES:
        if bad_name.lower() in case_name.lower():
            irrel_drop.add(idx)
            excluded.append({**row.to_dict(),
                             "exclusion_reason": f"Irrelevant — confirmed non-securities ({bad_name})"})
            break

    if idx in irrel_drop:
        continue

    # Check pattern-based irrelevance
    for pat, reason in IRRELEVANT_PATTERNS:
        if re.search(pat, text_proxy, re.I):
            # Secondary check: if it has securities theories, keep it
            if not theories or theories == "nan":
                irrel_drop.add(idx)
                excluded.append({**row.to_dict(),
                                 "exclusion_reason": f"Irrelevant — {reason}, no securities theories"})
                break

print(f"Stage 3 — Irrelevant cases removed: {len(irrel_drop)}")
df = df.drop(index=list(irrel_drop)).reset_index(drop=True)

# ── SAVE OUTPUTS ─────────────────────────────────────────────────────────────
df.to_csv(CLEAN_CSV, index=False)

excl_df = pd.DataFrame(excluded)
excl_df.to_csv(EXCLUDED_CSV, index=False)

print(f"\n{'='*50}")
print(f"Final cleaned corpus N = {len(df)}")
print(f"Total excluded         = {len(excluded)}")
print(f"\nExclusion breakdown:")
print(excl_df["exclusion_reason"].str.extract(r'^([^—(]+)')[0].str.strip().value_counts().to_string())
print(f"\nCleaned CSV  → {CLEAN_CSV}")
print(f"Excluded CSV → {EXCLUDED_CSV}")
