"""
NLP/ML Pipeline — Shareholder & Securities Litigation Corpus (N=883)
Stages:
  A. Text preprocessing (tokenize, stopwords, lemmatize)
  B. TF-IDF vectorization + top terms
  C. LDA topic modeling (k=10)
  D. Outcome classification (Random Forest + Logistic Regression)
  E. Save all outputs
"""

import json, re, csv
from pathlib import Path
from collections import Counter
import numpy as np
import pandas as pd

from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn.decomposition import LatentDirichletAllocation, NMF
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.metrics import classification_report
from sklearn.preprocessing import LabelEncoder
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS

TEXTS_JSON  = "/home/claude/securities_texts.json"
CLEAN_CSV   = "/home/claude/securities_corpus_cleaned.csv"
OUT_DIR     = Path("/home/claude/pipeline_outputs")
OUT_DIR.mkdir(exist_ok=True)

# ══════════════════════════════════════════════════════════════════════════════
# A. LOAD & PREPROCESS
# ══════════════════════════════════════════════════════════════════════════════
print("A. Loading corpus...")
with open(TEXTS_JSON) as f:
    corpus_dict = json.load(f)

df_meta = pd.read_csv(CLEAN_CSV)
filenames = list(df_meta["filename"])

# Align texts to metadata order
texts_raw = [corpus_dict.get(fn, "") for fn in filenames]

# Legal domain stopwords (added to sklearn base)
LEGAL_STOP = {
    "court","plaintiff","defendant","case","action","claims","claim","alleged",
    "allege","alleging","complaint","appeal","appellate","district","circuit",
    "opinion","judge","honor","pursuant","order","motion","section","rule",
    "act","law","federal","states","united","new","york","inc","corp","co",
    "ltd","llc","also","may","would","shall","must","however","therefore",
    "thus","whether","although","pursuant","upon","per","see","id","ibid",
    "supra","infra","fn","note","cf","eg","ie","p","pp","v","vs","et","al",
    "slip","op","aff","rev","remanded","affirmed","reversed","denied",
    "granted","held","holding","court","judge","justice","hon","honorable",
    "therein","herein","thereof","hereof","therefrom","heretofore","hereafter",
    "whereas","whereby","wherein","hereinafter","said","such","under","above",
    "below","within","without","among","between","against","behalf","respect",
}
ALL_STOP = ENGLISH_STOP_WORDS.union(LEGAL_STOP)

def preprocess(text):
    """Lowercase, strip numbers/punctuation, remove stopwords, keep 4+ char tokens."""
    text = text.lower()
    text = re.sub(r'\d+', ' ', text)
    text = re.sub(r'[^a-z\s]', ' ', text)
    tokens = text.split()
    tokens = [t for t in tokens if len(t) >= 4 and t not in ALL_STOP]
    return " ".join(tokens)

print("   Preprocessing texts...")
texts_clean = [preprocess(t) for t in texts_raw]
print(f"   Done. Vocab sample: {texts_clean[0][:200]}")

# ══════════════════════════════════════════════════════════════════════════════
# B. TF-IDF
# ══════════════════════════════════════════════════════════════════════════════
print("\nB. TF-IDF vectorization...")
tfidf = TfidfVectorizer(max_features=5000, min_df=5, max_df=0.85, ngram_range=(1,2))
X_tfidf = tfidf.fit_transform(texts_clean)
print(f"   TF-IDF matrix: {X_tfidf.shape}")

# Top 30 overall terms by mean TF-IDF score
mean_tfidf = np.asarray(X_tfidf.mean(axis=0)).flatten()
feature_names = tfidf.get_feature_names_out()
top_idx = mean_tfidf.argsort()[::-1][:30]
top_terms = [(feature_names[i], round(float(mean_tfidf[i]),5)) for i in top_idx]

print("   Top 30 TF-IDF terms:")
for term, score in top_terms:
    print(f"     {term}: {score}")

# Save top terms
with open(OUT_DIR / "tfidf_top_terms.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["term","mean_tfidf"])
    w.writerows(top_terms)

# ══════════════════════════════════════════════════════════════════════════════
# C. LDA TOPIC MODELING
# ══════════════════════════════════════════════════════════════════════════════
print("\nC. LDA Topic Modeling (k=10)...")
count_vec = CountVectorizer(max_features=5000, min_df=5, max_df=0.85, ngram_range=(1,2))
X_count = count_vec.fit_transform(texts_clean)
count_features = count_vec.get_feature_names_out()

lda = LatentDirichletAllocation(
    n_components=10, max_iter=30, learning_method="online",
    random_state=42, n_jobs=-1
)
lda.fit(X_count)
doc_topics = lda.transform(X_count)   # shape (883, 10)
dominant_topic = doc_topics.argmax(axis=1)

# Top 15 words per topic
def top_words(model, feature_names, n=15):
    topics = []
    for i, comp in enumerate(model.components_):
        top_w = [feature_names[j] for j in comp.argsort()[::-1][:n]]
        topics.append(top_w)
    return topics

lda_topics = top_words(lda, count_features)

print("   LDA Topics:")
topic_labels = {}
for i, words in enumerate(lda_topics):
    print(f"   Topic {i}: {', '.join(words[:10])}")

# Save LDA topics
with open(OUT_DIR / "lda_topics.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["topic_id"] + [f"word_{j+1}" for j in range(15)])
    for i, words in enumerate(lda_topics):
        w.writerow([i] + words)

# Save doc-topic assignments
df_topics = df_meta.copy()
for t in range(10):
    df_topics[f"topic_{t}_prob"] = doc_topics[:, t].round(4)
df_topics["dominant_topic"] = dominant_topic
df_topics.to_csv(OUT_DIR / "doc_topic_assignments.csv", index=False)

# ── NMF for robustness ────────────────────────────────────────────────────────
print("\n   NMF robustness check (k=10)...")
nmf = NMF(n_components=10, random_state=42, max_iter=400)
nmf.fit(X_tfidf)
nmf_topics = top_words(nmf, feature_names)
print("   NMF Topics:")
for i, words in enumerate(nmf_topics):
    print(f"   NMF Topic {i}: {', '.join(words[:10])}")

with open(OUT_DIR / "nmf_topics.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["topic_id"] + [f"word_{j+1}" for j in range(15)])
    for i, words in enumerate(nmf_topics):
        w.writerow([i] + words)

# ══════════════════════════════════════════════════════════════════════════════
# D. OUTCOME CLASSIFICATION
# ══════════════════════════════════════════════════════════════════════════════
print("\nD. Outcome Classification...")

# Build binary label: Dismissed/Defendant Win = 0 (defense prevails)
#                     Plaintiff Win/Certified/Settled = 1 (plaintiff prevails)
# Cases with ambiguous/missing outcomes are excluded from classification

def label_outcome(outcome_str):
    if pd.isna(outcome_str) or outcome_str == "":
        return None
    o = outcome_str.lower()
    # Plaintiff-favorable
    if any(x in o for x in ["plaintiff win","certified","settled","reversed"]):
        return 1
    # Defense-favorable
    if any(x in o for x in ["dismissed","defendant win","summary judgment","denied cert","affirmed"]):
        return 0
    return None

df_meta["outcome_label"] = df_meta["outcome"].apply(label_outcome)
labeled = df_meta["outcome_label"].notna()
print(f"   Labeled cases: {labeled.sum()} / {len(df_meta)}")
print(f"   Class distribution:")
print(df_meta.loc[labeled, "outcome_label"].value_counts().to_string())

if labeled.sum() >= 50:
    X_clf = X_tfidf[labeled.values]
    y_clf = df_meta.loc[labeled, "outcome_label"].astype(int).values

    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000, C=1.0, random_state=42),
        "Random Forest":       RandomForestClassifier(n_estimators=200, random_state=42, n_jobs=-1),
        "Linear SVC":          LinearSVC(max_iter=2000, C=1.0, random_state=42),
    }

    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    clf_results = []

    for name, model in models.items():
        scores = cross_val_score(model, X_clf, y_clf, cv=skf,
                                  scoring="f1_weighted", n_jobs=-1)
        acc    = cross_val_score(model, X_clf, y_clf, cv=skf,
                                  scoring="accuracy", n_jobs=-1)
        clf_results.append({
            "model": name,
            "f1_weighted_mean": round(scores.mean(), 4),
            "f1_weighted_std":  round(scores.std(),  4),
            "accuracy_mean":    round(acc.mean(),    4),
            "accuracy_std":     round(acc.std(),     4),
        })
        print(f"   {name}: F1={scores.mean():.4f} ± {scores.std():.4f}  Acc={acc.mean():.4f}")

    clf_df = pd.DataFrame(clf_results)
    clf_df.to_csv(OUT_DIR / "classification_results.csv", index=False)

    # Feature importance from best model (Logistic Regression coefficients)
    best_lr = LogisticRegression(max_iter=1000, C=1.0, random_state=42)
    best_lr.fit(X_clf, y_clf)
    coefs = best_lr.coef_[0]
    top_plaintiff = [(feature_names[i], round(float(coefs[i]),4))
                     for i in coefs.argsort()[::-1][:20]]
    top_defense   = [(feature_names[i], round(float(coefs[i]),4))
                     for i in coefs.argsort()[:20]]

    print("\n   Top plaintiff-predictive terms:")
    for t,s in top_plaintiff: print(f"     {t}: {s}")
    print("\n   Top defense-predictive terms:")
    for t,s in top_defense: print(f"     {t}: {s}")

    with open(OUT_DIR / "lr_feature_importance.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["term","coef","direction"])
        for t,s in top_plaintiff:
            w.writerow([t, s, "plaintiff-favorable"])
        for t,s in top_defense:
            w.writerow([t, s, "defense-favorable"])
else:
    print("   Insufficient labeled cases for classification — skipping.")

print(f"\nAll outputs saved to {OUT_DIR}/")
print("Files:")
for f in sorted(OUT_DIR.iterdir()):
    print(f"  {f.name}")
