"""
Comprehensive Descriptive Analytics
Shareholder & Securities Litigation Corpus (N=883)

Sections:
  1.  Corpus overview
  2.  Temporal distribution (by year and decade)
  3.  Court level distribution
  4.  Circuit / jurisdiction distribution
  5.  Legal theory frequency
  6.  Legal theory co-occurrence matrix
  7.  Outcome distribution
  8.  Outcome × Court level cross-tab
  9.  Outcome × Theory cross-tab (top theories)
  10. Document length statistics
  11. Vocabulary richness
  12. Top TF-IDF bigrams
  13. Theory × Decade heatmap data
  14. Circuit × Theory cross-tab
  15. Summary statistics table
"""

import json, re, csv
from pathlib import Path
from collections import Counter, defaultdict
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer, ENGLISH_STOP_WORDS

CLEAN_CSV  = "/home/claude/securities_corpus_cleaned.csv"
TEXTS_JSON = "/home/claude/securities_texts.json"
OUT        = Path("/home/claude/descriptive_outputs")
OUT.mkdir(exist_ok=True)

print("Loading data...")
df = pd.read_csv(CLEAN_CSV)
with open(TEXTS_JSON) as f:
    corpus_dict = json.load(f)

texts = [corpus_dict.get(fn, "") for fn in df["filename"]]
N = len(df)
print(f"N = {N} cases loaded.\n")

# ── helpers ───────────────────────────────────────────────────────────────────
THEORIES = [
    'Rule 10b-5','Section 10(b)','Section 11','Section 12','Section 14',
    'Section 20(a)','Rule 14a-9','Fiduciary Duty','Insider Trading','Proxy',
    'Fraud','Misrepresentation','Class Action','Derivative','Tender Offer',
    'Merger','Short-swing','PSLRA','RICO','Standing','Scienter','Loss Causation'
]
OUTCOMES = [
    'Affirmed','Reversed','Remanded','Dismissed','Summary Judgment',
    'Settled','Plaintiff Win','Defendant Win','Certified','Denied Cert'
]

def has_theory(row, theory):
    t = str(row.get("theories",""))
    return theory in t

def has_outcome(row, outcome):
    o = str(row.get("outcome",""))
    return outcome in o

def decade(year):
    if pd.isna(year): return "Unknown"
    y = int(year)
    return f"{(y//10)*10}s"

df["decade"] = df["year"].apply(decade)

# ══════════════════════════════════════════════════════════════════════════════
# 1. CORPUS OVERVIEW
# ══════════════════════════════════════════════════════════════════════════════
print("1. Corpus overview...")
yr = df["year"].dropna().astype(int)
wc = df["word_count"]

overview = {
    "Total cases (N)": N,
    "Year range": f"{yr.min()}–{yr.max()}",
    "Median year": int(yr.median()),
    "Mean year": round(yr.mean(), 1),
    "Cases with year identified": int(yr.count()),
    "Cases with citation identified": int((df["citation"].notna() & (df["citation"]!="")).sum()),
    "Cases with court identified": int((df["court_level"]!="Unknown").sum()),
    "Cases with theories identified": int((df["theories"].notna() & (df["theories"]!="")).sum()),
    "Cases with outcome identified": int((df["outcome"].notna() & (df["outcome"]!="")).sum()),
    "Mean word count": round(wc.mean(), 0),
    "Median word count": round(wc.median(), 0),
    "Min word count": int(wc.min()),
    "Max word count": int(wc.max()),
    "Total words (corpus)": int(wc.sum()),
}
pd.DataFrame(list(overview.items()), columns=["Metric","Value"])\
  .to_csv(OUT/"01_corpus_overview.csv", index=False)
for k,v in overview.items():
    print(f"   {k}: {v}")

# ══════════════════════════════════════════════════════════════════════════════
# 2. TEMPORAL DISTRIBUTION
# ══════════════════════════════════════════════════════════════════════════════
print("\n2. Temporal distribution...")
yr_counts = df["year"].dropna().astype(int).value_counts().sort_index()
yr_df = yr_counts.reset_index()
yr_df.columns = ["year","case_count"]
yr_df.to_csv(OUT/"02_temporal_by_year.csv", index=False)

dec_counts = df["decade"].value_counts().sort_index()
dec_df = dec_counts.reset_index()
dec_df.columns = ["decade","case_count"]
# Add pct
dec_df["pct"] = (dec_df["case_count"] / N * 100).round(1)
dec_df.to_csv(OUT/"02_temporal_by_decade.csv", index=False)
print(dec_df.to_string(index=False))

# ══════════════════════════════════════════════════════════════════════════════
# 3. COURT LEVEL DISTRIBUTION
# ══════════════════════════════════════════════════════════════════════════════
print("\n3. Court level distribution...")
cl = df["court_level"].value_counts().reset_index()
cl.columns = ["court_level","count"]
cl["pct"] = (cl["count"] / N * 100).round(1)
cl.to_csv(OUT/"03_court_level.csv", index=False)
print(cl.to_string(index=False))

# ══════════════════════════════════════════════════════════════════════════════
# 4. CIRCUIT / JURISDICTION
# ══════════════════════════════════════════════════════════════════════════════
print("\n4. Circuit distribution...")
circ = df[df["circuit"]!=""]["circuit"].value_counts().reset_index()
circ.columns = ["circuit","count"]
circ["pct"] = (circ["count"] / N * 100).round(1)
circ.to_csv(OUT/"04_circuit_distribution.csv", index=False)
print(circ.to_string(index=False))

# ══════════════════════════════════════════════════════════════════════════════
# 5. LEGAL THEORY FREQUENCY
# ══════════════════════════════════════════════════════════════════════════════
print("\n5. Legal theory frequency...")
theory_freq = []
for t in THEORIES:
    count = df["theories"].fillna("").apply(lambda x: t in x).sum()
    theory_freq.append({"theory": t, "count": int(count), "pct": round(count/N*100,1)})
theory_df = pd.DataFrame(theory_freq).sort_values("count", ascending=False)
theory_df.to_csv(OUT/"05_theory_frequency.csv", index=False)
print(theory_df.to_string(index=False))

# ══════════════════════════════════════════════════════════════════════════════
# 6. THEORY CO-OCCURRENCE MATRIX
# ══════════════════════════════════════════════════════════════════════════════
print("\n6. Theory co-occurrence matrix...")
top_theories = theory_df.head(12)["theory"].tolist()
comat = pd.DataFrame(0, index=top_theories, columns=top_theories)
for _, row in df.iterrows():
    theories_present = [t for t in top_theories if t in str(row["theories"])]
    for i, t1 in enumerate(theories_present):
        for t2 in theories_present:
            comat.loc[t1, t2] += 1
comat.to_csv(OUT/"06_theory_cooccurrence.csv")
print(f"   Co-occurrence matrix saved ({len(top_theories)}×{len(top_theories)})")
# Print top pairs
pairs = []
for i in range(len(top_theories)):
    for j in range(i+1, len(top_theories)):
        t1, t2 = top_theories[i], top_theories[j]
        pairs.append((t1, t2, comat.loc[t1,t2]))
pairs.sort(key=lambda x: -x[2])
print("   Top co-occurring theory pairs:")
for t1,t2,c in pairs[:10]:
    print(f"     {t1} + {t2}: {c}")

# ══════════════════════════════════════════════════════════════════════════════
# 7. OUTCOME DISTRIBUTION
# ══════════════════════════════════════════════════════════════════════════════
print("\n7. Outcome distribution...")
out_freq = []
for o in OUTCOMES:
    count = df["outcome"].fillna("").apply(lambda x: o in x).sum()
    out_freq.append({"outcome": o, "count": int(count), "pct": round(count/N*100,1)})
out_df = pd.DataFrame(out_freq).sort_values("count", ascending=False)
out_df.to_csv(OUT/"07_outcome_distribution.csv", index=False)
print(out_df.to_string(index=False))

missing_out = (df["outcome"].isna() | (df["outcome"]=="")).sum()
print(f"   No outcome keyword: {missing_out} cases ({missing_out/N*100:.1f}%)")

# ══════════════════════════════════════════════════════════════════════════════
# 8. OUTCOME × COURT LEVEL
# ══════════════════════════════════════════════════════════════════════════════
print("\n8. Outcome × Court level...")
rows = []
for cl_val in ["District","Circuit","SCOTUS","State-Supreme","State-Chancery"]:
    sub = df[df["court_level"]==cl_val]
    row = {"court_level": cl_val, "n": len(sub)}
    for o in ["Dismissed","Affirmed","Reversed","Remanded","Plaintiff Win","Settled"]:
        row[o] = int(sub["outcome"].fillna("").apply(lambda x: o in x).sum())
    rows.append(row)
oc_ct = pd.DataFrame(rows)
oc_ct.to_csv(OUT/"08_outcome_x_court.csv", index=False)
print(oc_ct.to_string(index=False))

# ══════════════════════════════════════════════════════════════════════════════
# 9. OUTCOME × THEORY (top 8 theories)
# ══════════════════════════════════════════════════════════════════════════════
print("\n9. Outcome × Theory...")
top8 = theory_df.head(8)["theory"].tolist()
rows = []
for t in top8:
    sub = df[df["theories"].fillna("").str.contains(re.escape(t))]
    row = {"theory": t, "n": len(sub)}
    for o in ["Dismissed","Affirmed","Reversed","Plaintiff Win","Settled"]:
        row[o] = int(sub["outcome"].fillna("").apply(lambda x: o in x).sum())
    row["dismiss_rate"] = round(row["Dismissed"]/len(sub)*100, 1) if len(sub) else 0
    rows.append(row)
ot_df = pd.DataFrame(rows)
ot_df.to_csv(OUT/"09_outcome_x_theory.csv", index=False)
print(ot_df.to_string(index=False))

# ══════════════════════════════════════════════════════════════════════════════
# 10. DOCUMENT LENGTH STATISTICS
# ══════════════════════════════════════════════════════════════════════════════
print("\n10. Document length statistics...")
wc_stats = df["word_count"].describe().round(1)
wc_stats.to_csv(OUT/"10_wordcount_stats.csv", header=["value"])

# By court level
wc_by_court = df.groupby("court_level")["word_count"].agg(
    ["count","mean","median","std","min","max"]
).round(0).sort_values("mean", ascending=False)
wc_by_court.to_csv(OUT/"10_wordcount_by_court.csv")
print(wc_by_court.to_string())

# By decade
wc_by_dec = df[df["decade"]!="Unknown"].groupby("decade")["word_count"].agg(
    ["count","mean","median"]
).round(0)
wc_by_dec.to_csv(OUT/"10_wordcount_by_decade.csv")
print(wc_by_dec.to_string())

# ══════════════════════════════════════════════════════════════════════════════
# 11. VOCABULARY RICHNESS (Type-Token Ratio by decade)
# ══════════════════════════════════════════════════════════════════════════════
print("\n11. Vocabulary richness by decade...")
LEGAL_STOP = {
    "court","plaintiff","defendant","case","action","claims","claim","alleged",
    "allege","alleging","complaint","appeal","appellate","district","circuit",
    "opinion","judge","honor","pursuant","order","motion","section","rule",
    "act","law","federal","states","united","new","york","inc","corp","co",
    "ltd","llc","also","may","would","shall","must","however","therefore",
    "thus","whether","although","upon","per","see","said","such","under",
}
ALL_STOP = ENGLISH_STOP_WORDS.union(LEGAL_STOP)

def clean_tokens(text):
    text = re.sub(r'\d+','',text.lower())
    text = re.sub(r'[^a-z\s]',' ',text)
    return [t for t in text.split() if len(t)>=4 and t not in ALL_STOP]

voc_rows = []
for dec_val in sorted(df["decade"].unique()):
    if dec_val == "Unknown": continue
    subset = df[df["decade"]==dec_val]
    all_tokens = []
    for fn in subset["filename"]:
        all_tokens.extend(clean_tokens(corpus_dict.get(fn,"")))
    if not all_tokens: continue
    ttr = round(len(set(all_tokens))/len(all_tokens)*100, 2)
    voc_rows.append({
        "decade": dec_val,
        "cases": len(subset),
        "total_tokens": len(all_tokens),
        "unique_types": len(set(all_tokens)),
        "ttr_pct": ttr,
        "avg_tokens_per_case": round(len(all_tokens)/len(subset), 0)
    })
voc_df = pd.DataFrame(voc_rows)
voc_df.to_csv(OUT/"11_vocabulary_richness.csv", index=False)
print(voc_df.to_string(index=False))

# ══════════════════════════════════════════════════════════════════════════════
# 12. TOP TF-IDF UNIGRAMS AND BIGRAMS
# ══════════════════════════════════════════════════════════════════════════════
print("\n12. Top TF-IDF terms by type...")
clean_texts = [" ".join(clean_tokens(corpus_dict.get(fn,""))) for fn in df["filename"]]

for ngram, label in [((1,1),"unigrams"), ((2,2),"bigrams"), ((1,2),"combined")]:
    vec = TfidfVectorizer(max_features=3000, min_df=5, max_df=0.85,
                          ngram_range=ngram)
    X = vec.fit_transform(clean_texts)
    means = np.asarray(X.mean(axis=0)).flatten()
    fnames = vec.get_feature_names_out()
    top_idx = means.argsort()[::-1][:30]
    top = pd.DataFrame([(fnames[i], round(float(means[i]),5))
                         for i in top_idx], columns=["term","mean_tfidf"])
    top.to_csv(OUT/f"12_tfidf_top_{label}.csv", index=False)
    print(f"   Top 10 {label}: {', '.join(top['term'].head(10).tolist())}")

# ══════════════════════════════════════════════════════════════════════════════
# 13. THEORY × DECADE HEATMAP DATA
# ══════════════════════════════════════════════════════════════════════════════
print("\n13. Theory × Decade heatmap...")
decades_ordered = [d for d in sorted(df["decade"].unique()) if d != "Unknown"]
top10_theories  = theory_df.head(10)["theory"].tolist()

heat_rows = []
for t in top10_theories:
    row = {"theory": t}
    for d in decades_ordered:
        sub = df[df["decade"]==d]
        cnt = sub["theories"].fillna("").apply(lambda x: t in x).sum()
        # As % of cases in that decade
        pct = round(cnt/len(sub)*100, 1) if len(sub) else 0
        row[d] = pct
    heat_rows.append(row)
heat_df = pd.DataFrame(heat_rows).set_index("theory")
heat_df.to_csv(OUT/"13_theory_x_decade_heatmap.csv")
print(heat_df.to_string())

# ══════════════════════════════════════════════════════════════════════════════
# 14. CIRCUIT × THEORY CROSS-TAB
# ══════════════════════════════════════════════════════════════════════════════
print("\n14. Circuit × Theory...")
top_circuits = ["Second","Third","Fifth","Seventh","Ninth"]
top6_theories = theory_df.head(6)["theory"].tolist()
ct_rows = []
for circ_val in top_circuits:
    sub = df[df["circuit"]==circ_val]
    row = {"circuit": circ_val, "n": len(sub)}
    for t in top6_theories:
        cnt = sub["theories"].fillna("").apply(lambda x: t in x).sum()
        row[t] = f"{cnt} ({round(cnt/len(sub)*100,0):.0f}%)" if len(sub) else "0"
    ct_rows.append(row)
ct_df = pd.DataFrame(ct_rows)
ct_df.to_csv(OUT/"14_circuit_x_theory.csv", index=False)
print(ct_df.to_string(index=False))

# ══════════════════════════════════════════════════════════════════════════════
# 15. SUMMARY STATISTICS TABLE (for Methods/Results section)
# ══════════════════════════════════════════════════════════════════════════════
print("\n15. Summary statistics table...")
summary = [
    ("Corpus", "", ""),
    ("Total cases (N)", N, ""),
    ("Year range", f"{yr.min()}–{yr.max()}", ""),
    ("Median decision year", int(yr.median()), ""),
    ("", "", ""),
    ("Document Length", "", ""),
    ("Mean word count", round(wc.mean(),0), "words"),
    ("Median word count", round(wc.median(),0), "words"),
    ("SD word count", round(wc.std(),0), "words"),
    ("Range", f"{int(wc.min())}–{int(wc.max())}", "words"),
    ("", "", ""),
    ("Court Level", "", ""),
]
for _, r in cl.iterrows():
    summary.append((f"  {r['court_level']}", r['count'], f"{r['pct']}%"))
summary += [
    ("", "", ""),
    ("Top Circuits (of labeled cases)", "", ""),
]
for _, r in circ.head(5).iterrows():
    summary.append((f"  {r['circuit']} Circuit", r['count'], f"{r['pct']}%"))
summary += [
    ("", "", ""),
    ("Legal Theories (top 5)", "", ""),
]
for _, r in theory_df.head(5).iterrows():
    summary.append((f"  {r['theory']}", r['count'], f"{r['pct']}%"))
summary += [
    ("", "", ""),
    ("Outcomes (top 5)", "", ""),
]
for _, r in out_df.head(5).iterrows():
    summary.append((f"  {r['outcome']}", r['count'], f"{r['pct']}%"))

sum_df = pd.DataFrame(summary, columns=["Metric","Value","Note"])
sum_df.to_csv(OUT/"15_summary_statistics.csv", index=False)
print("   Summary table saved.")

print(f"\n{'='*60}")
print(f"All descriptive analytics saved to {OUT}/")
print(f"Files generated: {len(list(OUT.iterdir()))}")
for f in sorted(OUT.iterdir()):
    print(f"  {f.name}")
