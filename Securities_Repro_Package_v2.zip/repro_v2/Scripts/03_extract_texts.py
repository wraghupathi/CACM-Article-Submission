"""
Stage 1: Full Text Extraction & Cleaning
Reads the 883 cleaned cases, extracts full text via PyMuPDF,
strips Westlaw boilerplate, and saves a JSON corpus file.
Output: securities_texts.json  {filename: cleaned_text}
"""

import json, re
from pathlib import Path
import fitz
import pandas as pd

CORPUS_DIR = Path("/home/claude/securities_all")
CLEAN_CSV  = "/home/claude/securities_corpus_cleaned.csv"
OUT_JSON   = "/home/claude/securities_texts.json"

df = pd.read_csv(CLEAN_CSV)
print(f"Extracting text for {len(df)} cases...")

# ── Westlaw boilerplate patterns to strip ────────────────────────────────────
STRIP_PATTERNS = [
    r'Raghupathi,\s+Wullianallur\s+\d+/\d+/\d+\s*\n?',
    r'For Educational Use Only\s*\n?',
    r'© \d{4} Thomson Reuters\. No claim to original U\.S\. Government Works\.\s*\n?',
    r'END OF DOCUMENT\s*',
    r'Westlaw\s+\w+\s+\d+/\d+/\d+\s*\n?',
    r'\*{1,4}\d+\s*',          # page star markers  *1  **2
    r'^\s*\d+\s*$',             # lone page numbers
]

def clean_text(raw):
    text = raw
    for pat in STRIP_PATTERNS:
        text = re.sub(pat, ' ', text, flags=re.MULTILINE | re.IGNORECASE)
    # Collapse whitespace
    text = re.sub(r'\n{3,}', '\n\n', text)
    text = re.sub(r'[ \t]{2,}', ' ', text)
    return text.strip()

def extract_pdf(path):
    try:
        doc = fitz.open(str(path))
        raw = " ".join(page.get_text() for page in doc)
        doc.close()
        return clean_text(raw)
    except Exception as e:
        return ""

corpus = {}
errors = []

for i, row in df.iterrows():
    if (i+1) % 100 == 0:
        print(f"  {i+1}/{len(df)}...")
    pdf_path = CORPUS_DIR / row["filename"]
    text = extract_pdf(pdf_path)
    if text:
        corpus[row["filename"]] = text
    else:
        errors.append(row["filename"])

with open(OUT_JSON, "w", encoding="utf-8") as f:
    json.dump(corpus, f, ensure_ascii=False)

print(f"\nExtracted: {len(corpus)} texts")
print(f"Errors:    {len(errors)}")
if errors:
    for e in errors: print(f"  {e}")
print(f"Saved → {OUT_JSON}")
