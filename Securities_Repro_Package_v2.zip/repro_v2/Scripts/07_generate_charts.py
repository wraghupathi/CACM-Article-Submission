"""
Chart Generation — All Descriptive Analytics
Shareholder & Securities Litigation Corpus (N=883)
"""

import json, re
from pathlib import Path
from collections import Counter
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.gridspec import GridSpec
import seaborn as sns
from wordcloud import WordCloud
from sklearn.feature_extraction.text import TfidfVectorizer, ENGLISH_STOP_WORDS

OUT     = Path("/home/claude/descriptive_outputs")
CHARTS  = Path("/home/claude/charts")
CHARTS.mkdir(exist_ok=True)

# ── style ──────────────────────────────────────────────────────────────────────
NAVY   = "#1B3A6B"
STEEL  = "#2E75B6"
GOLD   = "#C4A32B"
SLATE  = "#5A7FA8"
SMOKE  = "#E8EEF5"
CORAL  = "#C0392B"
GREEN  = "#1E8449"
GREY   = "#7F8C8D"

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "axes.spines.top":   False,
    "axes.spines.right": False,
    "axes.titlesize":    13,
    "axes.labelsize":    11,
    "xtick.labelsize":   9,
    "ytick.labelsize":   9,
    "figure.dpi":        150,
    "savefig.bbox":      "tight",
    "savefig.dpi":       150,
})

df   = pd.read_csv("/home/claude/securities_corpus_cleaned.csv")
with open("/home/claude/securities_texts.json") as f:
    corpus_dict = json.load(f)

LEGAL_STOP = {'court','plaintiff','defendant','case','action','claims','claim',
    'alleged','allege','complaint','appeal','appellate','district','circuit',
    'opinion','judge','pursuant','order','motion','section','rule','act','law',
    'federal','states','united','new','york','inc','corp','co','ltd','llc',
    'also','may','would','shall','must','however','therefore','thus','whether',
    'although','upon','per','see','said','such','under'}
ALL_STOP = ENGLISH_STOP_WORDS.union(LEGAL_STOP)

def clean_tokens(text):
    text = re.sub(r'\d+','',text.lower())
    text = re.sub(r'[^a-z\s]',' ',text)
    return [t for t in text.split() if len(t)>=4 and t not in ALL_STOP]

filenames   = list(df["filename"])
texts_raw   = [corpus_dict.get(fn,"") for fn in filenames]
tokens_list = [clean_tokens(t) for t in texts_raw]
texts_clean = [" ".join(toks) for toks in tokens_list]

def savefig(name):
    p = CHARTS/name
    plt.savefig(p, bbox_inches="tight")
    plt.close()
    print(f"  Saved: {name}")

# ══════════════════════════════════════════════════════════════════════════════
# CHART 1: Temporal distribution by decade
# ══════════════════════════════════════════════════════════════════════════════
print("Chart 1: Temporal distribution...")
dec_df = pd.read_csv(OUT/"02_temporal_by_decade.csv")
dec_df = dec_df[dec_df["decade"]!="Unknown"]

fig, ax = plt.subplots(figsize=(10,5))
bars = ax.bar(dec_df["decade"], dec_df["case_count"],
              color=STEEL, edgecolor="white", linewidth=0.8)
for bar, val in zip(bars, dec_df["case_count"]):
    ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()+2,
            str(val), ha="center", va="bottom", fontsize=9, color=NAVY)
ax.set_xlabel("Decade"); ax.set_ylabel("Number of Cases")
ax.set_title("Fig. 1 — Temporal Distribution of Securities Litigation Cases by Decade (N=883)", 
             fontweight="bold", pad=12)
ax.set_facecolor(SMOKE); fig.patch.set_facecolor("white")
ax.yaxis.grid(True, alpha=0.4, linestyle="--")
ax.set_axisbelow(True)
savefig("chart01_temporal_decade.png")

# ══════════════════════════════════════════════════════════════════════════════
# CHART 2: Court level distribution (pie + bar combo)
# ══════════════════════════════════════════════════════════════════════════════
print("Chart 2: Court level...")
cl_df = pd.read_csv(OUT/"03_court_level.csv")
colors = [NAVY, STEEL, SLATE, GOLD, CORAL, GREEN, GREY, "#A569BD"][:len(cl_df)]

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5))
wedges, texts, autotexts = ax1.pie(
    cl_df["count"], labels=None,
    autopct=lambda p: f"{p:.1f}%" if p > 2 else "",
    colors=colors, startangle=140,
    wedgeprops={"edgecolor":"white","linewidth":1.5})
for at in autotexts: at.set_fontsize(8); at.set_color("white"); at.set_fontweight("bold")
ax1.legend(wedges, cl_df["court_level"], loc="lower left", fontsize=8,
           bbox_to_anchor=(-0.15, -0.1))
ax1.set_title("Court Level Distribution", fontweight="bold")

ax2.barh(cl_df["court_level"][::-1], cl_df["count"][::-1], color=colors[::-1], edgecolor="white")
for i, (val, pct) in enumerate(zip(cl_df["count"][::-1], cl_df["pct"][::-1])):
    ax2.text(val+3, i, f"{val} ({pct}%)", va="center", fontsize=8.5)
ax2.set_xlabel("Number of Cases")
ax2.set_title("Case Count by Court Level", fontweight="bold")
ax2.set_facecolor(SMOKE)
ax2.xaxis.grid(True, alpha=0.4, linestyle="--"); ax2.set_axisbelow(True)
fig.suptitle("Fig. 2 — Court Level Distribution (N=883)", fontweight="bold", y=1.02)
savefig("chart02_court_level.png")

# ══════════════════════════════════════════════════════════════════════════════
# CHART 3: Circuit distribution
# ══════════════════════════════════════════════════════════════════════════════
print("Chart 3: Circuit...")
circ_df = pd.read_csv(OUT/"04_circuit_distribution.csv")

fig, ax = plt.subplots(figsize=(9, 5))
palette = [NAVY if c=="Second" else STEEL for c in circ_df["circuit"]]
bars = ax.bar(circ_df["circuit"], circ_df["count"], color=palette, edgecolor="white")
for bar, val, pct in zip(bars, circ_df["count"], circ_df["pct"]):
    ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.5,
            f"{val}\n({pct}%)", ha="center", va="bottom", fontsize=8, color=NAVY)
ax.set_xlabel("Circuit"); ax.set_ylabel("Number of Cases")
ax.set_title("Fig. 3 — Cases by Federal Circuit (N=883)", fontweight="bold", pad=12)
ax.set_facecolor(SMOKE)
ax.yaxis.grid(True, alpha=0.4, linestyle="--"); ax.set_axisbelow(True)
savefig("chart03_circuit.png")

# ══════════════════════════════════════════════════════════════════════════════
# CHART 4: Legal theory frequency (horizontal bar)
# ══════════════════════════════════════════════════════════════════════════════
print("Chart 4: Theory frequency...")
th_df = pd.read_csv(OUT/"05_theory_frequency.csv").sort_values("count")

fig, ax = plt.subplots(figsize=(10, 8))
colors_th = [NAVY if i >= len(th_df)-6 else STEEL for i in range(len(th_df))]
bars = ax.barh(th_df["theory"], th_df["count"], color=colors_th, edgecolor="white")
for bar, val, pct in zip(bars, th_df["count"], th_df["pct"]):
    ax.text(bar.get_width()+4, bar.get_y()+bar.get_height()/2,
            f"{val} ({pct}%)", va="center", fontsize=8.5)
ax.set_xlabel("Number of Cases")
ax.set_title("Fig. 4 — Legal Theory Frequency (N=883, multiple theories per case)",
             fontweight="bold", pad=12)
ax.set_facecolor(SMOKE)
ax.xaxis.grid(True, alpha=0.4, linestyle="--"); ax.set_axisbelow(True)
ax.set_xlim(0, 500)
savefig("chart04_theory_frequency.png")

# ══════════════════════════════════════════════════════════════════════════════
# CHART 5: Outcome distribution
# ══════════════════════════════════════════════════════════════════════════════
print("Chart 5: Outcome...")
out_df = pd.read_csv(OUT/"07_outcome_distribution.csv").sort_values("count", ascending=False)

fig, ax = plt.subplots(figsize=(10, 5))
colors_out = [CORAL if o in ["Dismissed","Defendant Win","Denied Cert"]
              else GREEN if o in ["Plaintiff Win","Certified","Settled","Reversed"]
              else STEEL for o in out_df["outcome"]]
bars = ax.bar(out_df["outcome"], out_df["count"], color=colors_out, edgecolor="white")
for bar, val, pct in zip(bars, out_df["count"], out_df["pct"]):
    ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()+2,
            f"{val}\n({pct}%)", ha="center", va="bottom", fontsize=8.5)
ax.set_ylabel("Number of Cases")
ax.set_title("Fig. 5 — Outcome Distribution (N=555 labeled cases)",
             fontweight="bold", pad=12)
ax.set_facecolor(SMOKE)
ax.yaxis.grid(True, alpha=0.4, linestyle="--"); ax.set_axisbelow(True)
legend_patches = [mpatches.Patch(color=CORAL, label="Defense-favorable"),
                  mpatches.Patch(color=GREEN, label="Plaintiff-favorable"),
                  mpatches.Patch(color=STEEL, label="Procedural")]
ax.legend(handles=legend_patches, fontsize=9, loc="upper right")
plt.xticks(rotation=20, ha="right")
savefig("chart05_outcomes.png")

# ══════════════════════════════════════════════════════════════════════════════
# CHART 6: Theory × Decade heatmap
# ══════════════════════════════════════════════════════════════════════════════
print("Chart 6: Theory × Decade heatmap...")
heat_df = pd.read_csv(OUT/"13_theory_x_decade_heatmap.csv", index_col="theory")
# Drop very small decades
heat_df = heat_df[[c for c in heat_df.columns if c not in ["1930s","1940s","1950s"]]]

fig, ax = plt.subplots(figsize=(12, 6))
sns.heatmap(heat_df, annot=True, fmt=".0f", cmap="Blues",
            linewidths=0.5, linecolor="white",
            cbar_kws={"label":"% of Cases in Decade"},
            ax=ax, annot_kws={"size":8})
ax.set_title("Fig. 6 — Legal Theory Prevalence by Decade (% of cases in decade)",
             fontweight="bold", pad=12)
ax.set_xlabel("Decade"); ax.set_ylabel("")
plt.xticks(rotation=30, ha="right")
savefig("chart06_theory_decade_heatmap.png")

# ══════════════════════════════════════════════════════════════════════════════
# CHART 7: Theory co-occurrence heatmap
# ══════════════════════════════════════════════════════════════════════════════
print("Chart 7: Theory co-occurrence...")
coo = pd.read_csv(OUT/"06_theory_cooccurrence.csv", index_col=0)

fig, ax = plt.subplots(figsize=(11, 9))
mask = np.eye(len(coo), dtype=bool)
sns.heatmap(coo, annot=True, fmt="d", cmap="YlOrRd",
            mask=mask, linewidths=0.5, linecolor="white",
            cbar_kws={"label":"Co-occurrence Count"}, ax=ax,
            annot_kws={"size":7.5})
ax.set_title("Fig. 7 — Legal Theory Co-occurrence Matrix (top 12 theories)",
             fontweight="bold", pad=12)
plt.xticks(rotation=40, ha="right"); plt.yticks(rotation=0)
savefig("chart07_cooccurrence_heatmap.png")

# ══════════════════════════════════════════════════════════════════════════════
# CHART 8: Word Cloud (unigrams)
# ══════════════════════════════════════════════════════════════════════════════
print("Chart 8: Word cloud...")
wc_data = pd.read_csv(OUT/"B1_wordcloud_data.csv")
freq_dict = dict(zip(wc_data["word"], wc_data["frequency"]))

wc = WordCloud(width=1200, height=600, background_color="white",
               colormap="Blues", max_words=120, prefer_horizontal=0.85,
               collocations=False, random_state=42,
               min_font_size=8).generate_from_frequencies(freq_dict)

fig, ax = plt.subplots(figsize=(14, 7))
ax.imshow(wc, interpolation="bilinear")
ax.axis("off")
ax.set_title("Fig. 8 — Word Cloud: Most Frequent Terms in Securities Litigation Corpus (N=883)",
             fontweight="bold", pad=10)
savefig("chart08_wordcloud.png")

# ══════════════════════════════════════════════════════════════════════════════
# CHART 9: Cosine similarity distribution
# ══════════════════════════════════════════════════════════════════════════════
print("Chart 9: Cosine similarity distribution...")
sim_hist = pd.read_csv(OUT/"B4_cosine_distribution.csv")
stats    = pd.read_csv(OUT/"B4_cosine_similarity_stats.csv").set_index("metric")["value"]

fig, ax = plt.subplots(figsize=(9, 5))
ax.bar(sim_hist["bin_left"], sim_hist["count"], width=0.045,
       color=STEEL, edgecolor="white", alpha=0.85, align="edge")
ax.axvline(float(stats["mean"]), color=CORAL, linestyle="--", linewidth=1.5,
           label=f"Mean = {stats['mean']}")
ax.axvline(float(stats["median"]), color=GOLD, linestyle=":", linewidth=1.8,
           label=f"Median = {stats['median']}")
ax.set_xlabel("Cosine Similarity Score")
ax.set_ylabel("Number of Document Pairs")
ax.set_title("Fig. 9 — Document Pair Cosine Similarity Distribution\n"
             f"(500 random pairs; 73.4% < 0.10 indicating high corpus diversity)",
             fontweight="bold", pad=10)
ax.legend(fontsize=9); ax.set_facecolor(SMOKE)
ax.yaxis.grid(True, alpha=0.4, linestyle="--"); ax.set_axisbelow(True)
savefig("chart09_cosine_similarity.png")

# ══════════════════════════════════════════════════════════════════════════════
# CHART 10: LDA topics (sklearn, k=10) — bubble / word bar chart
# ══════════════════════════════════════════════════════════════════════════════
print("Chart 10: LDA topics...")
lda_df = pd.read_csv(OUT/"lda_topics.csv")

TOPIC_LABELS = [
    "Derivative &\nFiduciary Duty",
    "Merger &\nValuation",
    "RICO &\nSummary Judgment",
    "Proxy Contests",
    "Securities Fraud\n(10b-5)",
    "Investment\nFunds",
    "Purchase-Sale\nTransactions",
    "Bankruptcy\n& SLUSA",
    "Merger Proxy\nDisclosure",
    "Tender Offers\n(Williams Act)",
]

fig, axes = plt.subplots(2, 5, figsize=(18, 8))
axes = axes.flatten()
cmap = plt.cm.Blues

for i, (_, row) in enumerate(lda_df.iterrows()):
    ax = axes[i]
    words = [row[f"word_{j+1}"] for j in range(8)]
    # Use rank-based bar lengths
    vals  = [8-j for j in range(8)]
    colors_t = [cmap(0.4 + 0.07*j) for j in range(8)][::-1]
    ax.barh(words[::-1], vals[::-1], color=colors_t, edgecolor="white")
    ax.set_xlim(0, 10); ax.axis("off")
    ax.set_title(f"Topic {i}\n{TOPIC_LABELS[i]}", fontsize=9, fontweight="bold",
                 color=NAVY, pad=4)
    for j, (w, v) in enumerate(zip(words[::-1], vals[::-1])):
        ax.text(0.15, j, w, va="center", fontsize=8, color="white" if v>4 else NAVY)

fig.suptitle("Fig. 10 — LDA Topic Model (k=10): Top 8 Terms per Topic",
             fontweight="bold", fontsize=13, y=1.01)
plt.tight_layout()
savefig("chart10_lda_topics.png")

# ══════════════════════════════════════════════════════════════════════════════
# CHART 11: Gensim LDA topics (k=10)
# ══════════════════════════════════════════════════════════════════════════════
print("Chart 11: Gensim LDA topics...")
g_lda = pd.read_csv(OUT/"B7_gensim_lda_k10_topics.csv")
doc_t  = pd.read_csv(OUT/"B7_gensim_lda_k10_doc_topics.csv")
dom_counts = doc_t["dominant_topic"].value_counts().sort_index()

GENSIM_LABELS = [
    "Fiduciary/\nDerivative/Merger",
    "Bankruptcy/\nReliance",
    "Merger Proxy\nDisclosure",
    "Proxy Board\nGovernance",
    "Tender Offer\nAgreements",
    "Shareholder\nMeetings",
    "Tender Offer\nMarket",
    "Securities\nFraud/PSLRA",
    "Class Action\nDismissal",
    "Issuer/\nWilliams Act",
]

fig, axes = plt.subplots(2, 5, figsize=(18, 8))
axes = axes.flatten()
for i, (_, row) in enumerate(g_lda.iterrows()):
    ax = axes[i]
    words = [row[f"word_{j+1}"] for j in range(8)]
    vals  = [8-j for j in range(8)]
    colors_t = [cmap(0.4+0.07*j) for j in range(8)][::-1]
    ax.barh(words[::-1], vals[::-1], color=colors_t, edgecolor="white")
    ax.set_xlim(0,10); ax.axis("off")
    n_docs = dom_counts.get(i, 0)
    ax.set_title(f"Topic {i} ({n_docs} docs)\n{GENSIM_LABELS[i]}",
                 fontsize=9, fontweight="bold", color=NAVY, pad=4)
    for j,(w,v) in enumerate(zip(words[::-1], vals[::-1])):
        ax.text(0.15, j, w, va="center", fontsize=8, color="white" if v>4 else NAVY)

fig.suptitle("Fig. 11 — Gensim LDA (k=10, C_v=0.394): Top 8 Terms per Topic",
             fontweight="bold", fontsize=13, y=1.01)
plt.tight_layout()
savefig("chart11_gensim_lda_topics.png")

# ══════════════════════════════════════════════════════════════════════════════
# CHART 12: Outcome × Theory dismiss rates
# ══════════════════════════════════════════════════════════════════════════════
print("Chart 12: Outcome × Theory...")
ot_df = pd.read_csv(OUT/"09_outcome_x_theory.csv")

fig, ax = plt.subplots(figsize=(10, 5))
colors_dr = [CORAL if r>40 else GOLD if r>33 else GREEN for r in ot_df["dismiss_rate"]]
bars = ax.bar(ot_df["theory"], ot_df["dismiss_rate"], color=colors_dr, edgecolor="white")
for bar, val in zip(bars, ot_df["dismiss_rate"]):
    ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.5,
            f"{val}%", ha="center", va="bottom", fontsize=9, fontweight="bold")
ax.axhline(37.1, color=GREY, linestyle="--", linewidth=1.2, label="Corpus avg. dismissal rate (37.1%)")
ax.set_ylabel("Dismissal Rate (%)")
ax.set_title("Fig. 12 — Dismissal Rate by Legal Theory",
             fontweight="bold", pad=12)
ax.set_facecolor(SMOKE)
ax.yaxis.grid(True, alpha=0.4, linestyle="--"); ax.set_axisbelow(True)
ax.legend(fontsize=9); ax.set_ylim(0,60)
plt.xticks(rotation=20, ha="right")
savefig("chart12_dismissal_by_theory.png")

# ══════════════════════════════════════════════════════════════════════════════
# CHART 13: Document length by decade (box approximation with mean/median bars)
# ══════════════════════════════════════════════════════════════════════════════
print("Chart 13: Document length trends...")
wcd = pd.read_csv(OUT/"10_wordcount_by_decade.csv")
wcd = wcd[wcd["decade"]!="Unknown"]
df["decade"] = df["year"].apply(lambda y: f"{(int(y)//10)*10}s" if pd.notna(y) else "Unknown")
df_dec = df[df["decade"]!="Unknown"]

fig, ax = plt.subplots(figsize=(10,5))
decades = sorted(df_dec["decade"].unique())
data = [df_dec[df_dec["decade"]==d]["word_count"].values for d in decades]
bp = ax.boxplot(data, labels=decades, patch_artist=True,
                medianprops={"color":GOLD,"linewidth":2},
                boxprops={"facecolor":STEEL,"alpha":0.6},
                flierprops={"marker":"o","markersize":3,"alpha":0.3,"color":GREY},
                whiskerprops={"color":NAVY},
                capprops={"color":NAVY})
ax.set_xlabel("Decade"); ax.set_ylabel("Word Count")
ax.set_title("Fig. 13 — Opinion Length Distribution by Decade\n"
             "(Opinions growing longer in recent decades)",
             fontweight="bold", pad=10)
ax.set_facecolor(SMOKE)
ax.yaxis.grid(True, alpha=0.4, linestyle="--"); ax.set_axisbelow(True)
savefig("chart13_wordcount_by_decade.png")

# ══════════════════════════════════════════════════════════════════════════════
# CHART 14: NMF topics
# ══════════════════════════════════════════════════════════════════════════════
print("Chart 14: NMF topics...")
nmf_df = pd.read_csv(OUT/"nmf_topics.csv")

NMF_LABELS = [
    "Class Action\n& RICO",
    "Tender Offer\n(Williams Act)",
    "Proxy Solicitation\n& Board",
    "PSLRA /\nScienter",
    "Purchase-Sale\n(Birnbaum)",
    "Bankruptcy /\nSLUSA",
    "Merger &\nMinority Shareholders",
    "SLUSA\nCarve-out",
    "Short-swing\nProfits (§16b)",
    "Derivative &\nInvestment Funds",
]

fig, axes = plt.subplots(2, 5, figsize=(18, 8))
axes = axes.flatten()
cmap2 = plt.cm.Oranges
for i, (_, row) in enumerate(nmf_df.iterrows()):
    ax = axes[i]
    words = [row[f"word_{j+1}"] for j in range(8)]
    vals  = [8-j for j in range(8)]
    colors_t = [cmap2(0.35+0.08*j) for j in range(8)][::-1]
    ax.barh(words[::-1], vals[::-1], color=colors_t, edgecolor="white")
    ax.set_xlim(0,10); ax.axis("off")
    ax.set_title(f"NMF Topic {i}\n{NMF_LABELS[i]}", fontsize=9, fontweight="bold",
                 color="#7D3C00", pad=4)
    for j,(w,v) in enumerate(zip(words[::-1], vals[::-1])):
        ax.text(0.15, j, w, va="center", fontsize=8, color="white" if v>4 else "#7D3C00")

fig.suptitle("Fig. 14 — NMF Topic Model (k=10): Robustness Check — Top 8 Terms per Topic",
             fontweight="bold", fontsize=13, y=1.01)
plt.tight_layout()
savefig("chart14_nmf_topics.png")

print(f"\nAll charts saved to {CHARTS}/")
print(f"Total charts: {len(list(CHARTS.iterdir()))}")
for f in sorted(CHARTS.iterdir()):
    print(f"  {f.name}")
