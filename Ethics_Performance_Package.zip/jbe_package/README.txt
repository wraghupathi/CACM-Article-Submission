JBE ETHICS-PERFORMANCE PAPER: ANALYSIS PACKAGE
===============================================
"Does Ethics Communication Create Value?"
Target: Journal of Business Ethics | March 2026

INPUT: Ethics_Financial_Merged_Panel.csv (1,891 firm-years, 397 firms)
ALL random_state=42, HC1 robust SE, winsorized TQ at 1/99%

code/  - 4 Python scripts (fully reproducible)
results/ - All CSV outputs + complete summary
JBE_Ethics_Performance_Outline.docx - Paper outline mirroring JMS

STILL NEEDED: Boilerplate moderation (H8) requires JD-level position data
