"""Analysis 3: Cross-Dimension Interactions"""
import pandas as pd
import numpy as np
import statsmodels.api as sm
import warnings
warnings.filterwarnings('ignore')

df = pd.read_csv('/mnt/user-data/uploads/Ethics_Financial_Merged_Panel.csv')
df['ln_size'] = np.log(df['Firm Size'])
df = df.replace([np.inf, -np.inf], np.nan)
for col in ["Tobin's Q", 'ROA', 'ROE']:
    lower, upper = df[col].quantile(0.01), df[col].quantile(0.99)
    df[col] = df[col].clip(lower, upper)

for col in ['ethics_governance', 'ethics_social', 'ethics_environmental', 'ethics_legal',
            'ln_size', 'Leverage', 'R&D Intensity']:
    if col in df.columns:
        df[col + '_std'] = (df[col] - df[col].mean()) / df[col].std()

df_rd = df.dropna(subset=['R&D Intensity']).copy()

# Year and industry FE
yr_dum = pd.get_dummies(df_rd['fyear'], prefix='yr', drop_first=True).astype(float)
ind_dum = pd.get_dummies(df_rd['gsector'], prefix='ind', drop_first=True).astype(float)
df_reg = pd.concat([df_rd.reset_index(drop=True), yr_dum.reset_index(drop=True), ind_dum.reset_index(drop=True)], axis=1)

fe_cols = list(yr_dum.columns) + list(ind_dum.columns)
controls = ['ln_size_std', 'Leverage_std', 'R&D Intensity_std']
dims = ['ethics_governance_std', 'ethics_social_std', 'ethics_environmental_std', 'ethics_legal_std']
dim_labels = ['Governance', 'Social', 'Environmental', 'Legal']

print("="*80)
print("ANALYSIS 3: CROSS-DIMENSION INTERACTION EFFECTS ON TOBIN'S Q")
print("(Parallel to JMS Table 7)")
print("="*80)

# Create all pairwise interactions
interaction_terms = []
interaction_labels = []
for i in range(len(dims)):
    for j in range(i+1, len(dims)):
        col_name = f'{dims[i]}_x_{dims[j].replace("ethics_","").replace("_std","")}'
        df_reg[col_name] = df_reg[dims[i]] * df_reg[dims[j]]
        interaction_terms.append(col_name)
        interaction_labels.append(f'{dim_labels[i]} × {dim_labels[j]}')

x_cols = dims + interaction_terms + controls + fe_cols
valid = df_reg[["Tobin's Q"] + x_cols].dropna()
y = valid["Tobin's Q"].values.astype(float)
X = sm.add_constant(valid[x_cols].values.astype(float))

model = sm.OLS(y, X).fit(cov_type='HC1')

print(f"\nN = {int(model.nobs)}, R² = {model.rsquared:.6f}")
print(f"\n{'Variable':<30} {'β':>10} {'SE':>10} {'p':>10}")
print("-"*62)

# Main effects
for i, label in enumerate(dim_labels):
    idx = i + 1
    sig = '***' if model.pvalues[idx] < 0.001 else '**' if model.pvalues[idx] < 0.01 else '*' if model.pvalues[idx] < 0.05 else '†' if model.pvalues[idx] < 0.10 else ''
    print(f"{label:<30} {model.params[idx]:>10.6f} {model.bse[idx]:>10.6f} {model.pvalues[idx]:>10.6f} {sig}")

print()
# Interactions
for i, label in enumerate(interaction_labels):
    idx = len(dims) + i + 1
    sig = '***' if model.pvalues[idx] < 0.001 else '**' if model.pvalues[idx] < 0.01 else '*' if model.pvalues[idx] < 0.05 else '†' if model.pvalues[idx] < 0.10 else ''
    print(f"{label:<30} {model.params[idx]:>10.6f} {model.bse[idx]:>10.6f} {model.pvalues[idx]:>10.6f} {sig}")

print()
# Controls
for i, label in enumerate(['Firm Size', 'Leverage', 'R&D Intensity']):
    idx = len(dims) + len(interaction_terms) + i + 1
    sig = '***' if model.pvalues[idx] < 0.001 else '**' if model.pvalues[idx] < 0.01 else '*' if model.pvalues[idx] < 0.05 else '†' if model.pvalues[idx] < 0.10 else ''
    print(f"{label:<30} {model.params[idx]:>10.6f} {model.bse[idx]:>10.6f} {model.pvalues[idx]:>10.6f} {sig}")

# Save
rows = []
for i, label in enumerate(dim_labels):
    idx = i + 1
    rows.append({'Variable': label, 'coef': model.params[idx], 'se': model.bse[idx], 'p': model.pvalues[idx]})
for i, label in enumerate(interaction_labels):
    idx = len(dims) + i + 1
    rows.append({'Variable': label, 'coef': model.params[idx], 'se': model.bse[idx], 'p': model.pvalues[idx]})
pd.DataFrame(rows).to_csv('/home/claude/Table_Cross_Interactions.csv', index=False)

