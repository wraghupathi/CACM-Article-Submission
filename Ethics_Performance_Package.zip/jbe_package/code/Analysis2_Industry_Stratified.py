"""Analysis 2: Industry-Stratified Ethics Dimension Regressions"""
import pandas as pd
import numpy as np
import statsmodels.api as sm
import warnings
warnings.filterwarnings('ignore')

df = pd.read_csv('/mnt/user-data/uploads/Ethics_Financial_Merged_Panel.csv')
df['ln_size'] = np.log(df['Firm Size'])
df = df.replace([np.inf, -np.inf], np.nan)
for col in ["Tobin's Q", 'ROA', 'ROE']:
    lower, upper = df[col].quantile(0.01), df[col].quantile(0.99)
    df[col] = df[col].clip(lower, upper)

for col in ['ethics_governance', 'ethics_social', 'ethics_environmental', 'ethics_legal',
            'ln_size', 'Leverage', 'R&D Intensity']:
    if col in df.columns:
        df[col + '_std'] = (df[col] - df[col].mean()) / df[col].std()

sector_labels = {
    10: 'Energy', 15: 'Materials', 20: 'Industrials', 25: 'Cons. Discret.',
    30: 'Cons. Staples', 35: 'Health Care', 40: 'Financials', 45: 'Info Tech',
    50: 'Communication', 55: 'Utilities', 60: 'Real Estate'
}

df_rd = df.dropna(subset=['R&D Intensity']).copy()

print("="*80)
print("ANALYSIS 2: INDUSTRY-STRATIFIED ETHICS DIMENSION REGRESSIONS")
print("(Parallel to JMS Table 6)")
print("="*80)

dim_std = ['ethics_governance_std', 'ethics_social_std', 'ethics_environmental_std', 'ethics_legal_std']
controls = ['ln_size_std', 'Leverage_std', 'R&D Intensity_std']

results = []

for sector_code in sorted(df_rd['gsector'].unique()):
    sub = df_rd[df_rd['gsector'] == sector_code].copy()
    n = len(sub)
    label = sector_labels.get(int(sector_code), str(int(sector_code)))
    
    if n < 30:
        print(f"\n{label} (N={n}): SKIPPED — too few observations")
        continue
    
    # Re-standardize within subsample? No — keep global standardization for comparability
    # Year FE only (no industry FE within sector)
    yr_dum = pd.get_dummies(sub['fyear'], prefix='yr', drop_first=True).astype(float)
    sub = pd.concat([sub.reset_index(drop=True), yr_dum.reset_index(drop=True)], axis=1)
    
    fe_cols = list(yr_dum.columns)
    x_cols = dim_std + controls + fe_cols
    
    # Check we have enough variation
    valid = sub[["Tobin's Q"] + x_cols].dropna()
    if len(valid) < len(x_cols) + 5:
        print(f"\n{label} (N={n}): SKIPPED — insufficient df")
        continue
    
    y = valid["Tobin's Q"].values.astype(float)
    X = sm.add_constant(valid[x_cols].values.astype(float))
    
    try:
        model = sm.OLS(y, X).fit(cov_type='HC1')
        row = {'Sector': label, 'N': int(model.nobs)}
        for i, dim in enumerate(['Governance', 'Social', 'Environmental', 'Legal']):
            idx = i + 1  # +1 for constant
            row[f'{dim}_beta'] = model.params[idx]
            row[f'{dim}_p'] = model.pvalues[idx]
        row['R2'] = model.rsquared
        results.append(row)
        
        print(f"\n{label} (N={int(model.nobs)}, R²={model.rsquared:.3f}):")
        for i, dim in enumerate(['Governance', 'Social', 'Environmental', 'Legal']):
            idx = i + 1
            sig = '***' if model.pvalues[idx] < 0.001 else '**' if model.pvalues[idx] < 0.01 else '*' if model.pvalues[idx] < 0.05 else '†' if model.pvalues[idx] < 0.10 else ''
            print(f"  {dim:<15} β = {model.params[idx]:>8.3f}  (p = {model.pvalues[idx]:.4f}) {sig}")
    except Exception as e:
        print(f"\n{label} (N={n}): ERROR — {e}")

# Save results
results_df = pd.DataFrame(results)
results_df.to_csv('/home/claude/Table_Industry_Stratified.csv', index=False)

print("\n\n" + "="*80)
print("SUMMARY TABLE")
print("="*80)
print(f"\n{'Sector':<18} {'N':>4}  {'Gov β':>8} {'Soc β':>8} {'Env β':>8} {'Leg β':>8}  {'R²':>5}")
print("-"*72)
for _, r in results_df.iterrows():
    gov_sig = '***' if r['Governance_p'] < 0.001 else '**' if r['Governance_p'] < 0.01 else '*' if r['Governance_p'] < 0.05 else '†' if r['Governance_p'] < 0.10 else ''
    soc_sig = '***' if r['Social_p'] < 0.001 else '**' if r['Social_p'] < 0.01 else '*' if r['Social_p'] < 0.05 else '†' if r['Social_p'] < 0.10 else ''
    env_sig = '***' if r['Environmental_p'] < 0.001 else '**' if r['Environmental_p'] < 0.01 else '*' if r['Environmental_p'] < 0.05 else '†' if r['Environmental_p'] < 0.10 else ''
    leg_sig = '***' if r['Legal_p'] < 0.001 else '**' if r['Legal_p'] < 0.01 else '*' if r['Legal_p'] < 0.05 else '†' if r['Legal_p'] < 0.10 else ''
    print(f"{r['Sector']:<18} {int(r['N']):>4}  {r['Governance_beta']:>7.3f}{gov_sig:<3} {r['Social_beta']:>7.3f}{soc_sig:<3} {r['Environmental_beta']:>7.3f}{env_sig:<3} {r['Legal_beta']:>7.3f}{leg_sig:<3}  {r['R2']:.3f}")

