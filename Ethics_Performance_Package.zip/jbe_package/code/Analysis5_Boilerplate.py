"""
Analysis 5: Boilerplate Moderation (H8)
Maps JDs to companies via company_info start indices,
computes position features, aggregates to firm level,
merges with financial panel.
"""
import pandas as pd
import numpy as np
import re
import gc
import statsmodels.api as sm
import warnings
warnings.filterwarnings('ignore')

# =============================================================================
# STEP 1: Build JD → Ticker mapping from company_info
# =============================================================================
ci = pd.read_csv('/mnt/user-data/uploads/company_info_new.csv')
fp = pd.read_csv('/mnt/user-data/uploads/Ethics_Financial_Merged_Panel.csv')

# Only keep tickers that are in the financial panel
fp_tickers = set(fp['Ticker'].unique())

# Build mapping: original_idx (0-based) → Ticker
mapping = {}
for _, row in ci.iterrows():
    start = int(row['Unnamed: 0'])
    n = int(row['jd_num'])
    ticker = row['Ticker']
    for i in range(n):
        idx = start + i
        mapping[idx] = ticker

print(f"Mapping: {len(mapping)} JD indices → {len(set(mapping.values()))} tickers")
print(f"Of which {len(fp_tickers & set(mapping.values()))} are in financial panel")

# =============================================================================
# STEP 2: Load JDs, compute position features, assign tickers
# =============================================================================

# Ethics concept terms (from the analysis code)
ethics_concepts_flat = [
    'accountability', 'accounting', 'advertising', 'alcohol', 'antiboycott', 
    'antitrust', 'bribery', 'child labor', 'communication', 'compliance', 
    'confidential', 'conflict', 'corporate assets', 'corporate opportunities',
    'corruption', 'discrimination', 'diversity', 'drug', 'environmental',
    'equality', 'excellence', 'fair', 'fraud', 'gift', 'entertainment',
    'harassment', 'health', 'honesty', 'integrity', 'humanity', 'insider trading',
    'property', 'lobbying', 'loyalty', 'money laundering', 'politics', 'privacy',
    'quality', 'recording', 'respect', 'safety', 'sanction', 'security',
    'social responsibility', 'sustainability', 'transparency', 'trust', 'violation'
]

def compute_position_features(text):
    """Compute ethics position features for a single JD."""
    if not isinstance(text, str) or len(text.strip()) < 50:
        return None
    
    text_lower = text.lower()
    third = len(text) // 3
    if third == 0:
        return None
    
    beginning = text_lower[:third]
    middle = text_lower[third:2*third]
    end = text_lower[2*third:]
    
    beg_count = sum(1 for t in ethics_concepts_flat if t in beginning)
    mid_count = sum(1 for t in ethics_concepts_flat if t in middle)
    end_count = sum(1 for t in ethics_concepts_flat if t in end)
    total = max(beg_count + mid_count + end_count, 1)
    
    return {
        'ethics_beginning_ratio': beg_count / total,
        'ethics_middle_ratio': mid_count / total,
        'ethics_end_ratio': end_count / total,
        'ethics_position_concentration': max(beg_count, mid_count, end_count) / total,
        'ethics_end_heavy': 1 if end_count > beg_count + mid_count else 0,
        'total_ethics_mentions': beg_count + mid_count + end_count
    }

print("\nProcessing JD files...")
jd_results = []
chunk_files = ['PART1_part1', 'PART1_part2', 'PART1_part3', 'PART2_part1', 'PART2_part2', 'PART2_part3']

for part_name in chunk_files:
    f = f'/mnt/user-data/uploads/JD_ETHICS_WEIGHTED_{part_name}.csv'
    df = pd.read_csv(f)
    
    for _, row in df.iterrows():
        uid = int(row['job_uid'])
        original_idx = uid - 1  # uid is 1-based, mapping is 0-based
        
        ticker = mapping.get(original_idx)
        if ticker is None or ticker not in fp_tickers:
            continue
        
        features = compute_position_features(row['weighted_text'])
        if features is None:
            continue
        
        features['Ticker'] = ticker
        features['has_ethics_signal'] = row['has_ethics_signal']
        jd_results.append(features)
    
    print(f"  {part_name}: processed {len(df)} JDs (total mapped: {len(jd_results)})")
    del df; gc.collect()

jd_df = pd.DataFrame(jd_results)
print(f"\nTotal JDs mapped to FP tickers: {len(jd_df)}")
print(f"Unique tickers: {jd_df['Ticker'].nunique()}")

# =============================================================================
# STEP 3: Aggregate to firm level
# =============================================================================
firm_pos = jd_df.groupby('Ticker').agg(
    mean_beginning_ratio=('ethics_beginning_ratio', 'mean'),
    mean_middle_ratio=('ethics_middle_ratio', 'mean'),
    mean_end_ratio=('ethics_end_ratio', 'mean'),
    mean_position_concentration=('ethics_position_concentration', 'mean'),
    pct_end_heavy=('ethics_end_heavy', 'mean'),
    mean_ethics_mentions=('total_ethics_mentions', 'mean'),
    n_jds=('Ticker', 'count')
).reset_index()

print(f"\nFirm-level position features:")
print(f"  Firms: {len(firm_pos)}")
print(f"\nDescriptive stats:")
for col in ['mean_beginning_ratio', 'mean_end_ratio', 'mean_position_concentration', 'pct_end_heavy']:
    print(f"  {col}: mean={firm_pos[col].mean():.4f}, sd={firm_pos[col].std():.4f}, "
          f"min={firm_pos[col].min():.4f}, max={firm_pos[col].max():.4f}")

# Define boilerplate: firms with high end concentration
# Using pct_end_heavy (% of JDs where ethics terms are concentrated at the end)
median_end = firm_pos['pct_end_heavy'].median()
print(f"\nBoilerplate threshold (median pct_end_heavy): {median_end:.4f}")
firm_pos['boilerplate'] = (firm_pos['pct_end_heavy'] > median_end).astype(int)
print(f"Boilerplate firms: {firm_pos['boilerplate'].sum()} / {len(firm_pos)}")

# Also try: high position concentration (ethics terms concentrated in one section)
median_conc = firm_pos['mean_position_concentration'].median()
firm_pos['concentrated'] = (firm_pos['mean_position_concentration'] > median_conc).astype(int)

# =============================================================================
# STEP 4: Merge with financial panel and run regressions
# =============================================================================
fp['ln_size'] = np.log(fp['Firm Size'])
fp = fp.replace([np.inf, -np.inf], np.nan)
for col in ["Tobin's Q", 'ROA', 'ROE']:
    lower, upper = fp[col].quantile(0.01), fp[col].quantile(0.99)
    fp[col] = fp[col].clip(lower, upper)

merged = fp.merge(firm_pos[['Ticker', 'mean_end_ratio', 'mean_position_concentration', 
                             'pct_end_heavy', 'boilerplate', 'concentrated']], 
                   on='Ticker', how='inner')

print(f"\nMerged panel: {len(merged)} firm-years, {merged['Ticker'].nunique()} firms")

# Standardize
for col in ['ethics_composite', 'ethics_governance', 'ethics_social', 
            'ethics_environmental', 'ethics_legal', 'ln_size', 'Leverage', 
            'R&D Intensity', 'mean_end_ratio', 'mean_position_concentration', 'pct_end_heavy']:
    if col in merged.columns:
        merged[col + '_std'] = (merged[col] - merged[col].mean()) / merged[col].std()

# Drop missing R&D
merged_rd = merged.dropna(subset=['R&D Intensity']).copy()
print(f"After R&D filter: {len(merged_rd)} firm-years")

# FE dummies
yr_dum = pd.get_dummies(merged_rd['fyear'], prefix='yr', drop_first=True).astype(float)
ind_dum = pd.get_dummies(merged_rd['gsector'], prefix='ind', drop_first=True).astype(float)
df_reg = pd.concat([merged_rd.reset_index(drop=True), yr_dum.reset_index(drop=True), ind_dum.reset_index(drop=True)], axis=1)

fe_cols = list(yr_dum.columns) + list(ind_dum.columns)
controls = ['ln_size_std', 'Leverage_std', 'R&D Intensity_std']

print("\n" + "="*80)
print("ANALYSIS 5: BOILERPLATE MODERATION (H8)")
print("="*80)

# Model 1: Ethics + Boilerplate dummy + interaction
df_reg['ethics_x_boilerplate'] = df_reg['ethics_composite_std'] * df_reg['boilerplate']
x_cols = ['ethics_composite_std', 'boilerplate', 'ethics_x_boilerplate'] + controls + fe_cols
valid = df_reg[["Tobin's Q"] + x_cols].dropna()
y = valid["Tobin's Q"].values.astype(float)
X = sm.add_constant(valid[x_cols].values.astype(float))
model1 = sm.OLS(y, X).fit(cov_type='HC1')

print("\nModel 1: Ethics Composite × Boilerplate (end-heavy dummy)")
print(f"  N = {int(model1.nobs)}, R² = {model1.rsquared:.6f}")
labels1 = ['Ethics Composite', 'Boilerplate', 'Ethics × Boilerplate']
for i, label in enumerate(labels1):
    idx = i + 1
    sig = '***' if model1.pvalues[idx] < 0.001 else '**' if model1.pvalues[idx] < 0.01 else '*' if model1.pvalues[idx] < 0.05 else '†' if model1.pvalues[idx] < 0.10 else ''
    print(f"  {label:<25} β = {model1.params[idx]:>8.4f}, SE = {model1.bse[idx]:.4f}, p = {model1.pvalues[idx]:.4f} {sig}")

# Model 2: Governance + Boilerplate + interaction  
df_reg['gov_x_boilerplate'] = df_reg['ethics_governance_std'] * df_reg['boilerplate']
x_cols2 = ['ethics_governance_std', 'boilerplate', 'gov_x_boilerplate'] + controls + fe_cols
valid2 = df_reg[["Tobin's Q"] + x_cols2].dropna()
y2 = valid2["Tobin's Q"].values.astype(float)
X2 = sm.add_constant(valid2[x_cols2].values.astype(float))
model2 = sm.OLS(y2, X2).fit(cov_type='HC1')

print("\nModel 2: Governance × Boilerplate")
print(f"  N = {int(model2.nobs)}, R² = {model2.rsquared:.6f}")
labels2 = ['Governance', 'Boilerplate', 'Governance × Boilerplate']
for i, label in enumerate(labels2):
    idx = i + 1
    sig = '***' if model2.pvalues[idx] < 0.001 else '**' if model2.pvalues[idx] < 0.01 else '*' if model2.pvalues[idx] < 0.05 else '†' if model2.pvalues[idx] < 0.10 else ''
    print(f"  {label:<25} β = {model2.params[idx]:>8.4f}, SE = {model2.bse[idx]:.4f}, p = {model2.pvalues[idx]:.4f} {sig}")

# Model 3: Using continuous position concentration instead of dummy
df_reg['ethics_x_concentration'] = df_reg['ethics_composite_std'] * df_reg['mean_position_concentration_std']
x_cols3 = ['ethics_composite_std', 'mean_position_concentration_std', 'ethics_x_concentration'] + controls + fe_cols
valid3 = df_reg[["Tobin's Q"] + x_cols3].dropna()
y3 = valid3["Tobin's Q"].values.astype(float)
X3 = sm.add_constant(valid3[x_cols3].values.astype(float))
model3 = sm.OLS(y3, X3).fit(cov_type='HC1')

print("\nModel 3: Ethics Composite × Position Concentration (continuous)")
print(f"  N = {int(model3.nobs)}, R² = {model3.rsquared:.6f}")
labels3 = ['Ethics Composite', 'Position Concentration', 'Ethics × Concentration']
for i, label in enumerate(labels3):
    idx = i + 1
    sig = '***' if model3.pvalues[idx] < 0.001 else '**' if model3.pvalues[idx] < 0.01 else '*' if model3.pvalues[idx] < 0.05 else '†' if model3.pvalues[idx] < 0.10 else ''
    print(f"  {label:<25} β = {model3.params[idx]:>8.4f}, SE = {model3.bse[idx]:.4f}, p = {model3.pvalues[idx]:.4f} {sig}")

# Model 4: Split sample - boilerplate vs integrated
print("\nModel 4: Split Sample")
for label, mask in [('Boilerplate firms', df_reg['boilerplate'] == 1), 
                     ('Integrated firms', df_reg['boilerplate'] == 0)]:
    sub = df_reg[mask]
    x_sub = ['ethics_composite_std'] + controls + fe_cols
    valid_sub = sub[["Tobin's Q"] + x_sub].dropna()
    if len(valid_sub) < len(x_sub) + 5:
        print(f"  {label}: insufficient observations")
        continue
    y_sub = valid_sub["Tobin's Q"].values.astype(float)
    X_sub = sm.add_constant(valid_sub[x_sub].values.astype(float))
    model_sub = sm.OLS(y_sub, X_sub).fit(cov_type='HC1')
    sig = '***' if model_sub.pvalues[1] < 0.001 else '**' if model_sub.pvalues[1] < 0.01 else '*' if model_sub.pvalues[1] < 0.05 else '†' if model_sub.pvalues[1] < 0.10 else ''
    print(f"  {label:<25} β = {model_sub.params[1]:>8.4f}, SE = {model_sub.bse[1]:.4f}, p = {model_sub.pvalues[1]:.4f} {sig}  (N={int(model_sub.nobs)}, R²={model_sub.rsquared:.3f})")

# Model 5: Governance split sample
print("\nModel 5: Governance Split Sample")
for label, mask in [('Boilerplate firms', df_reg['boilerplate'] == 1), 
                     ('Integrated firms', df_reg['boilerplate'] == 0)]:
    sub = df_reg[mask]
    x_sub = ['ethics_governance_std'] + controls + fe_cols
    valid_sub = sub[["Tobin's Q"] + x_sub].dropna()
    if len(valid_sub) < len(x_sub) + 5:
        print(f"  {label}: insufficient observations")
        continue
    y_sub = valid_sub["Tobin's Q"].values.astype(float)
    X_sub = sm.add_constant(valid_sub[x_sub].values.astype(float))
    model_sub = sm.OLS(y_sub, X_sub).fit(cov_type='HC1')
    sig = '***' if model_sub.pvalues[1] < 0.001 else '**' if model_sub.pvalues[1] < 0.01 else '*' if model_sub.pvalues[1] < 0.05 else '†' if model_sub.pvalues[1] < 0.10 else ''
    print(f"  {label:<25} β = {model_sub.params[1]:>8.4f}, SE = {model_sub.bse[1]:.4f}, p = {model_sub.pvalues[1]:.4f} {sig}  (N={int(model_sub.nobs)}, R²={model_sub.rsquared:.3f})")

# Save firm-level position data
firm_pos.to_csv('/home/claude/firm_position_features.csv', index=False)
print(f"\nFirm position features saved: {len(firm_pos)} firms")

