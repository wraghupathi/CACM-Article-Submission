"""Analysis 4: Gradient Boosting + SHAP"""
import pandas as pd
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.model_selection import cross_val_score, train_test_split
from sklearn.preprocessing import StandardScaler
import shap
import warnings
warnings.filterwarnings('ignore')

df = pd.read_csv('/mnt/user-data/uploads/Ethics_Financial_Merged_Panel.csv')
df['ln_size'] = np.log(df['Firm Size'])
df = df.replace([np.inf, -np.inf], np.nan)
for col in ["Tobin's Q", 'ROA', 'ROE']:
    lower, upper = df[col].quantile(0.01), df[col].quantile(0.99)
    df[col] = df[col].clip(lower, upper)

df_rd = df.dropna(subset=['R&D Intensity']).copy()

# Features: 4 ethics dimensions + 3 controls + sector dummies
feature_cols = ['ethics_governance', 'ethics_social', 'ethics_environmental', 'ethics_legal',
                'ln_size', 'Leverage', 'R&D Intensity']

# Add sector dummies
ind_dum = pd.get_dummies(df_rd['gsector'], prefix='ind', drop_first=True).astype(float)
df_ml = pd.concat([df_rd[["Tobin's Q"] + feature_cols].reset_index(drop=True), 
                    ind_dum.reset_index(drop=True)], axis=1)
df_ml = df_ml.dropna()

feature_names = feature_cols + list(ind_dum.columns)
X = df_ml[feature_names].values
y = df_ml["Tobin's Q"].values

print("="*80)
print("ANALYSIS 4: MACHINE LEARNING COMPARISON + SHAP")
print("(Parallel to JMS Table 8)")
print("="*80)

# Train/test split (80/20, random_state=42 for reproducibility)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print(f"\nTrain: {len(X_train)}, Test: {len(X_test)}")

# Scale for Ridge
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Model 1: Ridge Regression
ridge = Ridge(alpha=1.0)
ridge.fit(X_train_scaled, y_train)
ridge_r2 = ridge.score(X_test_scaled, y_test)
ridge_rmse = np.sqrt(np.mean((ridge.predict(X_test_scaled) - y_test)**2))
print(f"\nRidge Regression:     R² = {ridge_r2:.4f}, RMSE = {ridge_rmse:.4f}")

# Model 2: Random Forest
rf = RandomForestRegressor(n_estimators=200, max_depth=15, random_state=42, n_jobs=-1)
rf.fit(X_train, y_train)
rf_r2 = rf.score(X_test, y_test)
rf_rmse = np.sqrt(np.mean((rf.predict(X_test) - y_test)**2))
print(f"Random Forest:        R² = {rf_r2:.4f}, RMSE = {rf_rmse:.4f}")

# Model 3: Gradient Boosting
gb = GradientBoostingRegressor(n_estimators=200, learning_rate=0.1, max_depth=4, random_state=42)
gb.fit(X_train, y_train)
gb_r2 = gb.score(X_test, y_test)
gb_rmse = np.sqrt(np.mean((gb.predict(X_test) - y_test)**2))
print(f"Gradient Boosting:    R² = {gb_r2:.4f}, RMSE = {gb_rmse:.4f}")

# 5-fold CV for GB
cv_scores = cross_val_score(
    GradientBoostingRegressor(n_estimators=200, learning_rate=0.1, max_depth=4, random_state=42),
    X, y, cv=5, scoring='r2'
)
print(f"GB 5-fold CV R²:      {cv_scores.mean():.4f} ± {cv_scores.std():.4f}")
print(f"  Individual folds:   {[f'{s:.4f}' for s in cv_scores]}")

# SHAP Analysis on Gradient Boosting
print("\n" + "-"*60)
print("SHAP Feature Importance (Gradient Boosting)")
print("-"*60)

explainer = shap.TreeExplainer(gb)
# Use test set for SHAP values
shap_values = explainer.shap_values(X_test)

# Mean absolute SHAP values
mean_abs_shap = np.abs(shap_values).mean(axis=0)

# Direction: mean SHAP value (positive = higher TQ, negative = lower TQ)
mean_shap = shap_values.mean(axis=0)

# Create results dataframe
shap_df = pd.DataFrame({
    'Feature': feature_names,
    'Mean_Abs_SHAP': mean_abs_shap,
    'Mean_SHAP': mean_shap
}).sort_values('Mean_Abs_SHAP', ascending=False)

print(f"\n{'Feature':<25} {'Mean |SHAP|':>12} {'Direction':>12}")
print("-"*52)
for _, row in shap_df.head(15).iterrows():
    direction = '↑ Higher TQ' if row['Mean_SHAP'] > 0.01 else '↓ Lower TQ' if row['Mean_SHAP'] < -0.01 else 'Mixed'
    print(f"{row['Feature']:<25} {row['Mean_Abs_SHAP']:>12.4f} {direction:>12}")

# Separate ethics-only importance
print("\n\nETHICS DIMENSIONS ONLY:")
print(f"{'Feature':<25} {'Mean |SHAP|':>12} {'Mean SHAP':>12} {'Direction':>12}")
print("-"*64)
ethics_dims = ['ethics_governance', 'ethics_social', 'ethics_environmental', 'ethics_legal']
for dim in ethics_dims:
    row = shap_df[shap_df['Feature'] == dim]
    if len(row) > 0:
        r = row.iloc[0]
        direction = '↑ Higher TQ' if r['Mean_SHAP'] > 0.005 else '↓ Lower TQ' if r['Mean_SHAP'] < -0.005 else 'Mixed'
        print(f"{r['Feature']:<25} {r['Mean_Abs_SHAP']:>12.4f} {r['Mean_SHAP']:>12.4f} {direction:>12}")

# SHAP Interaction Values (on smaller subset for computational efficiency)
print("\n" + "-"*60)
print("SHAP INTERACTION VALUES (Top 10 pairs)")
print("-"*60)

# Use subset for interaction computation
np.random.seed(42)
subset_idx = np.random.choice(len(X_test), min(200, len(X_test)), replace=False)
X_subset = X_test[subset_idx]

shap_interaction = explainer.shap_interaction_values(X_subset)

# Average absolute interaction values
n_features = shap_interaction.shape[2]
avg_interactions = np.abs(shap_interaction).mean(axis=0)

# Extract top pairs
pairs = []
for i in range(n_features):
    for j in range(i+1, n_features):
        pairs.append({
            'Feature_1': feature_names[i],
            'Feature_2': feature_names[j],
            'Interaction_Value': avg_interactions[i, j]
        })

pairs_df = pd.DataFrame(pairs).sort_values('Interaction_Value', ascending=False)

print(f"\n{'Feature 1':<22} {'Feature 2':<22} {'Interaction':>12}")
print("-"*58)
for _, row in pairs_df.head(10).iterrows():
    print(f"{row['Feature_1']:<22} {row['Feature_2']:<22} {row['Interaction_Value']:>12.4f}")

# Ethics-only interactions
print("\n\nETHICS DIMENSION INTERACTIONS ONLY:")
eth_pairs = pairs_df[
    (pairs_df['Feature_1'].str.startswith('ethics_')) & 
    (pairs_df['Feature_2'].str.startswith('ethics_'))
].head(10)
for _, row in eth_pairs.iterrows():
    print(f"  {row['Feature_1']:<22} × {row['Feature_2']:<22} = {row['Interaction_Value']:.4f}")

# Save all results
shap_df.to_csv('/home/claude/Table_SHAP_Importance.csv', index=False)
pairs_df.to_csv('/home/claude/Table_SHAP_Interactions.csv', index=False)

summary = {
    'Ridge_R2': ridge_r2, 'Ridge_RMSE': ridge_rmse,
    'RF_R2': rf_r2, 'RF_RMSE': rf_rmse,
    'GB_R2': gb_r2, 'GB_RMSE': gb_rmse,
    'GB_CV_mean': cv_scores.mean(), 'GB_CV_std': cv_scores.std()
}
pd.DataFrame([summary]).to_csv('/home/claude/Table_ML_Comparison.csv', index=False)

print("\n\nAll results saved to CSV files.")
