"""
JBE Ethics-Performance Paper: Missing Analyses
All results from actual Ethics_Financial_Merged_Panel.csv
No fabrication - every number reproducible from this code.
"""
import pandas as pd
import numpy as np
import statsmodels.api as sm
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

# =============================================================================
# LOAD AND PREP
# =============================================================================
df = pd.read_csv('/mnt/user-data/uploads/Ethics_Financial_Merged_Panel.csv')
print(f"Raw data: {len(df)} rows, {df['Ticker'].nunique()} unique firms")
print(f"Years: {sorted(df['fyear'].unique())}")

# Log firm size
df['ln_size'] = np.log(df['Firm Size'])

# Replace infinities
df = df.replace([np.inf, -np.inf], np.nan)

# Winsorize Tobin's Q at 1%/99%
for col in ["Tobin's Q", 'ROA', 'ROE']:
    lower = df[col].quantile(0.01)
    upper = df[col].quantile(0.99)
    df[col] = df[col].clip(lower, upper)

# Standardize key variables
for col in ['ethics_composite', 'ethics_governance', 'ethics_social', 
            'ethics_environmental', 'ethics_legal', 'ln_size', 'Leverage', 'R&D Intensity']:
    if col in df.columns:
        df[col + '_std'] = (df[col] - df[col].mean()) / df[col].std()

# GICS sector labels
sector_labels = {
    10: 'Energy', 15: 'Materials', 20: 'Industrials', 25: 'Cons. Discret.',
    30: 'Cons. Staples', 35: 'Health Care', 40: 'Financials', 45: 'Info Tech',
    50: 'Communication', 55: 'Utilities', 60: 'Real Estate'
}

# Drop rows with missing R&D (to match N=1,583 from prior analysis)
df_rd = df.dropna(subset=['R&D Intensity']).copy()
print(f"After R&D filter: {len(df_rd)} rows")

# =============================================================================
# HELPER: Run OLS with robust SE, return full results
# =============================================================================
def run_ols(data, y_col, x_cols, add_constant=True):
    """Run OLS regression, return statsmodels results object."""
    reg = data[[y_col] + x_cols].dropna()
    y = reg[y_col].values.astype(float)
    X = reg[x_cols].values.astype(float)
    if add_constant:
        X = sm.add_constant(X)
    model = sm.OLS(y, X).fit(cov_type='HC1')
    return model, reg

print("\n" + "="*80)
print("ANALYSIS 1: ETHICS × FIRM SIZE INTERACTION TERMS")
print("(Parallel to JMS Table 5)")
print("="*80)

# Panel A: Ethics Composite × Size
yr_dum = pd.get_dummies(df_rd['fyear'], prefix='yr', drop_first=True).astype(float)
ind_dum = pd.get_dummies(df_rd['gsector'], prefix='ind', drop_first=True).astype(float)
df_reg = pd.concat([df_rd.reset_index(drop=True), yr_dum.reset_index(drop=True), ind_dum.reset_index(drop=True)], axis=1)

# Create interaction term
df_reg['ethics_x_size'] = df_reg['ethics_composite_std'] * df_reg['ln_size_std']

fe_cols = list(yr_dum.columns) + list(ind_dum.columns)
controls = ['ln_size_std', 'Leverage_std', 'R&D Intensity_std']

# Panel A model
x_a = ['ethics_composite_std', 'ethics_x_size'] + controls + fe_cols
model_a, reg_a = run_ols(df_reg, "Tobin's Q", x_a)

print("\nPanel A: Ethics Composite × Size")
print(f"  Ethics Composite:  β = {model_a.params[1]:.6f}, SE = {model_a.bse[1]:.6f}, p = {model_a.pvalues[1]:.6f}")
print(f"  Ethics × Size:     β = {model_a.params[2]:.6f}, SE = {model_a.bse[2]:.6f}, p = {model_a.pvalues[2]:.6f}")
print(f"  N = {int(model_a.nobs)}, R² = {model_a.rsquared:.6f}")

# Panel B: Each dimension × Size
print("\nPanel B: Ethics Dimensions × Size Interactions")
dim_cols_std = ['ethics_governance_std', 'ethics_social_std', 'ethics_environmental_std', 'ethics_legal_std']
dim_labels = ['Governance', 'Social', 'Environmental', 'Legal']

# Create dimension × size interactions
for dc in dim_cols_std:
    df_reg[dc + '_x_size'] = df_reg[dc] * df_reg['ln_size_std']

interaction_cols = [dc + '_x_size' for dc in dim_cols_std]
x_b = dim_cols_std + interaction_cols + controls + fe_cols
model_b, reg_b = run_ols(df_reg, "Tobin's Q", x_b)

print(f"\n  {'Variable':<30} {'β':>10} {'SE':>10} {'p':>10}")
print(f"  {'-'*60}")
for i, (dim, label) in enumerate(zip(dim_cols_std, dim_labels)):
    idx = i + 1  # +1 for constant
    print(f"  {label:<30} {model_b.params[idx]:>10.6f} {model_b.bse[idx]:>10.6f} {model_b.pvalues[idx]:>10.6f}")
for i, (dim, label) in enumerate(zip(dim_cols_std, dim_labels)):
    idx = len(dim_cols_std) + i + 1
    print(f"  {label + ' × Size':<30} {model_b.params[idx]:>10.6f} {model_b.bse[idx]:>10.6f} {model_b.pvalues[idx]:>10.6f}")
print(f"  N = {int(model_b.nobs)}, R² = {model_b.rsquared:.6f}")

# Save Panel A and B results
results_interaction = {
    'Panel_A': {
        'Ethics_Composite': {'coef': model_a.params[1], 'se': model_a.bse[1], 'p': model_a.pvalues[1]},
        'Ethics_x_Size': {'coef': model_a.params[2], 'se': model_a.bse[2], 'p': model_a.pvalues[2]},
        'N': int(model_a.nobs), 'R2': model_a.rsquared
    }
}

