# Paper DF — Reproducibility Package
## "From Certification to Selection: Venture Capital and the Structural Transformation of the US IPO Market, 1990–2025"
### Wullianallur Raghupathi & Deepika Sethi — Gabelli School of Business, Fordham University
### Target: Journal of Business Venturing

---

## Package Contents

### data/
- `master_all_us_ipos_RitterLSEGcompustat.xlsx` — Master dataset: 7,751 US IPOs × 190 columns, 1990–2025.
  Sources: LSEG New Issues (deal characteristics), Compustat (firm fundamentals), Ritter IPO Database (VC status, founding year, sector classification).

### code/
- `analysis_paperD.py` — Primary analysis script (Paper D): VC vs non-VC characteristics, underpricing regressions, selection model, subsample analyses. Produces all Paper D CSV outputs.
- `analysis_paperF.py` — Primary analysis script (Paper F): Market cycle classification, structural shift regressions, dot-com vs COVID comparison. Produces all Paper F CSV outputs.
- `build_tables_A1_A2.py` — Builds Table A1 (Variable Definitions) and Table A2 (Descriptive Statistics) XML blocks inserted into the paper's DOCX.
- `make_figure1.py` — Generates Figure 1 (Conceptual Framework) as a PNG.
- `README_PaperD.txt` — Original Paper D package documentation and key results.
- `README_PaperF.txt` — Original Paper F package documentation and key results.

### outputs/
**Paper D outputs (n = 2,909 Ritter-matched subsample):**
- `table1_vc_vs_nonvc.csv` — VC vs non-VC firm characteristics comparison (→ Table 2 in paper)
- `table2_vc_by_decade.csv` — VC effect across market eras
- `table3_vc_by_industry.csv` — VC presence by industry
- `table4_vc_underpricing.csv` — Underpricing by VC × decade × sector
- `table5_vc_profitability.csv` — Profitability comparison
- `table6_vc_firm_size.csv` — VC by deal size tercile
- `table7_internet_comparison.csv` — Internet vs non-internet comparison
- `paperD_regression_models.csv` — 6 OLS models (→ Table 3 in paper)
- `paperD_subsample_regressions.csv` — 5 subsample regressions (→ Table 4)

**Paper F outputs (n = 7,474 full sample with complete data):**
- `table1_annual.csv` — Year-by-year IPO volume and characteristics
- `table2_market_cycles.csv` — 10 market cycle classification
- `table3_cycle_transitions.csv` — Cross-cycle t-tests
- `table4_dotcom.csv` — Dot-com boom decomposition
- `table5_firm_quality.csv` — Firm quality trends
- `table6_hot_cold.csv` — Hot vs cold market comparison
- `paperF_regression_models.csv` — 8 OLS models (deal size + underpricing)
- `paperF_profitability_models.csv` — 3 logistic models (profitability)
- `table_two_booms.csv` — Dot-com vs COVID direct comparison (→ Table 7)

**Figures:**
- `Figure1_ConceptualFramework.png` — Conceptual framework figure (embedded in paper)
- `fig_paperD.png` — Six-panel VC analysis figure
- `fig_paperF.png` — Six-panel market cycle analysis figure

### docs/
- `PaperDF_JBV_Full.docx` — Full paper, JBV-formatted, validated OOXML
- `CoverLetter_DF_JBV.docx` — Cover letter for JBV submission

### transcript/
- `session_transcript_PaperDF_JBV.txt` — Full Claude working session transcript documenting all analytical decisions, data verification steps, and paper construction.

---

## Key Sample Notes

| Sample | N | Description |
|--------|---|-------------|
| Full LSEG sample | 7,751 | All US IPOs 1990–2025 from LSEG New Issues |
| Ritter-matched subsample | 2,909 | VC-status non-null (1,088 VC-backed, 1,821 non-VC) |
| First-day return subsample | 1,421 | Valid PRICESAMEDAY in LSEG within Ritter match |

**Critical note on n = 2,909:** The Ritter-matched subsample retains 25 firms with null `ipo_year` but valid `vc_backed`, consistent with `analysis_paperD.py` which never applies a year filter before extracting the VC subsample. This matches the Paper D README which states n = 2,909 (1,088 VC, 1,821 non-VC).

---

## To Reproduce

```bash
pip install pandas numpy scipy matplotlib openpyxl statsmodels
python3 code/analysis_paperD.py   # requires data/master_all_us_ipos_...xlsx
python3 code/analysis_paperF.py
```

All output CSVs in `outputs/` are regenerated from the master dataset.
