import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

fig, ax = plt.subplots(figsize=(11, 6.8))
ax.set_xlim(0, 11)
ax.set_ylim(0, 6.8)
ax.axis('off')
fig.patch.set_facecolor('white')

FONT='serif'; LIGHT='#e4e4e4'; WHITE='white'; BLACK='black'; DG='#444444'; MG='#888888'

def rbox(cx,cy,w,h,fc=WHITE,ec=BLACK,lw=1.3,ls='solid'):
    ax.add_patch(FancyBboxPatch((cx-w/2,cy-h/2),w,h,
        boxstyle='round,pad=0.07',linewidth=lw,edgecolor=ec,facecolor=fc,linestyle=ls,zorder=3))

def tb(cx,cy,lines,fs=8.4,bold0=True,color=BLACK,step=0.245):
    n=len(lines); top=cy+(n-1)/2*step
    for i,txt in enumerate(lines):
        ax.text(cx,top-i*step,txt,ha='center',va='center',fontsize=fs,fontfamily=FONT,
                zorder=4,color=color,fontweight='bold' if (bold0 and i==0) else 'normal')

def arr(x0,y0,x1,y1,lw=1.25,ls='solid',ec=BLACK,hw=0.16,hl=0.11):
    ax.annotate('',xy=(x1,y1),xytext=(x0,y0),
        arrowprops=dict(arrowstyle=f'->,head_width={hw},head_length={hl}',
                        color=ec,lw=lw,linestyle=ls),zorder=5)

def lbl(x,y,txt,ha='center',va='center',fs=7.3,color=DG):
    ax.text(x,y,txt,ha=ha,va=va,fontsize=fs,fontfamily=FONT,style='italic',color=color,zorder=6)

# ── LAYOUT ───────────────────────────────────────────────────────────────────
BNR_CY, BNR_H = 6.28, 0.92
ROW_Y  = 3.52
BW, BH = 2.72, 1.85
VC_X, FP_X, IPO_X = 1.60, 5.50, 9.40

VC_R  = VC_X  + BW/2   # 2.96
FP_L  = FP_X  - BW/2   # 4.14
FP_R  = FP_X  + BW/2   # 6.86
IPO_L = IPO_X - BW/2   # 8.04
TOP   = ROW_Y + BH/2   # 4.445

# Moderator sits above the FP–IPO gap midpoint
MC_X  = (FP_R + IPO_L) / 2   # 7.45
MC_CY, MC_W, MC_H = 5.25, 2.70, 0.68
MC_B  = MC_CY - MC_H/2        # 4.91

H3_CY = 1.42

# ── BANNER ───────────────────────────────────────────────────────────────────
rbox(5.50, BNR_CY, 10.30, BNR_H, fc=LIGHT, lw=1.1)
tb(5.50, BNR_CY,
   ['Structural Transformation of the US IPO Market  (H4)',
    'VC share: 25% (1990s) \u2192 53% (2020s)   |   Profitable at IPO: 62% \u2192 27%   |   Median deal: $34M \u2192 $154M',
    'H5: VC firms\u2019 profitability declining faster than non-VC  \u2014  41% of market profitability decline is compositional'],
   fs=8.5, step=0.280)

# ── MAIN BOXES ───────────────────────────────────────────────────────────────
rbox(VC_X,  ROW_Y, BW, BH)
tb(VC_X, ROW_Y, ['Venture Capital','Role: Selection','',
    'Selects younger,','pre-profit, high-growth','ventures'])

rbox(FP_X,  ROW_Y, BW, BH)
tb(FP_X, ROW_Y, ['VC-Pathway Firm Profile','',
    'Young, pre-profit','High-tech intensive',
    'Growth-dependent','High fundamental uncertainty'])

rbox(IPO_X, ROW_Y, BW, BH)
tb(IPO_X, ROW_Y, ['IPO Pricing Outcomes','',
    'Persistent premium: +12.4 pp','Amplified in booms:',
    '  +46.3 pp (dot-com)','  +10.6 pp (COVID)'])

# ── MODERATOR ────────────────────────────────────────────────────────────────
rbox(MC_X, MC_CY, MC_W, MC_H, fc=LIGHT, lw=1.1)
tb(MC_X, MC_CY, ['Market Cycles  (H2)','(Boom amplification)'], fs=8.4)

# ── H3 PANEL ─────────────────────────────────────────────────────────────────
rbox(5.50, H3_CY, 10.30, 1.26, fc='#f8f8f8', ec=MG, lw=0.9, ls='dashed')
tb(5.50, H3_CY,
   ['H3 \u2014 Signal Dilution Hypothesis  (Not Supported)',
    'Certification prediction: as VC prevalence rises (25% \u2192 53%), underpricing premium should shrink',
    'Finding: premium stable across all eras;  VC \u00d7 VC_share: \u03b2\u202f=\u202f+0.245,  p\u202f=\u202f0.094'],
   fs=7.85, bold0=True, color=DG, step=0.230)
pred_y = H3_CY + 0.230 * 0.5
ax.plot([0.75, 10.25], [pred_y, pred_y], color=MG, lw=0.75, alpha=0.55, zorder=7)

# ── ARROWS ───────────────────────────────────────────────────────────────────
# A: Banner → VC  (H4)
arr(VC_X, BNR_CY - BNR_H/2,  VC_X, TOP)
lbl(VC_X - 0.22, (BNR_CY - BNR_H/2 + TOP)/2,
    'H4: VC pathway\nbecomes dominant', ha='right', fs=7.2)

# B: VC → Firm Profile  (short label — gap = 1.18 units)
arr(VC_R, ROW_Y,  FP_L, ROW_Y)
lbl((VC_R + FP_L)/2, ROW_Y + 0.20, 'Shapes', fs=7.4)

# C: Firm Profile → IPO Outcomes  (H1 — label kept SHORT to fit the 1.18-unit gap)
arr(FP_R, ROW_Y,  IPO_L, ROW_Y)
lbl(MC_X, ROW_Y - 0.22, 'H1', fs=8.0, color=BLACK)

# D: Market Cycles (moderator) → FP–IPO midpoint  (dashed, no arrow label — box title suffices)
arr(MC_X, MC_B,  MC_X, ROW_Y + 0.08,  lw=1.2, ls='dashed')

# ── DIVIDER ──────────────────────────────────────────────────────────────────
ax.plot([0.40, 10.60], [2.20, 2.20],
        color='#bbbbbb', lw=0.65, linestyle='dotted', zorder=2)

plt.tight_layout(pad=0.2)
plt.savefig('/home/claude/framework_figure2.png', dpi=300,
            bbox_inches='tight', facecolor='white')
print('Done.')
