# All values computed directly from master_all_us_ipos_RitterLSEGcompustat.xlsx
# Ritter-matched subsample: n=2,909 (1,088 VC, 1,821 non-VC) — no year filter on vc_backed,
# matching analysis_paperD.py exactly and consistent with paper text n=2,909.

FONT = 'Times New Roman'

def esc(s):
    return s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;').replace('"','&quot;').replace("'",'&apos;')

def run(text, bold=False, italic=False, size=20):
    b  = '<w:b/><w:bCs/>' if bold  else '<w:b w:val="false"/><w:bCs w:val="false"/>'
    it = '<w:i/><w:iCs/>' if italic else '<w:i w:val="false"/><w:iCs w:val="false"/>'
    t  = esc(text)
    sp = ' xml:space="preserve"' if (' ' in text or text == '') else ''
    return (f'<w:r><w:rPr>'
            f'<w:rFonts w:ascii="{FONT}" w:cs="{FONT}" w:eastAsia="{FONT}" w:hAnsi="{FONT}"/>'
            f'{b}{it}<w:sz w:val="{size}"/><w:szCs w:val="{size}"/>'
            f'</w:rPr><w:t{sp}>{t}</w:t></w:r>')

def para(runs_xml, center=False, after=160, indent=False):
    jc  = '<w:jc w:val="center"/>' if center else '<w:jc w:val="both"/>'
    ind = '<w:ind w:firstLine="720"/>' if indent else ''
    return (f'<w:p><w:pPr>'
            f'<w:spacing w:after="{after}" w:line="360" w:lineRule="auto"/>'
            f'{ind}{jc}</w:pPr>{runs_xml}</w:p>')

def heading2(text):
    return (f'<w:p><w:pPr><w:pStyle w:val="Heading2"/>'
            f'<w:spacing w:before="240" w:after="120" w:line="360" w:lineRule="auto"/>'
            f'</w:pPr>{run(text, bold=True, size=24)}</w:p>')

def table_title(text):
    return (f'<w:p><w:pPr>'
            f'<w:spacing w:before="240" w:after="80" w:line="240"/>'
            f'</w:pPr>{run(esc(text), bold=True, size=22)}</w:p>')

def note(text):
    return (f'<w:p><w:pPr>'
            f'<w:spacing w:after="200" w:line="240"/>'
            f'</w:pPr>{run(text, italic=True, size=19)}</w:p>')

# Border constants
NONE = ('<w:top w:val="none" w:sz="0" w:color="auto"/>'
        '<w:bottom w:val="none" w:sz="0" w:color="auto"/>'
        '<w:left w:val="none" w:sz="0" w:color="auto"/>'
        '<w:right w:val="none" w:sz="0" w:color="auto"/>')
TOP  = ('<w:top w:val="single" w:sz="8" w:color="000000"/>'
        '<w:bottom w:val="none" w:sz="0" w:color="auto"/>'
        '<w:left w:val="none" w:sz="0" w:color="auto"/>'
        '<w:right w:val="none" w:sz="0" w:color="auto"/>')
BOT  = ('<w:top w:val="none" w:sz="0" w:color="auto"/>'
        '<w:bottom w:val="single" w:sz="8" w:color="000000"/>'
        '<w:left w:val="none" w:sz="0" w:color="auto"/>'
        '<w:right w:val="none" w:sz="0" w:color="auto"/>')
BOTH = ('<w:top w:val="single" w:sz="8" w:color="000000"/>'
        '<w:bottom w:val="single" w:sz="8" w:color="000000"/>'
        '<w:left w:val="none" w:sz="0" w:color="auto"/>'
        '<w:right w:val="none" w:sz="0" w:color="auto"/>')

def cell(text, w_dxa, border=NONE, bold=False, center=False, italic=False, shade=False):
    jc = '<w:jc w:val="center"/>' if center else ''
    sh = '<w:shd w:val="clear" w:color="auto" w:fill="F5F5F5"/>' if shade else ''
    t  = esc(text)
    b  = '<w:b/><w:bCs/>' if bold  else '<w:b w:val="false"/><w:bCs w:val="false"/>'
    it = '<w:i/><w:iCs/>' if italic else '<w:i w:val="false"/><w:iCs w:val="false"/>'
    sp = ' xml:space="preserve"' if ' ' in text else ''
    return (f'<w:tc><w:tcPr>'
            f'<w:tcW w:w="{w_dxa}" w:type="dxa"/>'
            f'<w:tcBorders>{border}</w:tcBorders>{sh}'
            f'<w:tcMar><w:top w:w="60" w:type="dxa"/><w:bottom w:w="60" w:type="dxa"/>'
            f'<w:left w:w="100" w:type="dxa"/><w:right w:w="100" w:type="dxa"/></w:tcMar>'
            f'</w:tcPr>'
            f'<w:p><w:pPr><w:spacing w:after="0" w:line="240"/>{jc}</w:pPr>'
            f'<w:r><w:rPr>'
            f'<w:rFonts w:ascii="{FONT}" w:cs="{FONT}" w:eastAsia="{FONT}" w:hAnsi="{FONT}"/>'
            f'{b}{it}<w:sz w:val="19"/><w:szCs w:val="19"/>'
            f'</w:rPr><w:t{sp}>{t}</w:t></w:r>'
            f'</w:p></w:tc>')

def trow(cells_xml, is_header=False):
    hdr = '<w:tblHeader/>' if is_header else ''
    return f'<w:tr><w:trPr>{hdr}</w:trPr>{cells_xml}</w:tr>'

def make_table(col_widths, header_cells, data_rows):
    total = sum(col_widths)
    grid  = ''.join(f'<w:gridCol w:w="{w}"/>' for w in col_widths)
    rows  = trow(header_cells, is_header=True)
    for i, (cells, is_last) in enumerate(zip(data_rows, [False]*(len(data_rows)-1)+[True])):
        rows += trow(cells)
    return (f'<w:tbl>'
            f'<w:tblPr><w:tblW w:w="{total}" w:type="dxa"/>'
            f'<w:tblLayout w:type="fixed"/><w:tblLook w:val="0000"/></w:tblPr>'
            f'<w:tblGrid>{grid}</w:tblGrid>{rows}</w:tbl>')

# ─── TABLE A1: VARIABLE DEFINITIONS ─────────────────────────────────────────
# Col widths: Variable | Definition | Source | Role
WA = [1700, 3100, 1400, 2160]  # sum=8360

var_data = [
    ('First-Day Return (FDR)',
     '(Closing price day 1 - Offer price) / Offer price; |FDR| > 5 set missing',
     'LSEG / Ritter DB',
     'Dependent variable (H1, H2, H3)'),
    ('VC-Backed',
     '1 if firm received VC financing prior to IPO; 0 otherwise',
     "Ritter's IPO database",
     'Primary IV (all hypotheses)'),
    ('Offer Price ($)',
     'Final IPO offer price per share in US dollars',
     'LSEG New Issues',
     'Control; deal characteristic'),
    ('Deal Amount ($M)',
     'Gross IPO proceeds in millions of US dollars',
     'LSEG New Issues',
     'Control; deal size'),
    ('Total Assets ($M)',
     'Book value of total assets at fiscal year of IPO',
     'Compustat (at)',
     'Control; firm size proxy'),
    ('log(Assets)',
     'Natural log of Total Assets ($M); used in OLS regressions',
     'Computed (Compustat)',
     'Regression control (H1 models)'),
    ('Revenue ($M)',
     'Total revenues at fiscal year of IPO (revt)',
     'Compustat',
     'Descriptive; firm scale'),
    ('ROA',
     'Operating income / Total assets (oiadp/at); |ROA|>10 set missing',
     'Compustat',
     'Control; profitability (H1)'),
    ('Leverage',
     'Total debt / Total assets (dt/at)',
     'Compustat',
     'Control; capital structure'),
    ('Profitable',
     '1 if ROA > 0 at IPO fiscal year; 0 otherwise; missing if ROA missing',
     'Computed (Compustat)',
     'Dependent variable (H5 logistic)'),
    ('High-Tech',
     '1 if SIC classified as technology or biotechnology; 0 otherwise',
     "Ritter's IPO database",
     'Control; sector (all models)'),
    ('Firm Age (years)',
     'IPO year minus founding year; values outside [0, 200] set missing',
     "Ritter's IPO database",
     'Descriptive; venture stage'),
    ('Bubble (1998-2000)',
     '1 if IPO in calendar years 1998-2000; 0 otherwise',
     'Authors',
     'Cycle indicator (H2)'),
    ('COVID Boom (2020-2021)',
     '1 if IPO in calendar years 2020-2021; 0 otherwise',
     'Authors',
     'Cycle indicator (H2)'),
    ('VC Share (Era)',
     'Proportion of VC-backed IPOs within each of six market eras',
     'Computed (Ritter DB)',
     'Signal dilution test (H3)'),
    ('Year (centered)',
     'IPO calendar year minus 2007 (sample midpoint)',
     'Authors',
     'Time trend (H3, H5)'),
]

hdr_A = (cell('Variable',             WA[0], BOTH, bold=True) +
          cell('Measurement / Definition', WA[1], BOTH, bold=True) +
          cell('Source',              WA[2], BOTH, bold=True) +
          cell('Role in Analysis',    WA[3], BOTH, bold=True))

rows_A = []
for i,(v,d,s,r) in enumerate(var_data):
    sh  = (i % 2 == 1)
    bdr = BOT if i == len(var_data)-1 else NONE
    rows_A.append(
        cell(v, WA[0], bdr, bold=True, shade=sh) +
        cell(d, WA[1], bdr,            shade=sh) +
        cell(s, WA[2], bdr,            shade=sh) +
        cell(r, WA[3], bdr,            shade=sh)
    )

TABLE_A = make_table(WA, hdr_A, rows_A)

# ─── TABLE A2: DESCRIPTIVE STATISTICS ────────────────────────────────────────
# Col widths: Variable | N | Mean | SD | Min | Median | Max
WB = [2100, 700, 900, 900, 900, 900, 1060]  # sum=7460

# All values computed from n=2,909 Ritter-matched subsample (vc_backed non-null, no year filter)
# matching analysis_paperD.py exactly
desc_data = [
    #  Variable                   N        Mean        SD         Min       Median      Max
    ('Offer Price ($)',         '2,884', '24.672',  '218.080',  '0.100',  '15.000',  '5,250.000'),
    ('Deal Amount ($M)',        '2,890', '265.493', '827.369',  '0.015',  '92.722',  '21,767.215'),
    ('Total Assets ($M)',       '2,551', '2,267.952','15,981.257','0.001', '179.953', '364,217.000'),
    ('Revenue ($M)',            '2,525', '702.822', '2,915.441','-18.834','65.969',  '35,915.000'),
    ('ROA',                     '2,460', '-0.093',  '0.492',    '-9.246', '0.015',   '0.959'),
    ('log(Assets)',             '2,551', '5.292',   '1.935',    '-6.908', '5.193',   '12.806'),
    ('Leverage (Debt/Assets)',  '1,718', '0.192',   '0.695',    '0.000',  '0.041',   '26.692'),
    ('Firm Age (years)',        '2,450', '15.458',  '21.776',   '0.000',  '9.000',   '179.000'),
    ('High-Tech (0/1)',         '2,909', '0.475',   '0.499',    '0.000',  '0.000',   '1.000'),
    ('Profitable (0/1)',        '2,460', '0.535',   '0.499',    '0.000',  '1.000',   '1.000'),
    ('First-Day Return',        '1,421', '0.168',   '0.331',    '-1.000', '0.075',   '3.500'),
    ('VC-Backed (0/1)',         '2,909', '0.374',   '0.484',    '0.000',  '0.000',   '1.000'),
]

hdr_B = (cell('Variable',  WB[0], BOTH, bold=True) +
          cell('N',        WB[1], BOTH, bold=True, center=True) +
          cell('Mean',     WB[2], BOTH, bold=True, center=True) +
          cell('SD',       WB[3], BOTH, bold=True, center=True) +
          cell('Min',      WB[4], BOTH, bold=True, center=True) +
          cell('Median',   WB[5], BOTH, bold=True, center=True) +
          cell('Max',      WB[6], BOTH, bold=True, center=True))

rows_B = []
for i,(v,n,mn,sd,mi,med,mx) in enumerate(desc_data):
    sh  = (i % 2 == 1)
    bdr = BOT if i == len(desc_data)-1 else NONE
    rows_B.append(
        cell(v,   WB[0], bdr, bold=True,  shade=sh) +
        cell(n,   WB[1], bdr, center=True, shade=sh) +
        cell(mn,  WB[2], bdr, center=True, shade=sh) +
        cell(sd,  WB[3], bdr, center=True, shade=sh) +
        cell(mi,  WB[4], bdr, center=True, shade=sh) +
        cell(med, WB[5], bdr, center=True, shade=sh) +
        cell(mx,  WB[6], bdr, center=True, shade=sh)
    )

TABLE_B = make_table(WB, hdr_B, rows_B)

# ─── ASSEMBLE ─────────────────────────────────────────────────────────────────
INSERTION = (
    heading2('4.2 Variable Definitions and Descriptive Statistics') +
    para(run('Table A1 defines all variables used in the analysis, including their operational measurements, data sources, and roles in the regression models.', size=24), indent=True) +
    table_title('Table A1. Variable Definitions and Measurement') +
    TABLE_A +
    note('Note. All variables defined using the same transformation rules as the original analysis scripts (analysis_paperD.py, analysis_paperF.py). ROA winsorized at |ROA| > 10. First-day return winsorized at |FDR| > 5. Firm age set to missing for values outside [0, 200] years. Sources: LSEG New Issues (deal characteristics), Compustat (firm fundamentals), Ritter IPO Database (VC status, founding year, sector).') +
    para(run('Table A2 reports descriptive statistics for all key variables in the Ritter-matched subsample (n = 2,909). N varies across variables due to Compustat coverage gaps. First-day return is available for 1,421 firms with valid same-day closing price in LSEG.', size=24), indent=True) +
    table_title('Table A2. Descriptive Statistics (Ritter-Matched Subsample, n = 2,909)') +
    TABLE_B +
    note('Note. All statistics computed directly from master_all_us_ipos_RitterLSEGcompustat.xlsx. Ritter-matched subsample defined as all observations where VC-Backed is non-missing (n = 2,909: 1,088 VC-backed, 1,821 non-VC), consistent with analysis_paperD.py. N for individual variables varies due to Compustat non-coverage. Offer price N = 2,884 reflects 25 firms with missing IPO year retained in the VC subsample per the original analysis protocol.')
)

with open('/tmp/insertion_block.xml', 'w', encoding='utf-8') as f:
    f.write(INSERTION)
print(f"Written: {len(INSERTION):,} chars")
