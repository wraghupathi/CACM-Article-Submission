PAPER F REPRODUCIBILITY PACKAGE (v2 — with regressions)
========================================================
"Three Structural Shifts in the US IPO Market:
 Deal Size, Firm Quality, and Cyclical Underpricing, 1990-2025"
Generated: March 12, 2026

DATA: master_all_us_ipos_RitterLSEGcompustat.xlsx (7,751 × 190)
ANALYSIS SAMPLE: 7,474 IPOs with complete data, 1990-2025

TO REPRODUCE: python3 analysis_paperF.py

REGRESSION OUTPUTS:
  paperF_regression_models.csv — 8 OLS models (deal size + underpricing)
  paperF_profitability_models.csv — 3 logistic models (profitability)
  table_two_booms.csv — Dot-com vs COVID direct comparison

DESCRIPTIVE OUTPUTS:
  table1_annual.csv — Year-by-year volume and characteristics
  table2_market_cycles.csv — 10 market cycles
  table3_cycle_transitions.csv — Cross-cycle t-tests
  table4_dotcom.csv — Dot-com boom decomposition
  table5_firm_quality.csv — Firm quality trends
  table6_hot_cold.csv — Hot vs cold market comparison

FIGURES: fig_paperF.png — Six-panel market cycle analysis
PAPER: PaperF_Draft.docx — Full working paper, 4 tables embedded

KEY RESULTS:
  1. Deal size: +5.2%/year raw, +1.2%/year with controls (both p<0.001)
  2. Profitability: -1.1 pp/year decline (p<0.001), monotonic across eras
  3. Underpricing: cyclical — dot-com +35.8 pp, COVID +10.8 pp (both p<0.001)
  4. Two booms differ: COVID had 3x larger deals, lower underpricing, less tech-concentrated
  5. High-tech share: cyclical with modest upward drift, not secular transformation
