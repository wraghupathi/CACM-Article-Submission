PAPER D REPRODUCIBILITY PACKAGE (v2 — with regressions)
========================================================
"The VC Certification Paradox: Venture Capital, Underpricing,
 and the Selection of Uncertainty"
Generated: March 12, 2026

DATA:
  master_all_us_ipos_RitterLSEGcompustat.xlsx (7,751 IPOs × 190 cols)
  VC subsample: 2,909 Ritter-matched (1,088 VC, 1,821 non-VC)

TO REPRODUCE:
  python3 analysis_paperD.py

ANALYSIS OUTPUTS:
  table1_vc_vs_nonvc.csv — Characteristics comparison (Table 2 in paper)
  table2_vc_by_decade.csv — VC effect across decades
  table3_vc_by_industry.csv — VC presence by industry
  table4_vc_underpricing.csv — Underpricing by VC × decade × sector
  table5_vc_profitability.csv — Profitability comparison
  table6_vc_firm_size.csv — VC by deal size tercile
  table7_internet_comparison.csv — Internet vs non-internet
  paperD_regression_models.csv — 6 OLS models (Table 3 in paper)
  paperD_subsample_regressions.csv — 5 subsample regressions (Table 4)
  paperD_selection_model.csv — Logistic selection model (Table 5)

FIGURES:
  fig_paperD.png — Six-panel VC analysis

PAPER DRAFT:
  PaperD_Draft.docx — Full working paper with all tables embedded

KEY RESULTS:
  VC underpricing premium: +16.8 pp bivariate, +15.6 pp with controls (p<0.0001)
  Within high-tech: +14.6 pp (p<0.0001)
  Within non-HT: +17.9 pp (p<0.0001)
  VC × Bubble: +45.5 pp (p=0.003)
  Selection: high-tech +37.2 pp probability of VC backing
