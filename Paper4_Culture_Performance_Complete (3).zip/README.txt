PAPER 4: CULTURE-PERFORMANCE (Target: Journal of Management Studies)
====================================================================
"Does Organizational Culture Create Value? Evidence from Text-Mined 
Job Descriptions of S&P 500 Firms"

V4: Full draft, 52 references (17 post-2020), 8 tables + 1 figure 
    embedded WITHOUT captions. Page numbers top right, no running header.

CONTENTS:
  paper/          V4 (current) + V3 (prior with captions)
  png_exports/    PNG of each table and figure (no captions)
  data/           Panel data, SHAP results, analysis summaries
  code/           Python analysis + table-building scripts
  outputs/        SVG source for conceptual framework
  transcripts/    All session transcripts + journal
