#!/usr/bin/env python3
"""Insert tables, figure, and gold-standard references into Culture Performance Paper V2."""

import pandas as pd
import numpy as np
import statsmodels.api as sm
from docx import Document
from docx.shared import Inches, Pt, Cm, RGBColor, Emu
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_ORIENT
from docx.oxml.ns import qn
import warnings
warnings.filterwarnings('ignore')

# ============================================================
# LOAD DATA AND RUN ALL REGRESSIONS
# ============================================================
df = pd.read_csv('/home/claude/culture/culture_panel_prepped.csv')

# Prep fixed effects
year_dum = pd.get_dummies(df['fyear'], prefix='yr', drop_first=True).astype(float)
ind_dum = pd.get_dummies(df['gsector'], prefix='ind', drop_first=True).astype(float)
df2 = pd.concat([df.reset_index(drop=True), year_dum.reset_index(drop=True), ind_dum.reset_index(drop=True)], axis=1)
year_cols = [c for c in df2.columns if c.startswith('yr_')]
ind_cols = [c for c in df2.columns if c.startswith('ind_')]
controls = ['Firm Size_std', 'Leverage_std', 'R&D Intensity_std']
cvf = ['CVF_Clan_std', 'CVF_Adhocracy_std', 'CVF_Market_std', 'CVF_Hierarchy_std']

def sig(p):
    if p < 0.001: return '***'
    if p < 0.01: return '**'
    if p < 0.05: return '*'
    if p < 0.1: return '\u2020'
    return ''

def run_ols(dv, ivs, data, fe_year=True, fe_ind=True, ctrls=True):
    X_cols = ivs.copy()
    if ctrls: X_cols += controls
    if fe_year: X_cols += year_cols
    if fe_ind: X_cols += ind_cols
    reg_data = data[[dv] + X_cols].dropna()
    y = reg_data[dv].values
    X = sm.add_constant(reg_data[X_cols].values)
    m = sm.OLS(y, X).fit(cov_type='HC1')
    return m, len(reg_data)

# Create interaction terms
df2['CultXSize'] = df2['Culture_Composite_std'] * df2['Firm Size_std']
df2['ClanXSize'] = df2['CVF_Clan_std'] * df2['Firm Size_std']
df2['AdhocXSize'] = df2['CVF_Adhocracy_std'] * df2['Firm Size_std']
df2['MktXSize'] = df2['CVF_Market_std'] * df2['Firm Size_std']
df2['HierXSize'] = df2['CVF_Hierarchy_std'] * df2['Firm Size_std']
df2['ClanXAdhoc'] = df2['CVF_Clan_std'] * df2['CVF_Adhocracy_std']
df2['ClanXMkt'] = df2['CVF_Clan_std'] * df2['CVF_Market_std']
df2['ClanXHier'] = df2['CVF_Clan_std'] * df2['CVF_Hierarchy_std']
df2['AdhocXMkt'] = df2['CVF_Adhocracy_std'] * df2['CVF_Market_std']
df2['AdhocXHier'] = df2['CVF_Adhocracy_std'] * df2['CVF_Hierarchy_std']
df2['MktXHier'] = df2['CVF_Market_std'] * df2['CVF_Hierarchy_std']

# ============================================================
# HELPER FUNCTIONS FOR TABLE FORMATTING
# ============================================================

def set_cell_font(cell, text, bold=False, size=9, align='left'):
    """Set cell text with Times New Roman formatting."""
    cell.text = ''
    p = cell.paragraphs[0]
    if align == 'center':
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == 'right':
        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    else:
        p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.space_before = Pt(1)
    p.paragraph_format.space_after = Pt(1)
    p.paragraph_format.line_spacing = Pt(11)
    run = p.add_run(str(text))
    run.font.name = 'Times New Roman'
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = RGBColor(0, 0, 0)
    return run

def add_table_title(doc, title_text):
    """Add a table title paragraph."""
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(6)
    run = p.add_run(title_text)
    run.font.name = 'Times New Roman'
    run.font.size = Pt(11)
    run.font.bold = True
    return p

def add_table_note(doc, note_text):
    """Add a table note paragraph."""
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(12)
    run = p.add_run(note_text)
    run.font.name = 'Times New Roman'
    run.font.size = Pt(8)
    run.font.italic = True
    return p

def set_table_borders(table, top_bottom_only=True):
    """Set thin borders on table."""
    tbl = table._tbl
    tblPr = tbl.tblPr if tbl.tblPr is not None else tbl.makeelement(qn('w:tblPr'), {})
    borders = tblPr.makeelement(qn('w:tblBorders'), {})
    for edge in ['top', 'bottom']:
        el = borders.makeelement(qn(f'w:{edge}'), {
            qn('w:val'): 'single', qn('w:sz'): '6',
            qn('w:space'): '0', qn('w:color'): '000000'
        })
        borders.append(el)
    if not top_bottom_only:
        for edge in ['left', 'right', 'insideH', 'insideV']:
            el = borders.makeelement(qn(f'w:{edge}'), {
                qn('w:val'): 'none', qn('w:sz'): '0',
                qn('w:space'): '0', qn('w:color'): '000000'
            })
            borders.append(el)
    tblPr.append(borders)
    if tbl.tblPr is None:
        tbl.insert(0, tblPr)

def add_header_bottom_border(row):
    """Add bottom border to header row cells."""
    for cell in row.cells:
        tc = cell._tc
        tcPr = tc.get_or_add_tcPr()
        borders = tcPr.makeelement(qn('w:tcBorders'), {})
        bottom = borders.makeelement(qn('w:bottom'), {
            qn('w:val'): 'single', qn('w:sz'): '4',
            qn('w:space'): '0', qn('w:color'): '000000'
        })
        borders.append(bottom)
        tcPr.append(borders)

def add_page_break(doc):
    p = doc.add_paragraph()
    run = p.add_run()
    run.add_break(docx.enum.text.WD_BREAK.PAGE)

# ============================================================
# OPEN DOCUMENT
# ============================================================
doc = Document('/home/claude/Culture_Performance_Paper_V2.docx')

# Find and remove the placeholder paragraph "[Tables 1–8 to be inserted here from analysis output]"
for i, para in enumerate(doc.paragraphs):
    if 'Tables 1' in para.text and 'inserted here' in para.text:
        # Clear it
        para.text = ''
        break

# ============================================================
# TABLE 1: DESCRIPTIVE STATISTICS
# ============================================================
add_table_title(doc, 'Table 1. Descriptive Statistics')

vars_info = [
    ("Tobin's Q", "Tobin\u2019s Q"), ("ROA", "ROA"), ("ROE", "ROE"),
    ("Culture_Composite", "Culture Composite"),
    ("CVF_Clan", "CVF Clan"), ("CVF_Adhocracy", "CVF Adhocracy"),
    ("CVF_Market", "CVF Market"), ("CVF_Hierarchy", "CVF Hierarchy"),
    ("Firm Size", "Firm Size (total assets, $M)"), ("Leverage", "Leverage"),
    ("R&D Intensity", "R&D Intensity")
]

table1 = doc.add_table(rows=1 + len(vars_info), cols=6)
table1.alignment = WD_TABLE_ALIGNMENT.CENTER

headers1 = ['Variable', 'N', 'Mean', 'SD', 'Min', 'Max']
for j, h in enumerate(headers1):
    set_cell_font(table1.rows[0].cells[j], h, bold=True, size=9, align='center' if j > 0 else 'left')
add_header_bottom_border(table1.rows[0])

for i, (col, label) in enumerate(vars_info):
    s = df[col].dropna()
    row = table1.rows[i + 1]
    set_cell_font(row.cells[0], label, size=9, align='left')
    set_cell_font(row.cells[1], f'{len(s):,}', size=9, align='center')
    set_cell_font(row.cells[2], f'{s.mean():.4f}', size=9, align='center')
    set_cell_font(row.cells[3], f'{s.std():.4f}', size=9, align='center')
    set_cell_font(row.cells[4], f'{s.min():.4f}', size=9, align='center')
    set_cell_font(row.cells[5], f'{s.max():.4f}', size=9, align='center')

set_table_borders(table1)
add_table_note(doc, 'Notes: N = 1,891 firm-year observations (397 firms, 2019\u20132023). Culture variables are proportions of CVF-related terms in job descriptions. Firm Size is total assets in millions. Tobin\u2019s Q is winsorized at the 1st and 99th percentiles. R&D Intensity is available for 1,583 observations; missing values imputed as zero for regression analysis.')

# ============================================================
# TABLE 2: CORRELATION MATRIX
# ============================================================
add_table_title(doc, 'Table 2. Correlation Matrix')

corr_vars = ["Tobin's Q", "Culture_Composite", "CVF_Clan", "CVF_Adhocracy",
             "CVF_Market", "CVF_Hierarchy", "Firm Size", "Leverage", "R&D Intensity"]
labels2 = ["(1) TQ", "(2) Culture", "(3) Clan", "(4) Adhoc", "(5) Market",
           "(6) Hier", "(7) Size", "(8) Lev", "(9) R&D"]
corr = df[corr_vars].corr()

table2 = doc.add_table(rows=10, cols=10)
table2.alignment = WD_TABLE_ALIGNMENT.CENTER

# Header
set_cell_font(table2.rows[0].cells[0], '', size=8)
for j, lab in enumerate(labels2):
    set_cell_font(table2.rows[0].cells[j+1], f'({j+1})', bold=True, size=8, align='center')
add_header_bottom_border(table2.rows[0])

for i in range(9):
    set_cell_font(table2.rows[i+1].cells[0], labels2[i], size=8, align='left')
    for j in range(9):
        if j <= i:
            val = corr.iloc[i, j]
            text = f'{val:.3f}' if i != j else '\u2014'
            set_cell_font(table2.rows[i+1].cells[j+1], text, size=8, align='center')
        else:
            set_cell_font(table2.rows[i+1].cells[j+1], '', size=8)

set_table_borders(table2)
add_table_note(doc, 'Notes: Pearson correlations. N = 1,891 (N = 1,583 for correlations involving R&D Intensity). Correlations |r| > .045 significant at p < .05.')

# ============================================================
# TABLE 3: CULTURE COMPOSITE → TOBIN'S Q (3 models)
# ============================================================
add_table_title(doc, 'Table 3. Culture Composite and Tobin\u2019s Q: OLS Regression Results')

m1, n1 = run_ols('TQ_wins', ['Culture_Composite_std'], df2, fe_year=True, fe_ind=False, ctrls=False)
m2, n2 = run_ols('TQ_wins', ['Culture_Composite_std'], df2, fe_year=True, fe_ind=False, ctrls=True)
m3, n3 = run_ols('TQ_wins', ['Culture_Composite_std'], df2, fe_year=True, fe_ind=True, ctrls=True)

t3_rows = [
    ('Culture Composite', 1, 1, 1),
    ('Firm Size', None, 2, 2),
    ('Leverage', None, 3, 3),
    ('R&D Intensity', None, 4, 4),
]

table3 = doc.add_table(rows=13, cols=4)
table3.alignment = WD_TABLE_ALIGNMENT.CENTER

set_cell_font(table3.rows[0].cells[0], 'Variable', bold=True, size=9)
set_cell_font(table3.rows[0].cells[1], 'Model 1', bold=True, size=9, align='center')
set_cell_font(table3.rows[0].cells[2], 'Model 2', bold=True, size=9, align='center')
set_cell_font(table3.rows[0].cells[3], 'Model 3', bold=True, size=9, align='center')
add_header_bottom_border(table3.rows[0])

models = [m1, m2, m3]
row_idx = 1
for label, i1, i2, i3 in t3_rows:
    set_cell_font(table3.rows[row_idx].cells[0], label, size=9)
    for col_idx, (m, idx) in enumerate([(m1, i1), (m2, i2), (m3, i3)]):
        if idx is not None:
            b = m.params[idx]; se = m.bse[idx]; p = m.pvalues[idx]
            text = f'{b:.3f}{sig(p)}'
            set_cell_font(table3.rows[row_idx].cells[col_idx+1], text, size=9, align='center')
            # SE on next row
        else:
            set_cell_font(table3.rows[row_idx].cells[col_idx+1], '', size=9)
    row_idx += 1
    # SE row
    set_cell_font(table3.rows[row_idx].cells[0], '', size=9)
    for col_idx, (m, idx) in enumerate([(m1, i1), (m2, i2), (m3, i3)]):
        if idx is not None:
            set_cell_font(table3.rows[row_idx].cells[col_idx+1], f'({m.bse[idx]:.3f})', size=9, align='center')
        else:
            set_cell_font(table3.rows[row_idx].cells[col_idx+1], '', size=9)
    row_idx += 1

# Footer rows
set_cell_font(table3.rows[row_idx].cells[0], 'Year FE', size=9)
for c in range(1, 4): set_cell_font(table3.rows[row_idx].cells[c], 'Yes', size=9, align='center')
row_idx += 1
set_cell_font(table3.rows[row_idx].cells[0], 'Industry FE', size=9)
set_cell_font(table3.rows[row_idx].cells[1], 'No', size=9, align='center')
set_cell_font(table3.rows[row_idx].cells[2], 'No', size=9, align='center')
set_cell_font(table3.rows[row_idx].cells[3], 'Yes', size=9, align='center')
row_idx += 1
set_cell_font(table3.rows[row_idx].cells[0], 'N', size=9)
for c, m in enumerate(models): set_cell_font(table3.rows[row_idx].cells[c+1], f'{n1:,}', size=9, align='center')
row_idx += 1
set_cell_font(table3.rows[row_idx].cells[0], 'R\u00b2', size=9)
for c, m in enumerate(models): set_cell_font(table3.rows[row_idx].cells[c+1], f'{m.rsquared:.3f}', size=9, align='center')

set_table_borders(table3)
add_table_note(doc, 'Notes: OLS regression with robust (HC1) standard errors in parentheses. Dependent variable: Tobin\u2019s Q (winsorized). All independent variables standardized. \u2020 p < .10, * p < .05, ** p < .01, *** p < .001.')

# ============================================================
# TABLE 4: CVF QUADRANTS → TQ
# ============================================================
add_table_title(doc, 'Table 4. CVF Culture Dimensions and Tobin\u2019s Q: Simultaneous Regression')

m4, n4 = run_ols('TQ_wins', cvf, df2)

table4 = doc.add_table(rows=10, cols=4)
table4.alignment = WD_TABLE_ALIGNMENT.CENTER

for j, h in enumerate(['Variable', '\u03b2', 'SE', 'p']):
    set_cell_font(table4.rows[0].cells[j], h, bold=True, size=9, align='center' if j > 0 else 'left')
add_header_bottom_border(table4.rows[0])

cvf_names = ['CVF Clan', 'CVF Adhocracy', 'CVF Market', 'CVF Hierarchy']
for i, name in enumerate(cvf_names):
    idx = i + 1
    set_cell_font(table4.rows[i+1].cells[0], name, size=9)
    set_cell_font(table4.rows[i+1].cells[1], f'{m4.params[idx]:.3f}{sig(m4.pvalues[idx])}', size=9, align='center')
    set_cell_font(table4.rows[i+1].cells[2], f'{m4.bse[idx]:.3f}', size=9, align='center')
    set_cell_font(table4.rows[i+1].cells[3], f'{m4.pvalues[idx]:.4f}', size=9, align='center')

ctrl_names = ['Firm Size', 'Leverage', 'R&D Intensity']
for i, name in enumerate(ctrl_names):
    idx = 5 + i
    row = 5 + i
    set_cell_font(table4.rows[row].cells[0], name, size=9)
    set_cell_font(table4.rows[row].cells[1], f'{m4.params[idx]:.3f}{sig(m4.pvalues[idx])}', size=9, align='center')
    set_cell_font(table4.rows[row].cells[2], f'{m4.bse[idx]:.3f}', size=9, align='center')
    set_cell_font(table4.rows[row].cells[3], f'{m4.pvalues[idx]:.4f}', size=9, align='center')

set_cell_font(table4.rows[8].cells[0], 'N', size=9)
set_cell_font(table4.rows[8].cells[1], f'{n4:,}', size=9, align='center')
set_cell_font(table4.rows[9].cells[0], 'R\u00b2', size=9)
set_cell_font(table4.rows[9].cells[1], f'{m4.rsquared:.3f}', size=9, align='center')

set_table_borders(table4)
add_table_note(doc, 'Notes: OLS regression with all four CVF dimensions entered simultaneously. Robust (HC1) standard errors. Year and industry fixed effects included. All variables standardized. \u2020 p < .10, * p < .05, ** p < .01, *** p < .001.')

# ============================================================
# TABLE 5: CULTURE × SIZE INTERACTION
# ============================================================
add_table_title(doc, 'Table 5. Culture \u00d7 Firm Size Interaction Effects on Tobin\u2019s Q')

# Panel A: Composite
m5a, n5a = run_ols('TQ_wins', ['Culture_Composite_std', 'CultXSize'], df2)
# Panel B: CVF × Size
int_vars = cvf + ['ClanXSize', 'AdhocXSize', 'MktXSize', 'HierXSize']
m5b, n5b = run_ols('TQ_wins', int_vars, df2)

table5 = doc.add_table(rows=12, cols=4)
table5.alignment = WD_TABLE_ALIGNMENT.CENTER

for j, h in enumerate(['Variable', '\u03b2', 'SE', 'p']):
    set_cell_font(table5.rows[0].cells[j], h, bold=True, size=9, align='center' if j > 0 else 'left')
add_header_bottom_border(table5.rows[0])

# Panel A header
set_cell_font(table5.rows[1].cells[0], 'Panel A: Culture Composite', bold=True, size=9)

set_cell_font(table5.rows[2].cells[0], 'Culture Composite', size=9)
set_cell_font(table5.rows[2].cells[1], f'{m5a.params[1]:.3f}{sig(m5a.pvalues[1])}', size=9, align='center')
set_cell_font(table5.rows[2].cells[2], f'{m5a.bse[1]:.3f}', size=9, align='center')
set_cell_font(table5.rows[2].cells[3], f'{m5a.pvalues[1]:.4f}', size=9, align='center')

set_cell_font(table5.rows[3].cells[0], 'Culture \u00d7 Size', size=9)
set_cell_font(table5.rows[3].cells[1], f'{m5a.params[2]:.3f}{sig(m5a.pvalues[2])}', size=9, align='center')
set_cell_font(table5.rows[3].cells[2], f'{m5a.bse[2]:.3f}', size=9, align='center')
set_cell_font(table5.rows[3].cells[3], f'{m5a.pvalues[2]:.4f}', size=9, align='center')

# Panel B header
set_cell_font(table5.rows[5].cells[0], 'Panel B: CVF Dimensions \u00d7 Size', bold=True, size=9)

int_names = ['Clan \u00d7 Size', 'Adhocracy \u00d7 Size', 'Market \u00d7 Size', 'Hierarchy \u00d7 Size']
for i, name in enumerate(int_names):
    idx = 5 + i  # after 4 CVF main effects
    row = 6 + i
    set_cell_font(table5.rows[row].cells[0], name, size=9)
    set_cell_font(table5.rows[row].cells[1], f'{m5b.params[idx]:.3f}{sig(m5b.pvalues[idx])}', size=9, align='center')
    set_cell_font(table5.rows[row].cells[2], f'{m5b.bse[idx]:.3f}', size=9, align='center')
    set_cell_font(table5.rows[row].cells[3], f'{m5b.pvalues[idx]:.4f}', size=9, align='center')

set_cell_font(table5.rows[10].cells[0], 'N', size=9)
set_cell_font(table5.rows[10].cells[1], f'{n5b:,}', size=9, align='center')
set_cell_font(table5.rows[11].cells[0], 'R\u00b2 (Panel B)', size=9)
set_cell_font(table5.rows[11].cells[1], f'{m5b.rsquared:.3f}', size=9, align='center')

set_table_borders(table5)
add_table_note(doc, 'Notes: OLS regression with robust (HC1) standard errors. Year and industry fixed effects, and controls (firm size, leverage, R&D intensity) included in all models. All variables standardized. \u2020 p < .10, * p < .05, ** p < .01, *** p < .001.')

# ============================================================
# TABLE 6: CVF CROSS-INTERACTIONS
# ============================================================
add_table_title(doc, 'Table 6. CVF Cross-Dimension Interaction Effects on Tobin\u2019s Q')

cross = cvf + ['ClanXAdhoc', 'ClanXMkt', 'ClanXHier', 'AdhocXMkt', 'AdhocXHier', 'MktXHier']
m6, n6 = run_ols('TQ_wins', cross, df2)

table6 = doc.add_table(rows=11, cols=4)
table6.alignment = WD_TABLE_ALIGNMENT.CENTER

for j, h in enumerate(['Variable', '\u03b2', 'SE', 'p']):
    set_cell_font(table6.rows[0].cells[j], h, bold=True, size=9, align='center' if j > 0 else 'left')
add_header_bottom_border(table6.rows[0])

# Main effects
for i, name in enumerate(cvf_names):
    idx = i + 1
    set_cell_font(table6.rows[i+1].cells[0], name, size=9)
    set_cell_font(table6.rows[i+1].cells[1], f'{m6.params[idx]:.3f}{sig(m6.pvalues[idx])}', size=9, align='center')
    set_cell_font(table6.rows[i+1].cells[2], f'{m6.bse[idx]:.3f}', size=9, align='center')
    set_cell_font(table6.rows[i+1].cells[3], f'{m6.pvalues[idx]:.4f}', size=9, align='center')

cross_names = ['Clan \u00d7 Adhocracy', 'Clan \u00d7 Market', 'Clan \u00d7 Hierarchy',
               'Adhocracy \u00d7 Market', 'Adhocracy \u00d7 Hierarchy', 'Market \u00d7 Hierarchy']
for i, name in enumerate(cross_names):
    idx = 5 + i
    row = 5 + i
    set_cell_font(table6.rows[row].cells[0], name, size=9)
    set_cell_font(table6.rows[row].cells[1], f'{m6.params[idx]:.3f}{sig(m6.pvalues[idx])}', size=9, align='center')
    set_cell_font(table6.rows[row].cells[2], f'{m6.bse[idx]:.3f}', size=9, align='center')
    set_cell_font(table6.rows[row].cells[3], f'{m6.pvalues[idx]:.4f}', size=9, align='center')

set_table_borders(table6)
add_table_note(doc, f'Notes: OLS regression with all four CVF main effects and all pairwise interactions. N = {n6:,}. R\u00b2 = {m6.rsquared:.3f}. Robust (HC1) standard errors. Controls, year and industry FE included. \u2020 p < .10, * p < .05, ** p < .01, *** p < .001.')

# ============================================================
# TABLE 7: INDUSTRY-STRATIFIED CVF → TQ
# ============================================================
add_table_title(doc, 'Table 7. Industry-Stratified CVF Effects on Tobin\u2019s Q')

gics_map = {10: 'Energy', 15: 'Materials', 20: 'Industrials', 25: 'Cons. Discret.',
            30: 'Cons. Staples', 35: 'Health Care', 40: 'Financials',
            45: 'Info Tech', 50: 'Communication', 55: 'Utilities', 60: 'Real Estate'}

# Collect results
ind_results = []
for sector in sorted(df['gsector'].unique()):
    sub = df2[df2['gsector'] == sector].copy()
    X_cols = cvf + controls + year_cols
    reg_data = sub[['TQ_wins'] + X_cols].dropna()
    if len(reg_data) < 30: continue
    y = reg_data['TQ_wins'].values
    X = sm.add_constant(reg_data[X_cols].values)
    try:
        m = sm.OLS(y, X).fit(cov_type='HC1')
        name = gics_map.get(int(sector), str(sector))
        row_data = [name, len(reg_data)]
        for i in range(4):
            row_data.append(f'{m.params[i+1]:.3f}{sig(m.pvalues[i+1])}')
        row_data.append(f'{m.rsquared:.3f}')
        ind_results.append(row_data)
    except:
        pass

table7 = doc.add_table(rows=1 + len(ind_results), cols=7)
table7.alignment = WD_TABLE_ALIGNMENT.CENTER

headers7 = ['Sector', 'N', 'Clan \u03b2', 'Adhocracy \u03b2', 'Market \u03b2', 'Hierarchy \u03b2', 'R\u00b2']
for j, h in enumerate(headers7):
    set_cell_font(table7.rows[0].cells[j], h, bold=True, size=8, align='center' if j > 0 else 'left')
add_header_bottom_border(table7.rows[0])

for i, row_data in enumerate(ind_results):
    for j, val in enumerate(row_data):
        align = 'left' if j == 0 else 'center'
        set_cell_font(table7.rows[i+1].cells[j], str(val), size=8, align=align)

set_table_borders(table7)
add_table_note(doc, 'Notes: Separate OLS regressions by GICS sector. Robust (HC1) standard errors. Year fixed effects and controls (firm size, leverage, R&D intensity) included. All culture variables standardized. \u2020 p < .10, * p < .05, ** p < .01, *** p < .001.')

# ============================================================
# TABLE 8: ML MODEL COMPARISON + SHAP
# ============================================================
add_table_title(doc, 'Table 8. Machine Learning Model Comparison and SHAP Feature Importance')

# Panel A: Model comparison
table8 = doc.add_table(rows=12, cols=3)
table8.alignment = WD_TABLE_ALIGNMENT.CENTER

set_cell_font(table8.rows[0].cells[0], '', size=9)
set_cell_font(table8.rows[0].cells[1], 'Test R\u00b2', bold=True, size=9, align='center')
set_cell_font(table8.rows[0].cells[2], 'RMSE', bold=True, size=9, align='center')
add_header_bottom_border(table8.rows[0])

set_cell_font(table8.rows[1].cells[0], 'Panel A: Model Comparison', bold=True, size=9)

ml_rows = [
    ('Ridge Regression (linear)', '0.134', '1.773'),
    ('Random Forest', '0.761', '0.931'),
    ('Gradient Boosting', '0.797', '0.858'),
    ('Gradient Boosting (5-fold CV)', '0.400 \u00b1 .095', '\u2014'),
]
for i, (model, r2, rmse) in enumerate(ml_rows):
    set_cell_font(table8.rows[i+2].cells[0], model, size=9)
    set_cell_font(table8.rows[i+2].cells[1], r2, size=9, align='center')
    set_cell_font(table8.rows[i+2].cells[2], rmse, size=9, align='center')

# Panel B: SHAP
set_cell_font(table8.rows[7].cells[0], 'Panel B: SHAP Feature Importance', bold=True, size=9)
set_cell_font(table8.rows[7].cells[1], 'Mean |SHAP|', bold=True, size=9, align='center')
set_cell_font(table8.rows[7].cells[2], 'Direction', bold=True, size=9, align='center')

shap_data = pd.read_csv('/home/claude/culture/culture_shap_results.csv')
# Show top features
shap_rows = [
    ('CVF Clan', '0.194', '\u2193 Lower TQ'),
    ('CVF Hierarchy', '0.143', '\u2191 Higher TQ'),
    ('CVF Market', '0.127', '\u2193 Lower TQ'),
    ('CVF Adhocracy', '0.110', 'Mixed'),
]
for i, (feat, shap_val, direction) in enumerate(shap_rows):
    set_cell_font(table8.rows[8+i].cells[0], feat, size=9)
    set_cell_font(table8.rows[8+i].cells[1], shap_val, size=9, align='center')
    set_cell_font(table8.rows[8+i].cells[2], direction, size=9, align='center')

set_table_borders(table8)
add_table_note(doc, 'Notes: Panel A compares linear (Ridge) and nonlinear (Random Forest, Gradient Boosting) models predicting Tobin\u2019s Q. Train/test split: 80/20. Panel B shows SHAP (SHapley Additive exPlanations) feature importance values from the Gradient Boosting model for CVF culture variables only (control variables: Firm Size = 0.689, R&D Intensity = 0.476, Leverage = 0.256). The gap between Gradient Boosting R\u00b2 (.797) and Ridge R\u00b2 (.134) indicates substantial nonlinearity in culture\u2013performance relationships.')

# ============================================================
# INSERT CONCEPTUAL FRAMEWORK FIGURE
# ============================================================
# Find the "TABLES" heading and insert figure before it
for i, para in enumerate(doc.paragraphs):
    if para.text.strip() == 'TABLES':
        # Insert figure heading and image before TABLES
        # We need to insert before this paragraph
        fig_heading = doc.add_paragraph()
        fig_heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = fig_heading.add_run('FIGURE')
        run.font.name = 'Times New Roman'
        run.font.size = Pt(12)
        run.font.bold = True

        fig_title = doc.add_paragraph()
        fig_title.alignment = WD_ALIGN_PARAGRAPH.LEFT
        run = fig_title.add_run('Figure 1. Conceptual Framework: Culture Dimensions, Moderators, and Firm Performance')
        run.font.name = 'Times New Roman'
        run.font.size = Pt(11)
        run.font.bold = True

        # Add image
        fig_para = doc.add_paragraph()
        fig_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = fig_para.add_run()
        run.add_picture('/home/claude/conceptual_framework.png', width=Inches(5.5))
        break

# ============================================================
# SAVE
# ============================================================
doc.save('/home/claude/Culture_Performance_Paper_V3_tables.docx')
print("V3 with tables saved successfully!")
print(f"Tables: 8")
print(f"Figure: 1 (conceptual framework, B&W)")
