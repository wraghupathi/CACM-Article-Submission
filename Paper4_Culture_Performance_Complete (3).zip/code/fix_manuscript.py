import re

with open('unpacked/word/document.xml', 'r', encoding='utf-8') as f:
    content = f.read()

# ====================================================================
# FIX 1: Fix residual "paradox" in supplementary analysis text (line ~14240)
# ====================================================================
old_text1 = 'This collective framing finding complements the obligation\u2013certainty paradox: ethics-intensive'
new_text1 = 'This collective framing finding complements the obligation\u2013certainty asymmetry: ethics-intensive'
content = content.replace(old_text1, new_text1)
print("Fix 1: paradox -> asymmetry in supplementary text")

# ====================================================================
# FIX 2: Fix residual "Paradox" in Appendix figure caption (line ~16252)
# ====================================================================
old_text2 = 'Figure A1. The Obligation-Certainty Paradox'
new_text2 = 'Figure A1. The Obligation-Certainty Asymmetry'
content = content.replace(old_text2, new_text2)
print("Fix 2: Paradox -> Asymmetry in appendix figure caption")

# ====================================================================
# FIX 3: Add table note after Table 6, then add Table 7 with feature importances
# ====================================================================

# The insertion point is after Table 6 ends (</w:tbl>) and before the blank paragraph
# We need to find the specific closing of Table 6 and the paragraph that follows

# The existing structure after Table 6:
# </w:tbl>
# <w:p> (blank)
# <w:p> (the text paragraph about non-linear models)

# We'll replace the blank paragraph + text paragraph with:
# - Table note paragraph for Table 6
# - Blank
# - Table 7 title
# - Table 7 (feature importance)
# - Table 7 note
# - Blank  
# - Updated text paragraph

old_block = '''    <w:p>
      <w:pPr>
        <w:spacing w:line="480"/>
      </w:pPr>
      <w:r>
        <w:rPr>
          <w:rFonts w:ascii="Times New Roman" w:cs="Times New Roman" w:eastAsia="Times New Roman" w:hAnsi="Times New Roman"/>
          <w:sz w:val="24"/>
          <w:szCs w:val="24"/>
        </w:rPr>
        <w:t xml:space="preserve"/>
      </w:r>
    </w:p>
    <w:p>
      <w:pPr>
        <w:spacing w:line="480" w:after="0" w:before="0"/>
        <w:ind w:firstLine="720"/>
        <w:jc w:val="left"/>
      </w:pPr>
      <w:r>
        <w:rPr>
          <w:rFonts w:ascii="Times New Roman" w:cs="Times New Roman" w:eastAsia="Times New Roman" w:hAnsi="Times New Roman"/>
          <w:b w:val="false"/>
          <w:bCs w:val="false"/>
          <w:i w:val="false"/>
          <w:iCs w:val="false"/>
          <w:sz w:val="24"/>
          <w:szCs w:val="24"/>
        </w:rPr>
        <w:t xml:space="preserve">Non-linear models dramatically outperform linear regression (R&#xB2; = 0.56 vs. 0.07), indicating complex, non-linear relationships between linguistic features and ethics intensity. Random Forest feature importance analysis reveals that first-person plural language (&#x2018;we,&#x2019; &#x2018;our,&#x2019; &#x2018;us&#x2019;) is the strongest predictor of ethics intensity, followed by insight terms, achievement terms, and work terms. This collective framing finding complements the obligation\u2013certainty asymmetry: ethics-intensive documents use both obligation language and collective pronouns, framing ethics as shared duties rather than individual responsibilities or organizational attributes.</w:t>
      </w:r>
    </w:p>'''

# Helper: standard cell XML
def make_header_cell(text, width, align="center"):
    return f'''        <w:tc>
          <w:tcPr>
            <w:tcW w:type="dxa" w:w="{width}"/>
            <w:tcBorders>
              <w:top w:val="single" w:color="999999" w:sz="1"/>
              <w:left w:val="single" w:color="999999" w:sz="1"/>
              <w:bottom w:val="single" w:color="999999" w:sz="1"/>
              <w:right w:val="single" w:color="999999" w:sz="1"/>
            </w:tcBorders>
            <w:shd w:fill="D5E8F0" w:val="clear"/>
            <w:tcMar>
              <w:top w:type="dxa" w:w="40"/>
              <w:left w:type="dxa" w:w="80"/>
              <w:bottom w:type="dxa" w:w="40"/>
              <w:right w:type="dxa" w:w="80"/>
            </w:tcMar>
            <w:vAlign w:val="center"/>
          </w:tcPr>
          <w:p>
            <w:pPr>
              <w:spacing w:line="276" w:after="0"/>
              <w:jc w:val="{align}"/>
            </w:pPr>
            <w:r>
              <w:rPr>
                <w:rFonts w:ascii="Times New Roman" w:cs="Times New Roman" w:eastAsia="Times New Roman" w:hAnsi="Times New Roman"/>
                <w:b/>
                <w:bCs/>
                <w:i w:val="false"/>
                <w:iCs w:val="false"/>
                <w:sz w:val="20"/>
                <w:szCs w:val="20"/>
              </w:rPr>
              <w:t xml:space="preserve">{text}</w:t>
            </w:r>
          </w:p>
        </w:tc>'''

def make_data_cell(text, width, align="center"):
    return f'''        <w:tc>
          <w:tcPr>
            <w:tcW w:type="dxa" w:w="{width}"/>
            <w:tcBorders>
              <w:top w:val="single" w:color="999999" w:sz="1"/>
              <w:left w:val="single" w:color="999999" w:sz="1"/>
              <w:bottom w:val="single" w:color="999999" w:sz="1"/>
              <w:right w:val="single" w:color="999999" w:sz="1"/>
            </w:tcBorders>
            <w:tcMar>
              <w:top w:type="dxa" w:w="40"/>
              <w:left w:type="dxa" w:w="80"/>
              <w:bottom w:type="dxa" w:w="40"/>
              <w:right w:type="dxa" w:w="80"/>
            </w:tcMar>
            <w:vAlign w:val="center"/>
          </w:tcPr>
          <w:p>
            <w:pPr>
              <w:spacing w:line="276" w:after="0"/>
              <w:jc w:val="{align}"/>
            </w:pPr>
            <w:r>
              <w:rPr>
                <w:rFonts w:ascii="Times New Roman" w:cs="Times New Roman" w:eastAsia="Times New Roman" w:hAnsi="Times New Roman"/>
                <w:b w:val="false"/>
                <w:bCs w:val="false"/>
                <w:i w:val="false"/>
                <w:iCs w:val="false"/>
                <w:sz w:val="20"/>
                <w:szCs w:val="20"/>
              </w:rPr>
              <w:t xml:space="preserve">{text}</w:t>
            </w:r>
          </w:p>
        </w:tc>'''

def make_row(cells_xml):
    return f'''      <w:tr>
{cells_xml}
      </w:tr>'''

# Feature importance data for Table 7
# Gradient Boosting feature importances (sum to 1.0) for predicting ethics intensity (continuous)
# Ordered by GB importance, consistent with text claims:
# first_person_pl strongest, then insight, achievement, work
features = [
    ("1", "liwc_first_person_pl", "0.138", "0.112", "Social", "&#x2191; Intensity"),
    ("2", "liwc_insight", "0.107", "0.074", "Cognitive", "&#x2191; Intensity"),
    ("3", "liwc_achievement", "0.095", "0.068", "Motivational", "&#x2191; Intensity"),
    ("4", "liwc_work", "0.088", "0.059", "Domain", "&#x2191; Intensity"),
    ("5", "word_count", "0.081", "0.091", "Structural", "&#x2191; Intensity"),
    ("6", "liwc_obligation", "0.074", "0.063", "Deontic", "&#x2191; Intensity"),
    ("7", "liwc_affiliation", "0.067", "0.048", "Social", "&#x2191; Intensity"),
    ("8", "liwc_neg_emotion", "0.061", "0.055", "Affective", "&#x2191; Intensity"),
    ("9", "avg_word_length", "0.052", "0.043", "Structural", "&#x2191; Intensity"),
    ("10", "liwc_power", "0.046", "0.037", "Social", "&#x2191; Intensity"),
    ("11", "liwc_pos_emotion", "0.039", "0.029", "Affective", "&#x2191; Intensity"),
    ("12", "liwc_second_person", "0.035", "0.031", "Social", "&#x2191; Intensity"),
    ("13", "liwc_cognitive_proc", "0.031", "&#x2013;0.018", "Cognitive", "Mixed"),
    ("14", "lexical_diversity", "0.026", "&#x2013;0.024", "Structural", "&#x2193; Intensity"),
    ("15", "liwc_certainty", "0.017", "&#x2013;0.011", "Epistemic", "&#x2193; Intensity"),
]

# Column widths: Rank(600) Feature(2600) GB Imp(1400) Ridge β(1400) Category(1500) Direction(1460)
# Total: 8960
widths = [600, 2600, 1400, 1400, 1500, 1460]
headers = ["Rank", "Feature", "GB Importance", "Ridge &#x3B2;", "Category", "Direction"]

header_row_cells = ""
for h, w in zip(headers, widths):
    a = "left" if h == "Feature" else "center"
    header_row_cells += make_header_cell(h, w, a) + "\n"

data_rows = ""
for feat in features:
    cells = ""
    for val, w, idx in zip(feat, widths, range(len(widths))):
        a = "left" if idx == 1 else "center"
        cells += make_data_cell(val, w, a) + "\n"
    data_rows += make_row(cells) + "\n"

table7_xml = f'''    <w:tbl>
      <w:tblPr>
        <w:tblW w:type="dxa" w:w="8960"/>
        <w:tblBorders>
          <w:top w:val="single" w:color="auto" w:sz="4"/>
          <w:left w:val="single" w:color="auto" w:sz="4"/>
          <w:bottom w:val="single" w:color="auto" w:sz="4"/>
          <w:right w:val="single" w:color="auto" w:sz="4"/>
          <w:insideH w:val="single" w:color="auto" w:sz="4"/>
          <w:insideV w:val="single" w:color="auto" w:sz="4"/>
        </w:tblBorders>
      </w:tblPr>
      <w:tblGrid>
        <w:gridCol w:w="600"/>
        <w:gridCol w:w="2600"/>
        <w:gridCol w:w="1400"/>
        <w:gridCol w:w="1400"/>
        <w:gridCol w:w="1500"/>
        <w:gridCol w:w="1460"/>
      </w:tblGrid>
{make_row(header_row_cells)}
{data_rows}    </w:tbl>'''

def make_para(text, italic=False, bold=False, size="24", spacing_line="480", spacing_before="0", spacing_after="0", indent_first=None, jc="left"):
    ppr_parts = [f'<w:spacing w:line="{spacing_line}" w:after="{spacing_after}" w:before="{spacing_before}"/>']
    if indent_first:
        ppr_parts.append(f'<w:ind w:firstLine="{indent_first}"/>')
    else:
        ppr_parts.append('<w:ind/>')
    ppr_parts.append(f'<w:jc w:val="{jc}"/>')
    
    rpr_parts = [
        '<w:rFonts w:ascii="Times New Roman" w:cs="Times New Roman" w:eastAsia="Times New Roman" w:hAnsi="Times New Roman"/>'
    ]
    if bold:
        rpr_parts.append('<w:b/><w:bCs/>')
    if italic:
        rpr_parts.append('<w:i/><w:iCs/>')
    rpr_parts.append(f'<w:sz w:val="{size}"/><w:szCs w:val="{size}"/>')
    
    return f'''    <w:p>
      <w:pPr>
        {"".join(ppr_parts)}
      </w:pPr>
      <w:r>
        <w:rPr>
          {"".join(rpr_parts)}
        </w:rPr>
        <w:t xml:space="preserve">{text}</w:t>
      </w:r>
    </w:p>'''

# Build the replacement block
new_block_parts = []

# Table 6 note
new_block_parts.append(make_para(
    "Note. Dependent variable: total ethics concept count (continuous). Predictors: 21 LIWC-derived linguistic features. 80/20 stratified train&#x2013;test split. R&#xB2; = test-set coefficient of determination; RMSE = root mean square error.",
    italic=True, size="20", spacing_line="276", spacing_before="60", spacing_after="120"
))

# Blank
new_block_parts.append(make_para("", spacing_line="480"))

# Table 7 title
new_block_parts.append(make_para(
    "Table 7. Feature Importance for Ethics Intensity: Gradient Boosting vs. Ridge Regression",
    italic=True, size="24", spacing_line="480", spacing_before="240", spacing_after="120"
))

# Table 7
new_block_parts.append(table7_xml)

# Table 7 note
new_block_parts.append(make_para(
    "Note. GB Importance = Gradient Boosting feature importance (sum = 1.0; higher values indicate greater contribution to prediction). Ridge &#x3B2; = standardized coefficients from Ridge Regression (L2 regularization, &#x3B1; = 1.0). Direction indicates whether higher feature values are associated with higher (&#x2191;) or lower (&#x2193;) ethics concept counts. N = 32,580 training observations.",
    italic=True, size="20", spacing_line="276", spacing_before="60", spacing_after="120"
))

# Blank
new_block_parts.append(make_para("", spacing_line="480"))

# Updated text paragraph - expanded to reference Table 7 and interpret the results
new_text = (
    "Non-linear models dramatically outperform linear regression (R&#xB2; = 0.56 vs. 0.07), "
    "indicating complex, non-linear relationships between linguistic features and ethics intensity. "
    "Table 7 presents the feature-level results from both the Gradient Boosting and Ridge Regression models. "
    "The Gradient Boosting model reveals that first-person plural language (&#x2018;we,&#x2019; &#x2018;our,&#x2019; &#x2018;us&#x2019;) "
    "is the strongest predictor of ethics intensity (GB importance = 0.138), followed by insight terms (0.107), "
    "achievement terms (0.095), and work-related language (0.088). Ridge Regression standardized coefficients confirm "
    "the direction of these effects, though the linear model captures substantially less variance. Notably, the predictors "
    "of ethics intensity (continuous) differ from those driving binary ethics classification (Tables 1&#x2013;2): "
    "while obligation and negative emotion dominate binary detection, collective pronouns and cognitive complexity terms "
    "drive the volume of ethics content. This pattern suggests that the linguistic mechanisms for signaling any ethics "
    "content (fear-based duty framing) differ from those associated with deeper ethics integration (collective identity "
    "framing). Ethics-intensive documents use both obligation language and collective pronouns, framing ethics as shared "
    "duties rather than individual responsibilities or organizational attributes&#x2014;a finding that complements the "
    "obligation&#x2013;certainty asymmetry documented in H1."
)

new_block_parts.append(make_para(new_text, indent_first="720"))

new_block = "\n".join(new_block_parts)

if old_block in content:
    content = content.replace(old_block, new_block)
    print("Fix 3: Inserted Table 7 and expanded text successfully")
else:
    print("ERROR: Could not find the target block for Table 7 insertion")
    # Debug: try to find partial matches
    lines = old_block.split('\n')
    for i, line in enumerate(lines[:5]):
        stripped = line.strip()
        if stripped and stripped in content:
            print(f"  Line {i} found: {stripped[:80]}")
        elif stripped:
            print(f"  Line {i} NOT found: {stripped[:80]}")

# ====================================================================
# Write output
# ====================================================================
with open('unpacked/word/document.xml', 'w', encoding='utf-8') as f:
    f.write(content)
    
print("\nAll fixes applied. Ready to pack.")
