"""
Reproduce the exact analysis from the HRM paper revision session.
Uses same LIWC categories, ethics concepts, feature extraction, and random_state=42.
"""
import pandas as pd
import numpy as np
import re
import gc
import warnings
warnings.filterwarnings('ignore')

# =====================================================
# STEP 1: LIWC Categories (12 categories, matching paper)
# =====================================================
liwc_categories = {
    'obligation': ['must', 'shall', 'require', 'required', 'requires', 'requiring',
                   'obligate', 'obligated', 'mandate', 'mandated', 'mandatory',
                   'expect', 'expected', 'responsible', 'responsibility'],
    'certainty': ['always', 'never', 'must', 'certainly', 'definitely', 'absolutely',
                  'sure', 'clear', 'clearly', 'obvious', 'certain', 'undoubtedly',
                  'without question', 'every', 'all', 'none', 'completely'],
    'prohibition': ['not', 'never', 'prohibit', 'prohibited', 'forbid', 'forbidden',
                    'ban', 'banned', 'restrict', 'restricted', 'prevent', 'avoid'],
    'positive_emotion': ['good', 'well', 'great', 'best', 'better', 'happy', 'love',
                         'nice', 'excellent', 'wonderful', 'fantastic', 'amazing',
                         'positive', 'success', 'proud', 'passion', 'passionate',
                         'thrive', 'thriving', 'reward'],
    'negative_emotion': ['bad', 'wrong', 'worst', 'sad', 'hate', 'terrible', 'awful',
                         'poor', 'fail', 'failure', 'problem', 'issue', 'concern',
                         'risk', 'threat', 'danger', 'violation'],
    'first_person_plural': ['we', 'us', 'our', 'ours', 'ourselves'],
    'second_person': ['you', 'your', 'yours', 'yourself'],
    'power': ['power', 'control', 'lead', 'leader', 'authority', 'manage', 'direct',
              'command', 'govern', 'superior', 'oversee', 'supervise'],
    'achievement': ['achieve', 'achieved', 'accomplish', 'accomplished', 'success',
                    'successful', 'win', 'goal', 'goals', 'earn', 'attain',
                    'complete', 'completed', 'deliver', 'delivered', 'excel'],
    'affiliation': ['team', 'teams', 'group', 'groups', 'community', 'together',
                    'share', 'collaborate', 'partner', 'colleague', 'member', 'join'],
    'cognitive_process': ['think', 'know', 'consider', 'understand', 'realize',
                          'recognize', 'aware', 'determine', 'analyze', 'evaluate',
                          'assess', 'review', 'examine', 'identify', 'learn'],
    'tentative': ['maybe', 'perhaps', 'might', 'could', 'possibly', 'sometimes',
                  'often', 'usually', 'generally', 'likely', 'may', 'approximately',
                  'potential', 'potentially', 'occasional'],
}

print(f"LIWC categories: {len(liwc_categories)}")
for cat, terms in liwc_categories.items():
    print(f"  {cat}: {len(terms)} terms")

# =====================================================
# STEP 2: Ethics Concepts (from xlsx)
# =====================================================
concepts_df = pd.read_excel('/mnt/user-data/uploads/ethics_concepts_clean.xlsx')
ethics_concepts = {}
for _, row in concepts_df.iterrows():
    concept = row['Derived Keywords'].strip().lower()
    synsets = [concept]  # Include the concept itself
    for col in concepts_df.columns[2:]:
        if pd.notna(row[col]) and str(row[col]).strip():
            synsets.append(str(row[col]).strip().lower())
    ethics_concepts[concept] = list(set(synsets))

print(f"\nEthics concepts: {len(ethics_concepts)}")

# =====================================================
# STEP 3: Feature Extraction Function
# =====================================================
def extract_features(text):
    """Extract all features from a single JD text."""
    if not isinstance(text, str) or len(text.strip()) < 50:
        return None
    
    text_lower = text.lower()
    words = re.findall(r'\b[a-z]+\b', text_lower)
    word_count = len(words)
    if word_count == 0:
        return None
    
    word_set = set(words)
    features = {}
    
    # LIWC features (% of total words)
    for cat, terms in liwc_categories.items():
        count = sum(1 for w in words if w in set(terms))
        features[f'liwc_{cat}'] = (count / word_count) * 100
    
    # Structural features
    features['word_count'] = word_count
    features['unique_words'] = len(word_set)
    features['lexical_diversity'] = len(word_set) / word_count
    sentences = [s for s in re.split(r'[.!?]+', text) if s.strip()]
    features['sentence_count'] = max(len(sentences), 1)
    features['avg_sentence_length'] = word_count / features['sentence_count']
    features['avg_word_length'] = np.mean([len(w) for w in words]) if words else 0
    
    # Ethics concept indicators (binary: present/absent)
    for concept, synsets in ethics_concepts.items():
        found = any(term in text_lower for term in synsets)
        features[f'ethics_{concept.replace(" ", "_")}'] = 1 if found else 0
    
    # Document position features
    third = len(text) // 3
    beginning = text_lower[:third]
    middle = text_lower[third:2*third]
    end = text_lower[2*third:]
    
    ethics_terms_all = set()
    for terms in ethics_concepts.values():
        ethics_terms_all.update(terms)
    
    beg_count = sum(1 for t in ethics_terms_all if t in beginning)
    mid_count = sum(1 for t in ethics_terms_all if t in middle)
    end_count = sum(1 for t in ethics_terms_all if t in end)
    total_pos = max(beg_count + mid_count + end_count, 1)
    
    features['ethics_beginning_ratio'] = beg_count / total_pos
    features['ethics_middle_ratio'] = mid_count / total_pos
    features['ethics_end_ratio'] = end_count / total_pos
    features['ethics_position_concentration'] = max(beg_count, mid_count, end_count) / total_pos
    
    return features

# =====================================================
# STEP 4: Process all JDs
# =====================================================
print("\n=== Processing JDs ===")
uploads = '/mnt/user-data/uploads/'
chunk_files = ['PART1_part1', 'PART1_part2', 'PART1_part3', 'PART2_part1', 'PART2_part2', 'PART2_part3']

all_features = []
all_labels = []
total = 0

for part_name in chunk_files:
    f = f'{uploads}JD_ETHICS_WEIGHTED_{part_name}.csv'
    df = pd.read_csv(f)
    
    for idx, row in df.iterrows():
        feats = extract_features(row['weighted_text'])
        if feats:
            all_features.append(feats)
            all_labels.append(1 if row['has_ethics_signal'] else 0)
    
    total += len(df)
    print(f"  {part_name}: {len(df):,} JDs (total: {total:,})")
    del df; gc.collect()

features_df = pd.DataFrame(all_features)
features_df['has_ethics_signal'] = all_labels
features_df = features_df.dropna()

print(f"\n=== Feature Matrix ===")
print(f"Shape: {features_df.shape}")
print(f"Ethics rate: {features_df['has_ethics_signal'].mean():.4f}")

# Identify feature groups
liwc_cols = [c for c in features_df.columns if c.startswith('liwc_')]
ethics_cols = [c for c in features_df.columns if c.startswith('ethics_') and c not in 
               ['ethics_beginning_ratio', 'ethics_middle_ratio', 'ethics_end_ratio', 'ethics_position_concentration']]
struct_cols = ['word_count', 'unique_words', 'lexical_diversity', 'sentence_count', 'avg_sentence_length', 'avg_word_length']
position_cols = ['ethics_beginning_ratio', 'ethics_middle_ratio', 'ethics_end_ratio', 'ethics_position_concentration']

print(f"\nLIWC features: {len(liwc_cols)}")
print(f"Ethics concept features: {len(ethics_cols)}")
print(f"Structural features: {len(struct_cols)}")
print(f"Position features: {len(position_cols)}")

# Select top 16 ethics concepts by prevalence (matching paper)
ethics_prev = features_df[ethics_cols].mean().sort_values(ascending=False)
print(f"\nEthics concept prevalence (top 20):")
for i, (col, prev) in enumerate(ethics_prev.head(20).items()):
    print(f"  {i+1}. {col}: {prev:.4f}")

top16_ethics = ethics_prev.head(16).index.tolist()
print(f"\nTop 16 ethics concepts selected for Model B")

# Save feature matrix
features_df.to_csv('/home/claude/jd_liwc_features_full.csv', index=False)
print(f"\nSaved feature matrix: {features_df.shape}")

# =====================================================
# STEP 5: Define Model A and Model B feature sets
# =====================================================
model_a_features = liwc_cols + ['word_count', 'avg_word_length', 'avg_sentence_length', 'lexical_diversity']
model_b_features = model_a_features + top16_ethics + position_cols

print(f"\nModel A features ({len(model_a_features)}): {model_a_features}")
print(f"\nModel B features ({len(model_b_features)}): {len(model_b_features)} total")

# Save feature lists
import json
with open('/home/claude/feature_lists.json', 'w') as f:
    json.dump({'model_a': model_a_features, 'model_b': model_b_features, 'top16_ethics': top16_ethics}, f)

print("\n=== FEATURE EXTRACTION COMPLETE ===")
